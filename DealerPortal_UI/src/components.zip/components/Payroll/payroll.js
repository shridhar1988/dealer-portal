import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import axios from "axios";
import config from "../../config/config.json";

const Payroll = () => {
  const [selectedDate, setSelectedDate] = useState({ month: "", year: "" });
  const [paySlip, setPaySlip] = useState([]);
  const [slipGenerated, setSlipGenerated] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [empinfo, setEmpinfo] = useState([]);
  const [allDepartment, setAllDepartment] = useState([]);

  useEffect(() => {
    window.initDatePickerFuncation();
    GetEmpInfo();
    GetAllDepartments();
    getPaySlip();
    getPayslipsGenerated();

    const datePicker = window.$("#monthYearV");
    datePicker.on("change.datetimepicker", (e) => {
      let date = e.date ? e.date.format("YYYY-MM") : e.target.value;
      if (!date) {
        console.error("No valid date provided");
        return;
      }
      const [year, month] = date.split("-");
      setSelectedDate({ month, year });
    });

    return () => {
      datePicker.off("change.datetimepicker");
    };
  }, []);

  useEffect(() => {
    if (selectedDate.month && selectedDate.year) {
      getPaySlip();
    }
  }, [selectedDate]);

  const downloadPdf = () => {
    const byteCharacters = atob(paySlip.file.fileContents);
    const byteNumbers = Array.from(byteCharacters, (char) =>
      char.charCodeAt(0)
    );
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: "application/pdf" });

    const blobUrl = URL.createObjectURL(blob);

    const link = document.createElement("a");
    link.href = blobUrl;
    link.download = "Payslip.pdf";
    document.body.appendChild(link);
    link.click();

    document.body.removeChild(link);
    URL.revokeObjectURL(blobUrl);
  };

  const getPayslipsGenerated = async () => {
    try {
      // alert("personl empinfoId--> ", personalInfo.empInfoId);
      setIsLoaderActive(true);
      const response = await axios.get(
        `${config.API_URL}Payroll/GetPaymentDoneMonthsByUserId?empId=${personalInfo.empInfoId}`
      );

      if (response.data.data) {
        const transformedData = response.data.data.map((item) => ({
          month: item.month,
          year: item.year,
        }));

        setSlipGenerated(transformedData);
      } else {
        setSlipGenerated([]);
      }
    } catch (error) {
      console.error("Error fetching Data:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const getPaySlip = async () => {
    const { month, year } = selectedDate;
    try {
      setIsLoaderActive(true);
      const response = await axios.get(
        config.API_URL +
          `Pdf/generate?empId=${personalInfo.empInfoId}&month=${month}&year=${year}`
      );
      if (response) {
        setPaySlip(response.data || []);
        // console.log("payslip data--->",response.data);
        
      } else {
        setPaySlip([]);
      }
    } catch (error) {
      console.error("Error fetching Data:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetEmpInfo = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}AuthMaster/GetEmpInfoByEmpId?id=${personalInfo.userID}`
      );
      if (response.data.success == true) {
        setEmpinfo(response.data.data.empInfo || []);
        
      } else {
        console.error("Error fetching employee info:");
      }
    } catch (error) {
      console.error("Error fetching employee info:");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const GetAllDepartments = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Department/GetAllDepartments`
      );
      if (response.data.success == "True") {
        setAllDepartment(response.data.data || []);
      } else {
        console.error("Error fetching departments:");
      }
    } catch (error) {
      console.error("Error fetching departments:");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const monthNames = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  const sortedSlipGenerated = [...slipGenerated].sort((a, b) => {
    if (a.year == b.year) {
      return parseInt(a.month, 10) - parseInt(b.month, 10);
    }
    return parseInt(a.year, 10) - parseInt(b.year, 10);
  });

  return (
    <>
      <main id="main" className="addAssignee">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">Payroll<span hover-tooltip="In this you can view and download the generated payslips by clicking on required month." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">Payroll</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
        <div className="container-fluid px-3">
          <div className="card postion-relative">
            <div className="card-header">
              <div className="row ">
                
              {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div className="button-container d-flex col-md-11">
                  {sortedSlipGenerated.length > 0
                    ? sortedSlipGenerated.map((item, index) => (
                        <button
                          key={index}
                          style={{ fontSize: ".775rem" }} // Inline styles cannot use !important
                          className="btn btn-xs btn-primary m-1 d-flex justify-content-center align-items-center"
                          onClick={() => {
                            setSelectedDate({
                              month: item.month,
                              year: item.year,
                            });
                            getPaySlip();
                          }}
                        >
                          {`${monthNames[parseInt(item.month, 10) - 1]} ${
                            item.year
                          }`}
                        </button>
                      ))
                    : "No payslips generated"}
                </div>
                <div
                  className="col-md-1 float-end d-flex"
                  style={{ justifyContent: "flex-end" }}
                >
                  <button
                    type="button"
                    className="btn btn-tool float-end"
                    data-card-widget="maximize"
                  >
                    <i className="fas fa-expand"></i>
                  </button>
                </div>
              </div>
            </div>
            {paySlip.details ? (
              <div className="card-body">
                {selectedDate && (
                  <>
                    <div
                      className="card-header text-center"
                      style={{ borderBottom: "none" }}
                    >
                      <h3>
                        Salary Slip for{" "}
                        {`${monthNames[parseInt(selectedDate.month, 10) - 1]} ${
                          selectedDate.year
                        }`}
                      </h3>
                    </div>
                    <div className="card-body pt-0">
                      
                      <div className="salary-slip">
                        <table
                          className="table"
                          style={{
                            border: "none",
                            width: "100%",
                            tableLayout: "fixed",
                            borderBottom: "solid black 1px",
                          }}
                        >
                          <tr>
                            <th
                              style={{
                                border: "none",
                                verticalAlign: "bottom",
                                width: "40%",
                                backgroundColor: "white",
                              }}
                            >
                              <img
                                src={require("../../assets/images/Hlogo.png")}
                                alt="Company Logo"
                                className="logo"
                                style={{ height: "60px" }}
                              />
                            </th>
                            <td style={{ border: "none", float: "right" }}>
                              <strong>ITEOS LLP</strong>
                              <br />
                              <span>Address:</span> #H210 Hustlehub Tech Park,
                              27th Main Road HSR Layout,
                              <br />
                              Bangalore-560102, Karnataka, India
                            </td>
                          </tr>
                        </table>

                        <h4>Employee Details</h4>
                        <table className="table">
                          <tr>
                            <th>Employee Name</th>
                            <td>
                              {empinfo.firstName} {empinfo.lastName}
                            </td>
                            <th>Designation</th>
                            <td>{empinfo.designation}</td>
                          </tr>
                          <tr>
                            <th>Emp No.</th>
                            <td>
                              {"ITS-" +
                                (empinfo.department
                                  ? allDepartment
                                      .find(
                                        (dep) =>
                                          dep.departmentID == empinfo.department
                                      )
                                      ?.departmentName.slice(0, 4) +
                                    "-" +
                                    new Date()
                                      .getFullYear()
                                      .toString()
                                      .slice(-2)
                                  : "NA") +
                                "-" +
                                (empinfo.empInfoId
                                  ? empinfo.empInfoId
                                      .toString()
                                      .padStart(3, "0")
                                  : "NA")}
                            </td>
                            <th>Department</th>
                            <td>
                              {allDepartment.find(
                                (dep) => dep.departmentID == empinfo.department
                              )?.departmentName || "N/A"}
                            </td>
                          </tr>
                          <tr>
                            <th>Date Of Joining</th>
                            <td>{empinfo.joiningDate}</td>
                            <th>Current LOP</th>
                            <td>{paySlip.details.lop}</td>
                          </tr>
                          <tr>
                            <th>PF Number</th>
                            <td>PYBOM29463800000010062</td>
                            <th>ESIC Number</th>
                            <td>102064901630</td>
                          </tr>
                          <tr>
                            <th>Working Days</th>
                            <td>{paySlip.details.totalDaysInMonth}</td>
                            <th>Effective Working Days</th>
                            <td>{paySlip.details.totalWorkingDays}</td>
                          </tr>
                        </table>

                        <h4>Income</h4>
                        <table className="table">
                          <tr>
                            <th>Component</th>
                            <th>Amount</th>
                          </tr>
                          <tr>
                            <td>Basic Pay</td>
                            <td>{paySlip.details.basic_salary}</td>
                          </tr>
                          <tr>
                            <td>HRA (Gross)</td>
                            <td>{paySlip.details.hra}</td>
                          </tr>
                          <tr>
                            <td>Special Allowance</td>
                            <td>{paySlip.details.special_allowance}</td>
                          </tr>
                        </table>

                        <h4>Bonus / Extra Deduction</h4>
                        <table className="table">
                          <thead>
                            <tr>
                              <th style={{ width: "78.5%" }}>Component</th>
                              <th>Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Bonus</td>
                              <td>{paySlip.details.bonus || 0}</td>
                            </tr>
                            <tr>
                              <td>Extra Deduction</td>
                              <td>{paySlip.details.extraDeduction || 0}</td>
                            </tr>
                          </tbody>
                        </table>

                        <h4>Employer Deduction</h4>
                        <table className="table">
                          <tr>
                            <th>Component</th>
                            <th>Amount</th>
                          </tr>
                          <tr>
                            <td>ESIC Employee (Gross)</td>
                            <td>{paySlip.details.esciOfficeUse || 0}</td>
                          </tr>
                          <tr>
                            <td>PF Employee (Gross)</td>
                            <td>{paySlip.details.pf}</td>
                          </tr>
                        </table>

                        <h4>Employee Deduction</h4>
                        <table className="table">
                          <tr>
                            <th>Component</th>
                            <th>Amount</th>
                          </tr>
                          <tr>
                            <td>ESIC Employee (Gross)</td>
                            <td>{paySlip.details.esci || 0}</td>
                          </tr>
                          <tr>
                            <td>PF Employee (Gross)</td>
                            <td>{paySlip.details.pf}</td>
                          </tr>
                          <tr>
                            <td>PT (Gross)</td>
                            <td>{paySlip.details.pt}</td>
                          </tr>
                          <tr>
                            <td>Total Deduction</td>
                            <td style={{ fontWeight: "bold" }}>
                              {paySlip.details.total_deduction}
                            </td>
                          </tr>
                        </table>

                        <h4>Net Pay</h4>
                        <table className="table">
                          <tr>
                            <th>Gross Earning</th>
                            <td>
                              {paySlip.details.total_Gross}
                            </td>
                            <th>Total Deductions</th>
                            <td>{paySlip.details.total_deduction}</td>
                          </tr>
                          <tr>
                            <th>Net Pay (A-B)</th>
                            <td>
                              {paySlip.details.net_sal}
                            </td>
                          </tr>
                        </table>

                        <div className="footer">
                          Note: This is a Computer Generated Slip and does not
                          require a signature.
                        </div>
                      </div>
                    </div>
                    <div className="button float-right">
                      <button
                        type="button"
                        onClick={downloadPdf}
                        className="btn btn-sm btn-primary float-right"
                        style={{ border: "none" }}
                      >
                        Download
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : null}
          </div>
        </div>
      </main>
    </>
  );
};

export default Payroll;
