import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import $ from "jquery";
import axios, { all } from "axios";
import { useDispatch } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { Link } from "react-router-dom";
import { setSelectedEmployeePersonalInformation } from "../../reduxStorage/selectedEmployeeInformation";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import { useSelector } from "react-redux";
import "./ManageEmployee.css";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

let pageLoadCount = 0;

function ManageEmployee() {
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [homeRoute, setHomeRoute] = useState("");

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const joiningdateref = useRef(null);
  const dateOfBirthref = useRef(null);
  const today = new Date().toISOString().split("T")[0];
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const [employees, setEmployees] = useState([]);
  const [sendOnboardingLink, setSendOnboardingLink] = useState(false);
  const [joiningDate, setJoiningDate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [overlay, setOverlay] = useState(false);
  const [payrolls, setAllPayrolls] = useState([]);
  const [inProgressEmployees, setInProgressEmployees] = useState([]);
  const [completedEmployees, setCompletedEmployees] = useState([]);
  const [openEmployees, setOpenEmployees] = useState([]);
  const [sectionsDisplay, setSectionsDisplay] = useState(false);
  const [deleteEmployeeId, setDeleteEmployeeId] = useState("");
  const [employeeCount, setEmployeeCount] = useState("");

  const [sectionEditDisplay, setSectionEditDisplay] = useState(false);
  const [cardName, setCardName] = useState("card1");
  const [tableData, setTableData] = useState([]);
  const [errors, setErrors] = useState({});
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const inputNameReference = useRef(null);
  const inputEmailReference = useRef(null);
  const inputContactReference = useRef(null);
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedManager, setSelectedManager] = useState("");
  const [selectedGender, setSelectedGender] = useState("Male");
  const [selectedRole, setSelectedRole] = useState("");
  const [locations, setLocations] = useState([]);
  const [allDepartment, setAllDepartment] = useState([]);
  const [allManager, setAllManager] = useState("");
  const [selectedEmployeeId, setSelectedEmployeeId] = useState("");
  const [allRolesList, setAllRolesList] = useState([]);
  const [showActive, setShowActive] = useState(true);
  const [allDeptManager, setAllDeptManager] = useState([]);
  const [userManager, setUserManager] = useState(null);
  const [cardHeaderText, setCardHeaderText] = useState(
    "Total Employees List",
    "card1"
  );
  const [isActiveUser, setIsActiveUser] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 5;
  const setDepartment = (e) => {
    const department = e.target.value;
    setSelectedDepartment(department);
    GetAllManager(department);
  };
  const setRole = (e) => {
    const role = e.target.value;
    // console.log("role --->>>>>", role);

    setSelectedRole(role);
    getAllRolesList(role);
  };
  const [employee, setEmployee] = useState({
    name: "",
    email: "",
    contact: "",
    department: "",
    employmentType: "",
    designation: "",
    joiningDate: "",
    manager: "",
    createdBy: "",
  });
  const [editEmployeeData, setEditEmployeeData] = useState({
    empId: "",
    firstName: "",
    lastName: "",
    userName: "",
    officialEmail: "",
    designation: "",
    role: "",
    payrollTempId: "",
    mobile: "",
    dateOfBirth: "",
    joiningDate: "",
    locationId: "",
    assignedCTC: "",
    isProbation: "",
  });

  const changeActiveUser = (event) => {
    setIsActiveUser(event.target.checked);
  };
  localStorage.setItem("isEmployeeActive", "true");
  const tooltipContent = {
    card1:
      "This card table data is for viewing and managing all employees in the organization. You can view, edit and remove the employee by using the action buttons in the table.",
    card2:
      "This card table data displays employees who are currently onboarding.",
    card3:
      "This card table data shows employees whose onboarding is in progress.",
    card4:
      "This card table data shows employees who have completed the onboarding process. You can view the employee data and make the action that accept or reject the employee onboarding process.",
  };

  useEffect(() => {
    // console.log("personalInfo--->", personalInfo);
    if(personalInfo.userRole == "Administrator") {
      setHomeRoute("/form-builder");
    } else {
      setHomeRoute("/manage-employee");
    }
    if(pageLoadCount == 0) {
      //   window.initDataTable();
      pageLoadCount++;
    }
    GetAllDepartments();
    GetAllManager();
    showEmployees();
    GetPayrollTemplates();
    GetAllLocation();
    getAllRolesList();
  }, []);

  useEffect(() => {
    if(showActive) {
      setTableData(employees.filter((emp) => emp.isActive));
    } else {
      setTableData(employees.filter((emp) => !emp.isActive));
    }
  }, [showActive, employees]);

  const handleClose = () => {
    setEmployee({
      name: "",
      email: "",
      contact: "",
    });
    setSelectedManager("");
    setSelectedDepartment("");
    setEditEmployeeData("");
    setErrors({});
    setError(null);
    if(inputContactReference.current) {
      inputContactReference.current.classList.remove("is-invalid");
    }
    if(inputEmailReference.current) {
      inputEmailReference.current.classList.remove("is-invalid");
    }
    if(inputNameReference.current) {
      inputNameReference.current.classList.remove("is-invalid");
    }

    // console.log("After reset, error:", error);
  };
  const getAllRolesList = () => {
    setIsLoaderActive(true);

    axios
      .get(
        config.API_URL + "AuthMaster/GetAllRoles?ClientId=" + config.ClientId,
        {
          headers: config.headers2,
        }
      )
      .then((response) => {
        if(response.status == 200) {
          if(response.data.success == "success") {
            if(response.data.data.length > 0) {
              setAllRolesList(response.data.data);
            }
          } else {
            toast.error(response.data.message);
          }
        } else if(response.data.status.status == 500) {
          toast.error("Invalid username or password");
        }
      })
      .catch((error) => {
        toast.error("Please try again later.");
      })
      .finally(() => {
        setIsLoaderActive(false);
      });
  };
  const GetAllLocation = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/LocationMaster/GetAllLocations`
      );
      if(response.data.success === "True") {
        // console.log("All locations:", response.data.data);
        setLocations(response.data.data || []); // Store data in state
      } else {
        console.error("Error fetching Locations:");
      }
    } catch(error) {
      console.error("Error fetching Locations:", error);
    }
  };
  const GetAllDepartments = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Department/GetAllDepartments`
      );
      if(response.data.success == "True") {
        // console.log("all department--->", response.data.data);

        setAllDepartment(response.data.data || []); // Store data in state
      } else {
        console.error("Error fetching departments:");
      }
    } catch(error) {
      console.error("Error fetching departments:");
    }
  };
  const GetAllManagerByDept = async (department) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllManagersByDept`,
        {
          params: { deptName: department },
        }
      );
      if(response.data.success == "success") {
        setAllManager(response.data.data || []);
      } else {
        console.error("Error fetching Manager:");
      }
    } catch(error) {
      console.error("Error fetching Manager:");
    }
  };
  const GetAllManager = async (department) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllManagers`
      );
      if(response.data.success == "success") {
        // console.log("All manager list-->", response.data.data);

        setAllDeptManager(response.data.data || []);
        //setAllManager(response.data.data || []);
      } else {
        console.error("Error fetching Manager:");
      }
    } catch(error) {
      console.error("Error fetching Manager:");
    }
  };
  const postFormData = async (formData) => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeData/PostEmployeeData`,
        formData
      );
      // console.log("response from postFormData----->", response);
      if(response.data.success === "True") {
        toast.success("Employee added successfully!");
        handleClose();
        showEmployees();
        setSectionsDisplay(false);
        setIsLoaderActive(false);
        return true;
      } else {
        // handleClose();
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch(error) {
      toast.error("Failed to save employee data.");
      setIsLoaderActive(false);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const postEditEmployeeData = async (formData) => {
    setIsLoaderActive(true);
    // debugger;
    // console.log("data----------------->", formData);
    try {
      const response = await axios.post(
        //   `${config.apiEndPoint}/EmployeeData/editEmployeeData?empId=${formData.empId}&name=${formData.employeeName}&email=${formData.email}&name=${formData.employeeName}&designation=${formData.designation}&departmentId=${formData.department}&assignedManager=${formData.assignedManager}&mobile=${formData.mobile}&locationId=${formData.locationId}&assignedCTC=${formData.assignedCTC}&payrollTempId=${formData.payrollTempId}&isProbation=${formData.isProbation}&joiningDate=${formData.joiningDate}`
        // );

        `${config.apiEndPoint}/AuthMaster/UpdateUser1`,
        formData
      );

      // console.log("response from postEditEmployeeData----->", response.data);
      if(response.data.success === "success") {
        toast.success("Employee Updated Successfully!");
        handleClose();
        showEmployees();
        setSectionEditDisplay(false);
        setSectionsDisplay(false);
        setIsLoaderActive(false);
        return true;
      } else {
        // handleClose();
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch(error) {
      toast.error("Failed to save employee data.");
      setIsLoaderActive(false);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const hideModal = async () => {
    window.$("#deleteModal").modal("hide");
  };
  const deleteEmployee = async (empInfoId) => {
    // console.log("====================================");
    // console.log("empInfoId", empInfoId);
    // console.log("====================================");
    try {
      window.$("#deleteModal").modal({ backdrop: "static", keyboard: false });
      window.$("#deleteModal").modal("show");
      setDeleteEmployeeId(empInfoId);
    } catch(error) {
      console.error(
        "Error deleting employee:",
        error.response ? error.response.data : error.message
      );
    }
  };


  const ReonboardEmployee = async (empId) => {
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/AuthMaster/ActivateToDeactiveUser?userID=${empId}`
      );
      if(response.data.success == "True") {

        toast.success(response.data.message);
        showEmployees();
        setIsLoaderActive(false);
      } else {
        toast.error(response.data.message);
        setTimeout(() => {
          showEmployees();
        }, 1000);
        setIsLoaderActive(false);
        // 
      }
    } catch(error) {
      console.error(
        "Error reonboarding employee:",
        error.response ? error.response.data : error.message
      );
    }
  };
  const confirmDeleteEmployee = async () => {
    setIsLoaderActive(true);

    const response = await axios.post(
      `${config.apiEndPoint}/EmployeeData/deleteEmployee?EmpId=${deleteEmployeeId}`
    );
    // console.log(response);

    if(response.data.success == "True") {
      window.$("#deleteModal").modal("hide");
      setDeleteEmployeeId("");
      toast.success(response.data.message);
      showEmployees();
      setIsLoaderActive(false);
    } else {
      toast.error(response.message);
      setIsLoaderActive(false);
    }
    setIsLoaderActive(false);
  };
  const showEmployees = async () => {
    setIsLoaderActive(true);
    setOverlay(true);
    try {
      setLoading(true);
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllEmployeeDetails`
      );

      if(response.data.success === "success") {
        if(response.data.data) {
          localStorage.setItem("setShowAcceptRejectButton", "f");
          const filteredEmployees = response.data.data.filter(
            (emp) =>
              emp.onboardingStatus == null ||
              emp.onboardingStatus == "direct" ||
              emp.hrStatus?.toLowerCase() === "approved"
          );
          const openEmployees = response.data.data.filter(
            (emp) => emp.onboardingStatus?.toLowerCase() == "open"
          );
          const inProgressEmployees = response.data.data.filter(
            (emp) => emp.onboardingStatus?.toLowerCase() == "in progress"
          );
          const completedEmployees = response.data.data.filter(
            (emp) =>
              emp.onboardingStatus?.toLowerCase() == "completed" &&
              emp.hrStatus?.toLowerCase() != "approved"
          );

          const empCnt = filteredEmployees.filter(
            (emp) =>
              emp.isActive == true
          );
          setEmployeeCount(empCnt.length);
          setEmployees(filteredEmployees);
          setOpenEmployees(openEmployees);
          setInProgressEmployees(inProgressEmployees);
          setCompletedEmployees(completedEmployees);
          setTableData(filteredEmployees);
          // console.log("filteredEmployees---->", filteredEmployees);
          // console.log("openEmployees---->", openEmployees);
          // console.log("inProgressEmployees---->", inProgressEmployees);
          // console.log("completedEmployees---->", completedEmployees);
        }
        setIsLoaderActive(false);
        setTimeout(() => {
          window.initDataTable();
        }, 1000);
      } else {
        setError("Failed to fetch employees");
        setIsLoaderActive(false);
      }
    } catch(error) {
      setError("Error fetching employee data");
      console.error("Error fetching employee data:", error);
    } finally {
      setLoading(false);
      setOverlay(true);
      setIsLoaderActive(false);
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    // alert(e.target);

    setEmployee((prev) => ({ ...prev, [name]: value }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
  };
  const handleEmployeeDetailsEditChange = (e) => {
    const { name, value } = e.target;
    console.log("name--->", name);
    console.log("value--->", value);

    setEditEmployeeData((prev) => ({ ...prev, [name]: value }));
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: "",
    }));
    // console.log(name, value, "Name--->>>>, VAlue---->>>>>");

    setIsLoaderActive(false);
  };
  const AddNewEmployeeClickHandler = (e) => {
    setSectionsDisplay(true);
    // e.preventDefault();
  };

  const toggleEmployeeView = () => {
    setShowActive((prev) => !prev);
    if(showActive) {
      const inactiveEmployees = employees.filter((emp) => !emp.isActive);
      localStorage.setItem("isEmployeeActive", "false");
      setTableData(inactiveEmployees);
    } else {
      setTableData(employees);
      localStorage.setItem("isEmployeeActive", "true");
    }
  };

  const [searchText, setSearchText] = useState("");

  // Table Search
  const filteredEmployees = tableData.filter(
    (emp) => emp.isActive === showActive
  );
  const searchedEmployees = filteredEmployees.filter((row) =>
    Object.values(row).some(
      (val) =>
        val && val.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  // Pagination Calculation
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = searchedEmployees.slice(indexOfFirstRow, indexOfLastRow);
  // console.log("currentRows--->", currentRows);

  const totalPages = Math.ceil(searchedEmployees.length / rowsPerPage);

  // Calculate the range of displayed entries
  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, searchedEmployees.length);

  // Page Change Handler
  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const EditEmployeeClickHandler = (employeeData) => {
    // console.log(employeeData, "Selected Employee Data---->");
    setSelectedEmployeeId(employeeData.userID);
    GetAllManager();
    getAllRolesList(employeeData.role);

    const parseDate = (dateString) => {
      if(!dateString || typeof dateString !== "string") return null;

      const dateParts = dateString.split("-");
      if(dateParts.length !== 3) return null;

      const [day, month, year] = dateParts.map((part) => parseInt(part, 10));

      if(isNaN(day) || isNaN(month) || isNaN(year)) return null;

      const formattedDate = `${year}-${String(month).padStart(2, "0")}-${String(
        day
      ).padStart(2, "0")}`;
      const dateObj = new Date(formattedDate);

      return isNaN(dateObj.getTime()) ? null : dateObj;
    };

    const validDateOfBirth = employeeData.dateOfBirth
      ? new Date(parseDate(employeeData.dateOfBirth))
        .toISOString()
        .split("T")[0]
      : "";
    const validJoiningDate = employeeData.joiningDate
      ? parseDate(employeeData.joiningDate)?.toISOString().split("T")[0] || ""
      : "";

    setEditEmployeeData({
      ...employeeData,
      dateOfBirth: validDateOfBirth,
      joiningDate: validJoiningDate,
      mobile: employeeData.contactNumber,
      payrollTempId: employeeData.payrollTemplateId,
      locationId: employeeData.location,
      isProbation: employeeData.isProbation ? "true" : "false",
    });
    // console.log("Selected Employee Data---->", employeeData);

    var filteredManagers = "";
    if(employeeData.assignedManager != null) {
      // console.log("allManager--->", allDeptManager);
      filteredManagers = (
        Array.isArray(allDeptManager) ? allDeptManager : []
      ).filter(
        (manager) =>
          manager.userID.toLowerCase() ===
          employeeData.assignedManager.toLowerCase()
      );
    }

    const userManagerr =
      filteredManagers.length > 0 ? filteredManagers[0] : null;

    if(userManagerr && userManagerr.firstName != null) {
      setUserManager(userManagerr.userID);
      setSelectedManager(userManagerr.userID);
    }
    setSelectedRole(employeeData.roleID);
    setSelectedDepartment(employeeData.department);
    setSelectedManager(employeeData.assignedManager);
    setUserManager(employeeData.assignedManager);
    setSectionsDisplay(false);
    setSectionEditDisplay(true);
  };
  const viewEmployeeDetailsClickHandler = (employeeData) => {
    // console.log(employeeData.empId);

    // console.log(employeeData, "----- view empData----<<<<<");

    localStorage.setItem(
      "isDeleted",
      employeeData.isDelete ? employeeData.isDelete : "false"
    );
    dispatch(
      setSelectedEmployeePersonalInformation({
        selectedEmployeeID: employeeData.userID,
        firstName: employeeData.firstName,
        email: employeeData.email,
        role: employeeData.role,
        department: employeeData.department,
        mobile: employeeData.contactNumber,
        isProbation: employeeData.isProbation,
        gender: employeeData.gender,
        payrollTempId: employeeData.payrollTempId,
        location: employeeData.location,
        roleID: employeeData.role,
        contactNumber: employeeData.contactNumber,
        assignedManager: employeeData.assignedManager
          ? employeeData.assignedManager
          : "NA",
        plant: editEmployeeData.locationId,
        dateOfBirth: new Date(employeeData.dateOfBirth)
          .toLocaleDateString("en-GB")
          .replace(/\//g, "-"),
        joiningDate: new Date(editEmployeeData.joiningDate)
          .toLocaleDateString("en-GB")
          .replace(/\//g, "-"),
      })
    );
    setTimeout(() => {
      navigate("/employee-details", { replace: true });
    }, 500);
  };
  const removeHighlight = (e) => {
    inputNameReference.current.blur();
    inputEmailReference.current.blur();
    inputContactReference.current.blur();

    if(inputNameReference.current.classList.contains("is-invalid")) {
      inputNameReference.current.classList.remove("is-invalid");
    }
    if(inputEmailReference.current.classList.contains("is-invalid")) {
      inputEmailReference.current.classList.remove("is-invalid");
    }
    if(inputContactReference.current.classList.contains("is-invalid")) {
      inputContactReference.current.classList.remove("is-invalid");
    }
  };
  const handleAddNewEmployee = (e) => {
    removeHighlight();
    const newErrors = {};
    if(!employee.name.trim()) {
      inputNameReference.current.focus();
      inputNameReference.current.classList.add("is-invalid");
      toast.error("Please Enter Employee Name");
      setIsLoaderActive(false);
      return;
    }
    if(!employee.email.trim()) {
      inputEmailReference.current.focus();
      inputEmailReference.current.classList.add("is-invalid");
      toast.error("Please Enter a valid Email.");
      setIsLoaderActive(false);
      return;
    } else if(!/\S+@\S+\.\S+/.test(employee.email)) {
      inputEmailReference.current.focus();
      inputEmailReference.current.classList.add("is-invalid");
      toast.error("Please Enter a valid email.");
      setIsLoaderActive(false);
      return;
    }
    if(!employee.contact.trim()) {
      inputContactReference.current.focus();
      inputContactReference.current.classList.add("is-invalid");
      toast.error("Please enter a valid contact number.");
      setIsLoaderActive(false);
      return;
    } else if(!/^\d{10}$/.test(employee.contact)) {
      inputContactReference.current.focus();
      inputContactReference.current.classList.add("is-invalid");
      toast.error("Please enter a valid contact number.");
      setIsLoaderActive(false);
      return;
    }
    setErrors(newErrors);

    // Stop submission if there are validation errors
    if(Object.keys(newErrors).length > 0) return;

    // Prepare data for API submission
    const formData = {
      employeeName: employee.name.trim(),
      email: employee.email.trim(),
      contactNumber: employee.contact.trim(),
      sendOnboardingLink: sendOnboardingLink,
      Gender: selectedGender,
      createdBy: personalInfo.userID,
    };

    postFormData(formData);
  };
  const handleEditEmployee = (e) => {
    const newErrors = {};
    // debugger;
    if(!editEmployeeData.firstName) {
      newErrors.firstName = "Employee first name is required.";
      setErrors(newErrors);
      toast.error("Employee first name is required.");
      setIsLoaderActive(false);
      return;
    }
    if(!editEmployeeData.lastName) {
      newErrors.lastName = "Employee last name is required.";
      setErrors(newErrors);
      toast.error("Employee last name is required.");
      setIsLoaderActive(false);
      return;
    }
    if(!editEmployeeData.userName) {
      newErrors.userName = "Employee user name is required.";
      setErrors(newErrors);
      toast.error("Employee user name is required.");
      setIsLoaderActive(false);
      return;
    }
    if(!editEmployeeData.officialEmail) {
      newErrors.email = "Email is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Email is required.");
      return;
    } else if(!/\S+@\S+\.\S+/.test(editEmployeeData.officialEmail)) {
      newErrors.email = "Enter a valid email.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Enter a valid email.");
      return;
    }
    if(!selectedRole && !editEmployeeData.role) {
      console.log(editEmployeeData, "role --->", selectedRole);
      newErrors.role = "Role is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Role is required.");
      return;
    }
    if(!editEmployeeData.designation || !editEmployeeData.designation) {
      newErrors.designation = "Designation is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Designation is required.");
      return;
    }
    if(!editEmployeeData.mobile) {
      newErrors.mobile = "Contact number is required.";
      toast.error("Contact number is required.");
      setIsLoaderActive(false);
      setErrors(newErrors);
      return;
    } else if(!/^\d{10}$/.test(editEmployeeData.mobile)) {
      newErrors.mobile = "Please enter a valid contact number.";
      toast.error("Please enter a valid contact number.");
      setIsLoaderActive(false);
      setErrors(newErrors);
      return;
    }
    if(!editEmployeeData.payrollTempId) {
      newErrors.payrollTempId = "Payroll template is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Payroll template is required.");
      return;
    }
    if(!editEmployeeData.assignedCTC) {
      newErrors.assignedCTC = "Assigned CTC is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Assigned CTC is required.");
      return;
    }
    if(!editEmployeeData.locationId) {
      newErrors.locationId = "Location is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Location is required.");
      return;
    }
    if(!editEmployeeData.dateOfBirth) {
      newErrors.dateOfBirth = "Date Of Birth is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Date Of Birth is required.");
      return;
    }
    if(!editEmployeeData.joiningDate) {
      newErrors.joiningDate = "Joining date is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Joining date is required.");
      return;
    }
    if(
      editEmployeeData.isProbation === undefined ||
      editEmployeeData.isProbation === ""
    ) {
      newErrors.isProbation = "Probation is required.";
      setErrors(newErrors);
      setIsLoaderActive(false);
      toast.error("Probation is required.");
      return;
    }
    setErrors(newErrors);

    if(Object.keys(newErrors).length > 0) return;

    const formData = {
      UserID: editEmployeeData.userID,
      firstName: editEmployeeData.firstName,
      userName: editEmployeeData.userName,
      lastName: editEmployeeData.lastName,
      email: editEmployeeData.officialEmail,
      roleID: selectedRole || editEmployeeData.role,
      designation: editEmployeeData.designation,
      department: selectedDepartment || editEmployeeData.department || "",
      assignedCTC: editEmployeeData.assignedCTC,
      locationId: editEmployeeData.locationId,
      payrollTempId: editEmployeeData.payrollTempId,
      manager:
        selectedManager ||
        (editEmployeeData.assignedManager
          ? editEmployeeData.assignedManager
          : null),
      contactNumber: editEmployeeData.mobile,
      isProbation: editEmployeeData.isProbation == "true" ? true : false,
      probationPeriod: editEmployeeData.probationPeriod,
      dateOfBirth: new Date(editEmployeeData.dateOfBirth)
        .toLocaleDateString("en-GB")
        .replace(/\//g, "-"),
      joiningDate: new Date(editEmployeeData.joiningDate)
        .toLocaleDateString("en-GB")
        .replace(/\//g, "-"),
      isActive: isActiveUser,
    };

    postEditEmployeeData(formData);
  };

  const CancelAddNewEmployeeClickHandler = () => {
    setSectionsDisplay(false);
    setSelectedDepartment("");
    setSelectedManager("");
    setUserManager("");
    setSectionEditDisplay(false);
    setSendOnboardingLink(false);
    handleClose();
  };
  // const onTilesCardClickHandler = (getHeaderValue, getCardClass) => {
  //   setIsLoaderActive(true);
  //   const nextLoaderValue = true;

  //   CancelAddNewEmployeeClickHandler();
  //   hideModal();
  //   setCardHeaderText(getHeaderValue);
  //   setCardName(getCardClass);
  //   $(".small-box").removeClass("tilesCardActive");
  //   setTimeout(() => {
  //     $("." + getCardClass).addClass("tilesCardActive");
  //   }, 500);

  //   window.initDestroyDataTableFuncation();
  //   setTimeout(() => {
  //     if(getCardClass == "card1") {
  //       setTableData(employees);
  //       localStorage.setItem("setShowAcceptRejectButton", "f");
  //     } else if(getCardClass == "card2") {
  //       setTableData(openEmployees);
  //       localStorage.setItem("setShowAcceptRejectButton", "f");
  //     } else if(getCardClass == "card3") {
  //       setTableData(inProgressEmployees);
  //       localStorage.setItem("setShowAcceptRejectButton", "f");
  //     } else if(getCardClass == "card4") {
  //       setTableData(completedEmployees);
  //       localStorage.setItem("setShowAcceptRejectButton", "t");
  //     }
  //   }, 500);

  //   setTimeout(() => {
  //     window.initAgainDestroyDataTableFuncation();
  //   }, 1000);
  //   setIsLoaderActive(false);
  // };


  const onTilesCardClickHandler = async (getHeaderValue, getCardClass) => {
    setIsLoaderActive(true);

    CancelAddNewEmployeeClickHandler();
    hideModal();
    setCardHeaderText(getHeaderValue);
    setCardName(getCardClass);
    $(".small-box").removeClass("tilesCardActive");

    await new Promise((res) => setTimeout(res, 500));
    $("." + getCardClass).addClass("tilesCardActive");

    window.initDestroyDataTableFuncation();

    await new Promise((res) => setTimeout(res, 500));
    if(getCardClass === "card1") {
      setTableData(employees);
      localStorage.setItem("setShowAcceptRejectButton", "f");
    } else if(getCardClass === "card2") {
      setTableData(openEmployees);
      localStorage.setItem("setShowAcceptRejectButton", "f");
    } else if(getCardClass === "card3") {
      setTableData(inProgressEmployees);
      localStorage.setItem("setShowAcceptRejectButton", "f");
    } else if(getCardClass === "card4") {
      setTableData(completedEmployees);
      localStorage.setItem("setShowAcceptRejectButton", "t");
    }

    window.initAgainDestroyDataTableFuncation();

    setIsLoaderActive(false);
  };



  const GetPayrollTemplates = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Payroll/GetTempalates`
      );
      if(response.data.success == "True") {
        setAllPayrolls(response.data.data || []);
      } else {
        console.error("Error fetching Payroll:");
      }
    } catch(error) {
      console.error("Error fetching Payroll:");
    }
  };

  const exportToExcel = () => {
    // Dynamically build data from what's actually displayed in the table
    const filteredData = currentRows.map((data) => {
      const empId =
        cardName === "card1"
          ? `ITS-${allDepartment.find(dep => dep.departmentID == data.department)?.departmentName.slice(0, 4) || "NA"}-${new Date().getFullYear().toString().slice(-2)}-${String(data.employeeInfoId).padStart(3, "0")}`
          : undefined;

      const manager = allDeptManager?.find(
        (mgr) => mgr.userID === data.assignedManager?.toLowerCase()
      );
      const assignedManager = manager
        ? `${manager.firstName} ${manager.lastName}`
        : "NA";

      const probationEnd = cardName === "card1"
        ? data.probationPeriod
          ? (() => {
            const monthsToAdd = Number(data.probationPeriod);
            const parts = data.joiningDate?.split("-") || [];
            if(parts.length === 3) {
              const [day, month, year] = parts.map(p => parseInt(p, 10));
              const formatted = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
              const joinDate = new Date(formatted);
              joinDate.setMonth(joinDate.getMonth() + monthsToAdd);
              return `${String(joinDate.getDate()).padStart(2, "0")}-${String(joinDate.getMonth() + 1).padStart(2, "0")}-${joinDate.getFullYear()}`;
            }
            return "Invalid";
          })()
          : "Permanent"
        : undefined;

      const row = {
        "Employee Name": data.firstName,
        "Email": data.officialEmail || data.email || "NA",
        "Designation": data.designation || "NA",
        "Date Of Joining": data.joiningDate ? data.joiningDate.split("T")[0] : "NA",
        "Assigned Manager": assignedManager,
      };

      if(cardName === "card1") {
        row["Employee ID"] = empId;
        row["Probation End Date"] = probationEnd;
      }

      return row;
    });

    const worksheet = XLSX.utils.json_to_sheet(filteredData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Employees");

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });

    saveAs(data, "EmployeeData.xlsx");
  };

  // Export to CSV
  const exportToCSV = () => {
    let headers = ["Employee Name", "Email", "Designation", "Date Of Joining", "Assigned Manager"];
    if(cardName === "card1") {
      headers.unshift("Employee ID");
      headers.push("Probation End Date");
    }

    let csvContent = headers.join(",") + "\n";

    currentRows.forEach((data) => {
      const manager = allDeptManager?.find(
        (mgr) => mgr.userID === data.assignedManager?.toLowerCase()
      );
      const assignedManager = manager ? `${manager.firstName} ${manager.lastName}` : "NA";

      const rowData = [
        data.firstName,
        data.officialEmail || data.email || "NA",
        data.designation || "NA",
        data.joiningDate ? data.joiningDate.split("T")[0] : "NA",
        assignedManager,
      ];

      if(cardName === "card1") {
        const empId = `ITS-${allDepartment.find(dep => dep.departmentID == data.department)?.departmentName.slice(0, 4) || "NA"}-${new Date().getFullYear().toString().slice(-2)}-${String(data.employeeInfoId).padStart(3, "0")}`;
        const probation = data.probationPeriod
          ? (() => {
            const parts = data.joiningDate?.split("-") || [];
            if(parts.length !== 3) return "Invalid";
            const [day, month, year] = parts.map(Number);
            const joinDate = new Date(`${year}-${month}-${day}`);
            joinDate.setMonth(joinDate.getMonth() + Number(data.probationPeriod));
            return `${String(joinDate.getDate()).padStart(2, "0")}-${String(joinDate.getMonth() + 1).padStart(2, "0")}-${joinDate.getFullYear()}`;
          })()
          : "Permanent";

        rowData.unshift(empId);
        rowData.push(probation);
      }

      csvContent += rowData.join(",") + "\n";
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "EmployeeData.csv");
  };

  // Export to PDF
  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Employee List", 14, 10);

    const headers = ["Employee Name", "Email", "Designation", "Date Of Joining", "Assigned Manager"];
    if(cardName === "card1") {
      headers.unshift("Employee ID");
      headers.push("Probation End Date");
    }

    const body = currentRows.map((data) => {
      const manager = allDeptManager?.find(
        (mgr) => mgr.userID === data.assignedManager?.toLowerCase()
      );
      const assignedManager = manager ? `${manager.firstName} ${manager.lastName}` : "NA";

      const row = [
        data.firstName,
        data.officialEmail || data.email || "NA",
        data.designation || "NA",
        data.joiningDate ? data.joiningDate.split("T")[0] : "NA",
        assignedManager,
      ];

      if(cardName === "card1") {
        const empId = `ITS-${allDepartment.find(dep => dep.departmentID == data.department)?.departmentName.slice(0, 4) || "NA"}-${new Date().getFullYear().toString().slice(-2)}-${String(data.employeeInfoId).padStart(3, "0")}`;
        const probation = data.probationPeriod
          ? (() => {
            const parts = data.joiningDate?.split("-") || [];
            if(parts.length !== 3) return "Invalid";
            const [day, month, year] = parts.map(Number);
            const joinDate = new Date(`${year}-${month}-${day}`);
            joinDate.setMonth(joinDate.getMonth() + Number(data.probationPeriod));
            return `${String(joinDate.getDate()).padStart(2, "0")}-${String(joinDate.getMonth() + 1).padStart(2, "0")}-${joinDate.getFullYear()}`;
          })()
          : "Permanent";

        row.unshift(empId);
        row.push(probation);
      }

      return row;
    });

    autoTable(doc, {
      head: [headers],
      body: body,
    });

    doc.save("EmployeeData.pdf");
  };

  // Print Table
  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print Employee Data</title></head><body>");
    printWindow.document.write("<table border='1' cellspacing='0' cellpadding='5'><tr>");

    if(cardName === "card1") {
      printWindow.document.write("<th>Employee ID</th>");
    }

    printWindow.document.write(`
    <th>Employee Name</th>
    <th>Email</th>
    <th>Designation</th>
    <th>Date Of Joining</th>
    <th>Assigned Manager</th>
  `);

    if(cardName === "card1") {
      printWindow.document.write("<th>Probation End Date</th>");
    }

    printWindow.document.write("</tr>");

    currentRows.forEach((data) => {
      const manager = allDeptManager?.find(
        (mgr) => mgr.userID === data.assignedManager?.toLowerCase()
      );
      const assignedManager = manager ? `${manager.firstName} ${manager.lastName}` : "NA";

      printWindow.document.write("<tr>");
      if(cardName === "card1") {
        const empId = `ITS-${allDepartment.find(dep => dep.departmentID == data.department)?.departmentName.slice(0, 4) || "NA"}-${new Date().getFullYear().toString().slice(-2)}-${String(data.employeeInfoId).padStart(3, "0")}`;
        printWindow.document.write(`<td>${empId}</td>`);
      }

      printWindow.document.write(`
      <td>${data.firstName}</td>
      <td>${data.officialEmail || data.email || "NA"}</td>
      <td>${data.designation || "NA"}</td>
      <td>${data.joiningDate ? data.joiningDate.split("T")[0] : "NA"}</td>
      <td>${assignedManager}</td>
    `);

      if(cardName === "card1") {
        const probation = data.probationPeriod
          ? (() => {
            const parts = data.joiningDate?.split("-") || [];
            if(parts.length !== 3) return "Invalid";
            const [day, month, year] = parts.map(Number);
            const joinDate = new Date(`${year}-${month}-${day}`);
            joinDate.setMonth(joinDate.getMonth() + Number(data.probationPeriod));
            return `${String(joinDate.getDate()).padStart(2, "0")}-${String(joinDate.getMonth() + 1).padStart(2, "0")}-${joinDate.getFullYear()}`;
          })()
          : "Permanent";
        printWindow.document.write(`<td>${probation}</td>`);
      }

      printWindow.document.write("</tr>");
    });

    printWindow.document.write("</table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">Employee Page </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to={homeRoute}>Home</Link>
                </li>
                <li className="breadcrumb-item active">Employee page </li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <div className="container-fluid">
        <div className="col-md-12">
          {/* First Card Section */}
          <div className="row">
            <div
              className="col-lg-3 col-3"
              onClick={() => {
                onTilesCardClickHandler("Total Employees List", "card1");
                setShowActive(true);
              }}
            >
              <div className="small-box bg-info-card1 card1 tilesCardActive">
                <div className="inner">
                  <h3 className="ng-binding">{employeeCount}</h3>
                  <p>Total Employee</p>
                </div>
                <div className="icon">
                  <i className="fas fa-dragon img-fluid"></i>
                </div>
                <div className="go-corner" href="#">
                  <div className="go-arrow">→</div>
                </div>
              </div>
            </div>
            <div
              className="col-lg-3 col-3"
              onClick={() => {
                onTilesCardClickHandler(
                  "No of On Boarding Employees List",
                  "card2"
                );
                setShowActive(true);
              }}
            >
              <div className="small-box bg-info-card4 card2">
                <div className="inner">
                  <h3 className="ng-binding">{openEmployees.length}</h3>
                  <p>No of on boarding</p>
                </div>
                <div className="icon">
                  <i className="fas fa-user-tie img-fluid"></i>
                </div>
                <div className="go-corner" href="#">
                  <div className="go-arrow">→</div>
                </div>
              </div>
            </div>
            <div
              className="col-lg-3 col-3"
              onClick={() => {
                onTilesCardClickHandler(
                  "Onboard In Progress Employees List",
                  "card3"
                );
                setShowActive(true);
              }}
            >
              <div className="small-box bg-info-card3 card3">
                <div className="inner">
                  <h3 className="ng-binding">{inProgressEmployees.length}</h3>
                  <p>Onboard in progress</p>
                </div>
                <div className="icon">
                  <i className="fas fa-user-plus img-fluid"></i>
                </div>
                <div className="go-corner" href="#">
                  <div className="go-arrow">→</div>
                </div>
              </div>
            </div>
            <div
              className="col-lg-3 col-3"
              onClick={() => {
                onTilesCardClickHandler(
                  "Onboard Completed Employees List",
                  "card4"
                );
                setShowActive(true);
              }}
            >
              <div className="small-box bg-info-card5 card4">
                <div className="inner">
                  <h3 className="ng-binding">{completedEmployees.length}</h3>
                  <p>Onboard form submitted</p>
                </div>
                <div className="icon">
                  <i className="fas fa-user-check img-fluid"></i>
                </div>
                <div className="go-corner" href="#">
                  <div className="go-arrow">→</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container-fluid">
        <div className="col-md-12">
          <div className="card card-outline card-primary">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col-md-8">
                  {sectionsDisplay === false && sectionEditDisplay === false ? (
                    <>
                      <h3 className="card-title">
                        Employees List{" "}
                        <em style={{ fontSize: "12px" }}>
                          ( {cardHeaderText} )
                          <span
                            hover-tooltip={tooltipContent[cardName]}
                            tooltip-position="bottom"
                          >
                            <i
                              className="fas fa-info-circle m-1"
                              style={{ color: "rgb(0 0 0 / 51%)" }}
                            ></i>
                          </span>
                        </em>
                      </h3>
                    </>
                  ) : sectionEditDisplay === true ? (
                    <h3 className="card-title">
                      Edit Employee{" "}
                      <em style={{ fontSize: "12px" }}>
                        ( Add details of an employee )
                      </em>
                      <span
                        hover-tooltip="This process will edit the employee's basic details and update their department, designation, and assigned manager, streamlining the information management."
                        tooltip-position="bottom"
                      >
                        <i
                          className="fas fa-info-circle ml-2"
                          style={{ color: "rgb(0 0 0 / 51%)" }}
                        ></i>
                      </span>
                    </h3>
                  ) : (
                    <h3 className="card-title">
                      Add New Employee{" "}
                      <em style={{ fontSize: "12px" }}>
                        ( Add details of an employee )
                      </em>
                      <span
                        hover-tooltip="This process allows for adding a new user by entering their full name, personal email ID, and contact number. After submitting these details, an onboarding link is sent to their personal email. When the user clicks the link, they are redirected to the onboarding page to provide further details and upload necessary documents."
                        tooltip-position="bottom"
                      >
                        <i
                          className="fas fa-info-circle ml-2"
                          style={{ color: "rgb(0 0 0 / 51%)" }}
                        ></i>
                      </span>
                    </h3>
                  )}
                </div>

                <div className="col-md-4 float-right">
                  <div className="card-tools float-right mt-1">
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                  {sectionsDisplay == false && sectionEditDisplay == false ? (
                    <>
                      <button
                        className="btn btn-sm float-right btn-primary mr-1"
                        onClick={() => AddNewEmployeeClickHandler()}
                        type="button"
                      >
                        Add New Employee
                      </button>
                      <button
                        className={`btn btn-sm float-right ${showActive ? "btn-warning" : "btn-warning"
                          } mr-2`}
                        onClick={toggleEmployeeView}
                        type="button"
                      >
                        {showActive ? "Show Inactive" : "Show Active"}
                      </button>
                    </>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="card-body position-relative">
              {isLoaderActive && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgb(233 236 239 / 81%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 10,
                  }}
                >
                  <i
                    className="fas fa-sync-alt fa-spin"
                    style={{ fontSize: "2rem", color: "#333" }}
                  ></i>
                </div>
              )}
              {sectionsDisplay == false && sectionEditDisplay == false ? (
                <div id="listOfEmployees">
                  <div className="d-flex justify-content-between mb-2">
                    <div>
                      <button
                        className="btn btn-default btn-sm mr-1 exportBtn"
                        onClick={exportToCSV}
                      >
                        Export CSV
                      </button>
                      <button
                        className="btn btn-default btn-sm mr-1 exportBtn"
                        onClick={exportToExcel}
                      >
                        Export Excel
                      </button>
                      <button
                        className="btn btn-default btn-sm mr-1 exportBtn"
                        onClick={exportToPDF}
                      >
                        Export PDF
                      </button>
                      <button
                        className="btn btn-default btn-sm mr-1 exportBtn"
                        onClick={printTable}
                      >
                        Print
                      </button>
                    </div>

                    <input
                      type="text"
                      className="form-control form-control-sm w-25"
                      placeholder="Search..."
                      onChange={(e) => setSearchText(e.target.value)}
                    />
                  </div>
                  <table className="table table-bordered table-sm">
                    <thead>
                      <tr>

                        {cardName === "card1" && <th>Employee ID</th>}
                        <th className="text-nowrap">Employee Name</th>
                        <th>Email</th>
                        <th>Designation</th>
                        <th className="text-nowrap">Date Of Joining</th>
                        <th className="text-nowrap">Assigned Manager</th>
                        {cardName === "card1" && (
                          <th className="text-nowrap">Probation End Date</th>
                        )}{" "}
                        <th width="16%" className="">
                          Actions
                        </th>
                        {/* Show only in Total Employees tab */}
                      </tr>
                    </thead>
                    <tbody>
                      {currentRows.map((data, index) => (
                        <tr key={index}>

                          {cardName === "card1" && (
                            <td className="text-nowrap">
                              {"ITS-" +
                                (data.department
                                  ? allDepartment
                                    .find(
                                      (dep) =>
                                        dep.departmentID == data.department
                                    )
                                    ?.departmentName.slice(0, 4) +
                                  "-" +
                                  new Date()
                                    .getFullYear()
                                    .toString()
                                    .slice(-2)
                                  : "NA") +
                                "-" +
                                (data.employeeInfoId
                                  ? data.employeeInfoId
                                    .toString()
                                    .padStart(3, "0")
                                  : "NA")}
                            </td>
                          )}
                          <td className="text-nowrap">{data.firstName}</td>
                          <td className="text-nowrap">{data.officialEmail || data.email || "NA"}</td>
                          <td className="text-nowrap">{data.designation || "NA"}</td>
                          <td>
                            {data.joiningDate
                              ? data.joiningDate.split("T")[0]
                              : "NA"}
                          </td>
                          <td className="text-nowrap">
                            {(() => {
                              const manager = allDeptManager?.find(
                                (mgr) =>
                                  mgr.userID ===
                                  data.assignedManager?.toLowerCase()
                              );
                              return manager
                                ? `${manager.firstName} ${manager.lastName}`
                                : "NA";
                            })()}
                          </td>
                          {cardName === "card1" && (
                            <td>
                              {data.probationPeriod
                                ? (() => {
                                  try {
                                    // Ensure probationPeriod is a valid number
                                    const monthsToAdd = Number(
                                      data.probationPeriod
                                    );
                                    if(isNaN(monthsToAdd) || monthsToAdd < 0)
                                      return "Invalid probation period";

                                    // Validate joiningDate format (DD-MM-YYYY)
                                    if(
                                      !data.joiningDate ||
                                      typeof data.joiningDate !== "string"
                                    ) {
                                      return "Invalid joining date format";
                                    }

                                    const dateParts =
                                      data.joiningDate.split("-");
                                    if(dateParts.length !== 3)
                                      return "Invalid joining date format";

                                    const [day, month, year] = dateParts.map(
                                      (part) => parseInt(part, 10)
                                    );

                                    // Ensure day, month, and year are valid numbers
                                    if(
                                      isNaN(day) ||
                                      isNaN(month) ||
                                      isNaN(year)
                                    ) {
                                      return "Invalid joining date format";
                                    }

                                    // Convert to ISO format (YYYY-MM-DD)
                                    const formattedDate = `${year}-${String(
                                      month
                                    ).padStart(2, "0")}-${String(
                                      day
                                    ).padStart(2, "0")}`;
                                    const joinDate = new Date(formattedDate);

                                    // Validate if joinDate is a valid date
                                    if(isNaN(joinDate.getTime()))
                                      return "Invalid joining date";

                                    // Add months to calculate probation end date
                                    const endDate = new Date(joinDate);
                                    endDate.setMonth(
                                      joinDate.getMonth() + monthsToAdd
                                    );

                                    // Handle month overflow
                                    if(
                                      endDate.getDate() !== joinDate.getDate()
                                    ) {
                                      endDate.setDate(0); // Move to last day of the previous month
                                    }

                                    // Format as DD/MM/YYYY
                                    return `${String(
                                      endDate.getDate()
                                    ).padStart(2, "0")}-${String(
                                      endDate.getMonth() + 1
                                    ).padStart(
                                      2,
                                      "0"
                                    )}-${endDate.getFullYear()}`;
                                  } catch(error) {
                                    console.error(
                                      "Error calculating probation end date:",
                                      error
                                    );
                                    return "Calculation error";
                                  }
                                })()
                                : "Permanent"}
                            </td>
                          )}
                          <td className="">
                            {(cardName == "card1" || cardName == "card4") && (
                              <span
                                className="btn btn-outline-info btn-sm cursor-pointer mr-1"
                                onClick={() =>
                                  viewEmployeeDetailsClickHandler(data)
                                }
                                title="View Employee"
                              >
                                <i className="fas fa-eye"></i>
                              </span>
                            )}
                            {cardName == "card1" ? (
                              <span
                                className={`btn btn-outline-warning btn-sm cursor-pointer mr-1 ${!data.isActive ? "disabled" : ""
                                  }`}
                                title={
                                  data.isActive
                                    ? "Employee is deleted"
                                    : "Edit Employee"
                                }
                                onClick={() =>
                                  data.isActive &&
                                  EditEmployeeClickHandler(data)
                                }
                              >
                                <i className="fas fa-edit"></i>
                              </span>
                            ) : null}
                            {(cardName == "card1" && !data.isActive == false && data.roleName != 'Administrator') ||
                              !data.isActive == null ? (
                              <span
                                className={`btn btn-outline-danger btn-sm cursor-pointer`}
                                title="Delete Employee"
                                onClick={() => deleteEmployee(data.userID)}
                              >
                                <i className="fas fa-trash"></i>
                              </span>
                            ) : null}
                            {showActive !== true ?
                              (<span
                                className={`btn btn-outline-danger btn-sm cursor-pointer`}
                                title="Reonboard Employee"
                                onClick={() => ReonboardEmployee(data.userID)}
                              >
                                <i className="fas fa-reply"></i>
                              </span>) : null

                            }
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {/* Pagination */}
                  <div className="d-flex justify-content-between mt-2">
                    <div>
                      Showing {startEntry} to {endEntry} of{" "}
                      {searchedEmployees.length} entries
                    </div>
                    <div>
                      <button
                        className="btn btn-xs btn-outline-primary"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <i className="fas fa-angle-double-left"></i>
                      </button>
                      <span className="m-1">
                        Page {currentPage} of {totalPages}
                      </span>
                      <button
                        className="btn btn-xs btn-outline-primary"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        <i className="fas fa-angle-double-right"></i>
                      </button>
                    </div>
                  </div>
                </div>
              ) : null}
              {sectionsDisplay == true ? (
                <div id="addEmployee">
                  <div className="row">
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option1">
                        Employee Name <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.name ? "is-invalid" : ""
                            }`}
                          id="option1"
                          ref={inputNameReference}
                          placeholder="Enter Employee Name"
                          name="name"
                          value={employee.name}
                          onChange={handleChange}
                        />
                        {/* {errors.name && <div className="invalid-feedback">{errors.name}</div>} */}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option2">
                        Employee Email <span className="text-danger"> *</span>
                      </label>
                      <span
                        hover-tooltip="Here you should give the employee personal email id."
                        tooltip-position="bottom"
                      >
                        <i
                          className="fas fa-info-circle m-1"
                          style={{ color: "rgb(0 0 0 / 51%)" }}
                        ></i>
                      </span>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.email ? "is-invalid" : ""
                            }`}
                          id="option2"
                          placeholder="Enter Employee Email"
                          ref={inputEmailReference}
                          name="email"
                          value={employee.email}
                          onChange={handleChange}
                        />
                        {/* {errors.email && <div className="invalid-feedback">{errors.email}</div>} */}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option3">
                        Employee contact No.{" "}
                        <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.contact ? "is-invalid" : ""
                            }`}
                          id="option3"
                          placeholder="Enter Employee Contact No"
                          name="contact"
                          ref={inputContactReference}
                          value={employee.contact}
                          onChange={handleChange}
                        />

                        {/* {errors.contact && <div className="invalid-feedback">{errors.contact}</div>} */}
                      </div>
                    </div>
                    {/* Select Manager Field */}
                    <div className="form-group col-md-4 mb-3">
                      <label htmlFor="selectGender">
                        Select Gender{" "}
                        {/* Uncomment below line if the field is mandatory */}
                        {/* <span className="text-danger bold"> *</span> */}
                      </label>
                      <select
                        id="selectGender"
                        className="form-control form-control-sm"
                        value={selectedGender || "Male"} // Replace with your actual state variables
                        onChange={(e) => setSelectedGender(e.target.value)} // Replace with your state updater function
                      >
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                      </select>
                    </div>
                    <div className="form-group col-md-4 mb-3 d-flex align-items-center ml-4 mt-3">
                      <input
                        type="checkbox"
                        id="onboardingCheckbox"
                        className="form-check-input me-2"
                        checked={sendOnboardingLink}
                        onChange={() =>
                          setSendOnboardingLink(!sendOnboardingLink)
                        }
                      />
                      <label
                        htmlFor="onboardingCheckbox"
                        className="form-check-label mb-0 text-bold"
                      >
                        Send Onboarding Link
                      </label>
                    </div>
                  </div>
                </div>
              ) : null}
              {sectionEditDisplay == true ? (
                <div id="editEmployee">
                  <div className="row">
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option1">
                        Employee First Name<sup style={{ color: "red" }}>*</sup>
                      </label>
                      <input
                        type="text"
                        className={`form-control form-control-sm ${errors.firstName ? "is-invalid" : ""
                          }`}
                        id="firstNameInput"
                        name="firstName"
                        value={editEmployeeData.firstName}
                        onChange={handleEmployeeDetailsEditChange}
                        placeholder="Employee First Name"
                      />
                      {errors.firstName && (
                        <div className="invalid-feedback">
                          {errors.firstName}
                        </div>
                      )}
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option1">
                        Employee Last Name<sup style={{ color: "red" }}>*</sup>
                      </label>
                      <input
                        type="text"
                        className={`form-control form-control-sm ${errors.lastName ? "is-invalid" : ""
                          }`}
                        id="lastNameInput"
                        name="lastName"
                        value={editEmployeeData.lastName}
                        onChange={handleEmployeeDetailsEditChange}
                        placeholder="Employee Last Name"
                      />{" "}
                      {errors.lastName && (
                        <div className="invalid-feedback">
                          {errors.lastName}
                        </div>
                      )}{" "}
                    </div>
                    {/* Employee Name Field */}
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option1">
                        Employee User Name{" "}
                        <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          disabled
                          type="text"
                          className={`form-control form-control-sm ${errors.userName ? "is-invalid" : ""
                            }`}
                          id="option1"
                          placeholder="Enter Employee User Name"
                          name="userName"
                          value={editEmployeeData.userName}
                          onChange={handleEmployeeDetailsEditChange}
                        />
                        {errors.userName && (
                          <div className="invalid-feedback">
                            {errors.userName}
                          </div>
                        )}{" "}
                      </div>
                    </div>
                    {/* Employee Email Field */}
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option2">
                        Employee Official Email{" "}
                        <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          disabled={selectedEmployeeId == personalInfo.userID}
                          className={`form-control form-control-sm ${errors.email ? "is-invalid" : ""
                            }`}
                          id="option2"
                          placeholder="Enter Employee Official Email"
                          name="officialEmail"
                          value={editEmployeeData.officialEmail}
                          onChange={handleEmployeeDetailsEditChange}
                        />
                        {errors.email && (
                          <div className="invalid-feedback">{errors.email}</div>
                        )}
                      </div>
                    </div>

                    {/* Employee Designation Field */}
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option3">
                        Employee Designation{" "}
                        <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.designation ? "is-invalid" : ""
                            }`}
                          id="option3"
                          placeholder="Enter Employee Designation"
                          name="designation"
                          value={editEmployeeData.designation}
                          onChange={handleEmployeeDetailsEditChange}
                        />
                        {errors.designation && (
                          <div className="invalid-feedback">
                            {errors.designation}
                          </div>
                        )}
                      </div>
                    </div>
                    {/* Select Role Field */}
                    <div className="form-group col-md-4 mb-3">
                      <label htmlFor="selectRole">
                        Select Role<sup style={{ color: "red" }}>*</sup>
                      </label>
                      <select
                        // disabled = {editEmployeeData.empId == personalInfo.userID}
                        disabled={selectedEmployeeId == personalInfo.userID}
                        id="selectRole"
                        className="form-control form-control-sm"
                        value={selectedRole || editEmployeeData.role}
                        onChange={setRole}
                      >
                        <option value="">Select Role</option>
                        {allRolesList.length > 0 ? (
                          allRolesList.map((role) => {
                            return (
                              <option
                                // disabled = {selectedEmployeeID == personalInfo.userID}
                                key={"Mana_" + role.roleID}
                                value={role.roleID}
                              >
                                {role.roleName}
                              </option>
                            );
                          })
                        ) : (
                          <option disabled>No Roles available</option>
                        )}
                      </select>
                    </div>
                    {/* Select Department Field */}
                    <div className="form-group col-md-4 mb-3">
                      <label htmlFor="selectDepartment">
                        Select Department
                        <span className="text-danger"> *</span>
                      </label>
                      <select
                        id="selectDepartment"
                        className="form-control form-control-sm"
                        value={
                          selectedDepartment || editEmployeeData.department
                        }
                        onChange={setDepartment}
                      >
                        <option value="">Select a department</option>
                        {allDepartment.length > 0 ? (
                          allDepartment.map((department) => (
                            <option
                              key={department.departmentID}
                              value={department.departmentID}
                            >
                              {department.departmentName}
                            </option>
                          ))
                        ) : (
                          <option disabled>No departments available</option>
                        )}
                      </select>
                    </div>
                    {/* Select Manager Field */}
                    <div className="form-group col-md-4 mb-3">
                      <label htmlFor="selectManager">
                        Select Manager{" "}
                        {/* <span className="text-danger bold"> *</span> */}
                      </label>
                      <select
                        id="selectManager"
                        className="form-control form-control-sm"
                        value={selectedManager || userManager}
                        onChange={(e) => setSelectedManager(e.target.value)}
                      >
                        <option value="">Select a Manager</option>
                        {/* {allDeptManager.length > 0 ? (
                          allDeptManager.map((manager) => (
                            <option key={manager.UserID} value={manager.userID}>
                              {manager.firstName}
                            </option>
                          ))
                        ) : (
                          <option disabled>No Manager available</option>
                        )} */}
                        {allDeptManager.length > 0 ? (
                          allDeptManager
                            .filter(
                              (manager) => manager.userID !== selectedEmployeeId
                            )
                            .map((manager) => (
                              <option
                                key={manager.userID}
                                value={manager.userID}
                              >
                                {manager.firstName}
                              </option>
                            ))
                        ) : (
                          <option disabled>No Manager available</option>
                        )}
                      </select>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option5">
                        Employee contact No.{" "}
                        <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.mobile ? "is-invalid" : ""
                            }`}
                          id="option5"
                          placeholder="Enter Employee Contact No"
                          name="mobile"
                          value={editEmployeeData.mobile}
                          onChange={handleEmployeeDetailsEditChange}
                        />

                        {/* {errors.contact && <div className="invalid-feedback">{errors.contact}</div>} */}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option6">
                        Assigned CTC <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <input
                          type="text"
                          className={`form-control form-control-sm ${errors.assignedCTC ? "is-invalid" : ""
                            }`}
                          id="option6"
                          placeholder="Enter Assigned CTC"
                          name="assignedCTC"
                          value={editEmployeeData.assignedCTC}
                          onChange={handleEmployeeDetailsEditChange}
                        />

                        {/* {errors.contact && <div className="invalid-feedback">{errors.contact}</div>} */}
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="option7">
                        Payroll Template <span className="text-danger"> *</span>
                      </label>
                      <div
                        className={`input-group input-group-merge speech-to-text${errors.payrollTempId ? "is-invalid" : ""
                          }`}
                      >
                        <select
                          id="selectPayroll"
                          name="payrollTempId"
                          className="form-control form-control-sm"
                          value={editEmployeeData.payrollTempId}
                          // onChange={(e) => setSelectedPayroll(e.target.value)}
                          onChange={handleEmployeeDetailsEditChange}
                        >
                          <option value="">Select Payroll Template</option>
                          {payrolls.length > 0 ? (
                            payrolls.map((template) => (
                              <option
                                key={template.autoId}
                                value={template.autoId}
                              >
                                {template.templateName}
                              </option>
                            ))
                          ) : (
                            <option disabled>No payroll available</option>
                          )}
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="selectLocation">
                        Location <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <select
                          className={`form-control form-control-sm ${errors.locationId ? "is-invalid" : ""
                            }`}
                          id="selectLocation"
                          name="locationId" // Matches state key
                          value={editEmployeeData.locationId} // Correct binding
                          onChange={handleEmployeeDetailsEditChange} // Calls function on change
                        >
                          <option value="">Select a Location</option>
                          {locations.map((location) => (
                            <option
                              key={location.locationID}
                              value={location.locationID}
                            >
                              {location.locationName}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      <label className="form-label" htmlFor="isProbation">
                        Probation <span className="text-danger"> *</span>
                      </label>
                      <div className="input-group input-group-merge speech-to-text">
                        <select
                          className={`form-control form-control-sm ${errors.isProbation ? "is-invalid" : ""
                            }`}
                          id="isProbation"
                          name="isProbation"
                          value={editEmployeeData.isProbation}
                          onChange={handleEmployeeDetailsEditChange}
                        >
                          <option value="">Select Is Probation</option>
                          <option value="true">Yes</option>
                          <option value="false">No</option>
                        </select>
                      </div>
                    </div>
                    {editEmployeeData.isProbation === "true" && (
                      <div className="col-md-4 mb-3">
                        <label className="form-label" htmlFor="probationPeriod">
                          Probation Period{" "}
                          <span className="text-danger"> *</span>
                        </label>
                        <select
                          className={`form-control form-control-sm ${errors.probationPeriod ? "is-invalid" : ""
                            }`}
                          id="probationPeriod"
                          name="probationPeriod"
                          value={editEmployeeData.probationPeriod}
                          onChange={handleEmployeeDetailsEditChange}
                        >
                          <option value="">Select probation period</option>
                          <option value="3">3 months</option>
                          <option value="6">6 months</option>
                        </select>
                      </div>
                    )}
                    <div className="col-md-4 mb-3">
                      <div className="form-group">
                        <label htmlFor="dateOfBirth">
                          Date Of Birth
                          <span className="text-danger"> *</span>
                        </label>
                        <input
                          type="date"
                          id="dateOfBirth"
                          ref={dateOfBirthref}
                          className={`form-control form-control-sm ${errors.dateOfBirth ? "is-invalid" : ""
                            }`}
                          name="dateOfBirth"
                          value={editEmployeeData.dateOfBirth}
                          onChange={handleEmployeeDetailsEditChange}
                          max={today}
                        />
                      </div>
                    </div>
                    <div className="col-md-4 mb-3">
                      {/* Select Joining Date Field */}
                      <div className="form-group">
                        <label htmlFor="joiningDate">
                          Joining Date
                          <span className="text-danger"> *</span>
                        </label>

                        <input
                          type="date"
                          id="joiningDate"
                          ref={joiningdateref}
                          className={`form-control form-control-sm ${errors.joiningDate ? "is-invalid" : ""
                            }`}
                          name="joiningDate"
                          value={editEmployeeData.joiningDate}
                          onChange={handleEmployeeDetailsEditChange}
                          min={today}
                        />
                      </div>
                    </div>
                    {selectedEmployeeId !== personalInfo.userID ? (
                      <div className="form-group d-flex align-items-center ml-auto">
                        <div className="custom-control custom-switch">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="customSwitch1"
                            onChange={(e) => changeActiveUser(e)}
                            value={isActiveUser}
                            checked={isActiveUser}
                          />
                          <label
                            className="custom-control-label"
                            for="customSwitch1"
                            style={{ color: "#000" }}
                          >
                            User Can Access This Account?
                          </label>
                        </div>
                      </div>
                    ) : null}
                  </div>
                </div>
              ) : null}
            </div>

            {sectionsDisplay == true && sectionEditDisplay == false ? (
              <div className="card-footer">
                {isLoaderActive ? (
                  <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                ) : (
                  <button
                    className="btn btn-sm float-right btn-primary"
                    onClick={() => handleAddNewEmployee()}
                    type="button"
                  >
                    Add New Employee
                  </button>
                )}

                <button
                  className="btn btn-sm float-right btn-default mr-1"
                  onClick={() => CancelAddNewEmployeeClickHandler()}
                  type="button"
                >
                  Cancel
                </button>
              </div>
            ) : null}

            {sectionEditDisplay == true ? (
              <div className="card-footer">
                <button
                  className="btn btn-sm float-right btn-primary "
                  onClick={(e) => handleEditEmployee(e)}
                  type="button"
                >
                  Update Employee
                </button>
                <button
                  className="btn btn-sm float-right btn-default mr-1"
                  onClick={() => CancelAddNewEmployeeClickHandler()}
                  type="button"
                >
                  Cancel
                </button>
              </div>
            ) : null}
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id="deleteModal"
        data-backdrop="static"
        data-keyboard="false"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          className="modal-dialog modal-sm modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h6
                className="modal-title w-100 text-center"
                id="exampleModalLabel2"
              >
                Are you sure?
              </h6>
              <button
                type="button"
                onClick={() => hideModal()}
                className="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body justify-content-center">
              <i
                className="w-100 text-center text-warning mb-3 fa fa-ban"
                style={{ fontSize: "3rem" }}
              ></i>
              <h6 className="text-center">
                Do you really want to delete this employee?
              </h6>
              <h6 className="text-center text-danger">
                This process cannot be undone.
              </h6>
            </div>
            <div className="modal-footer justify-content-center">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => hideModal()}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn btn-danger"
                onClick={() => confirmDeleteEmployee()}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}

export default ManageEmployee;
