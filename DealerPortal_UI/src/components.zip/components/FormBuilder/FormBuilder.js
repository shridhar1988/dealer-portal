import React, { useRef, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Modal, Button } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import axios from 'axios';
import './FormBuilder.css';
const config = require('../../config/config.json');

let getUpdatedJson = "";

const fbOptions = {
  fields: [
    {
      label: "Profile Upload",
      type: "file",
      icon: "👤",
      className: "profile-upload-field",
    },
    {
      label: "Document Upload",
      type: "file",
      icon: "📄",
      className: "document-upload-field",
    },
  ],
};




function FormBuilder() {

  // let navigate = useNavigate();

  // const personalInfo = useSelector((state) => state.personalInformationReducer);
  // const [newsNotifications, setNewsNotifications] = useState([]);
  // const [isLoaderActive, setIsLoaderActive] = useState(false);
  // const dispatch = useDispatch()

  // useEffect(() => {
  //   window.initScroller();

  // }, []);

  const check = useRef(true);
  const [formBuilderInstance, setFormBuilderInstance] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [allModule, setAllModule] = useState([]);
  const [allSubModule, setAllSubModule] = useState([]);
  const [jsonData, setJsonData] = useState(null);
  const [pjsonData, setpJsonData] = useState(null);
  const [isLoaderActive, setIsLoaderActive] = useState(false);


  const [selectOption, setselectOption] = useState("");
  const [selectedSubModuleValue, setSelectedSubModuleValue] = useState("");
  let fb = useRef(null);

  // Initialize formBuilder once on mount
  useEffect(() => {
    if (check.current) {
      const $ = window.jQuery;
      const fbTemplate = document.getElementById("form-builder-init-div");

      // Initialize form builder only once
      fb.current = $(fbTemplate).formBuilder(options);
      setFormBuilderInstance(fb.current); // Store instance for future reference

      check.current = false; // Prevent re-initialization
    }

    getAllModule(); // Fetch modules when component mounts
  }, []);


  // Module dropdown change handler
  const moduleDropdownChangeHandler = (getModuleId) => {
    setselectOption(getModuleId);
    getSubModuleByModuleId(getModuleId);
  };

  // Submodule dropdown change handler
  const subModuleDropdownChangeHandler = (getSubModuleId) => {
    setSelectedSubModuleValue(getSubModuleId);
    getSubModuleJsonByModuleId(selectOption, getSubModuleId);
  };

  // Fetch submodules based on selected module
  const getSubModuleByModuleId = async (id) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/SubModule/GetSubModuleByModuleId/${id}`
      );
      if (response.data.success === "True") {
        setAllSubModule(response.data.data);
      } else {
        setAllSubModule([]);
        // console.log("Submodules not fetched");
      }
    } catch (error) {
      console.error("Error fetching submodules:", error);
    }
  };

  // Fetch form data for the selected submodule
  const getSubModuleJsonByModuleId = async (moduleId, subModuleId) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AdminFormFormat/GetFormFormatById/${moduleId}/${subModuleId}`
      );
      if (response.data.success === "True") {
        const jsonData = response.data.data.jsonData;
        if (fb.current) {
          // Update the form builder instance with new data
          fb.current.actions.setData(jsonData);
          setJsonData(jsonData); // Store for preview
        }
      } else {
        // console.log("Form data not fetched");
      }
    } catch (error) {
      console.error("Error fetching form data:", error);
    }
  };

  // Handle preview action
  const handlePreview = () => {
    if (fb.current) {
      const formDataPreview = fb.current.actions.getData();
      const jsonData = JSON.stringify(formDataPreview);
      if (JSON.parse(jsonData).length > 0) {
        getUpdatedJson = jsonData;
        setJsonData(jsonData); // Store JSON data for preview
        setShowModal(true);
      } else {
        toast.error("There is nothing for the preview")
      }
      // console.log("in preview json--->", JSON.parse(jsonData).length);

    }
  };

  const options = {
    ...fbOptions,
    actionButtons: [
      {
        id: "preview", // Button ID
        className: "btn btn-success", // CSS classes for styling
        label: "Preview", // Label or emoji for the button
        type: "button", // Button type
        events: {
          click: handlePreview, // Assign preview handler
        },
      },
    ],
  };

  // Handle save action
  const handleSave = (moduleID, subModuleID) => {
    setIsLoaderActive(true);
    if (fb.current) {
      // console.log("fb.current---->",fb.current);
      const formData = fb.current.actions.getData();
      // console.log("fb.current formData---->",formData);
      const structure = {
        moduleID: moduleID,
        subModuleID: subModuleID,
        createdBy: "Admin",
        jsonData: JSON.stringify(formData),
      };
      postFormData(structure);
    }
    setIsLoaderActive(false);
  };

  // Save form data to the backend
  const postFormData = (formData) => {
    axios
      .post(`${config.apiEndPoint}/AdminFormFormat/PostFormData`, formData)
      .then((response) => {

        if (response.data.success != "False") {
          //alert(response.data.success);
          setIsLoaderActive(false);

        } else {
          toast.error(response.data.message);
          setIsLoaderActive(false);

        }
        toast.success("Saved successfully!");
        // console.log("Data saved successfully:", response.data);
      })
      .catch((error) => {
        toast.error("Error while storing data!");
        console.error("Error saving data:", error);
      });
  };

  // Fetch all modules
  const getAllModule = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Module/GetAllModules`
      );
      if (response.data.success === "True") {
        setAllModule(response.data.data);
      } else {
        setAllModule([]);
        // console.log("Modules not fetched");
      }
    } catch (error) {
      console.error("Error fetching modules:", error);
    }
  };

  // Render form data inside modal when it's open
  useEffect(() => {
    if (showModal && jsonData) {
      const $ = window.jQuery;
      $("#preview-form").formRender({ formData: jsonData });

      const renderedForm = $("#preview-form").find(".rendered-form");
      if (renderedForm.length) {
        renderedForm.addClass("row"); // Add `row` class to the rendered form
      }
    }
  }, [showModal, jsonData]);

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-6">
              <h5 className="m-0">Manage Dynamic Forms Using Form Builder
                <span hover-tooltip="This is a dynamic form builder. Use the dropdown menus to select modules or submodules. Drag and drop fields from the right panel to the central workspace. Available fields include Autocomplete, Button, Checkbox Group, and more. Use the 'Save Form' button to save, 'Clear' to reset, and 'Preview' to see the form before saving." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item"><a href="/form-builder">Home</a></li>
                <li className="breadcrumb-item active">Manage Dynamic Forms </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid" >
        <div className="col-md-12">
          <div className="card card-outline card-primary">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col-md-8">
                  {/* <h3 className="card-title">Master Streams</h3> */}
                  <div className='row'>
                    <div className="col-md-3">
                      <select
                        value={selectOption}
                        onChange={(e) => moduleDropdownChangeHandler(e.target.value)}
                        className="form-control form-control-sm select2"
                      >
                        <option value=" ">Select Module</option>
                        {allModule.map((value) => (
                          <option key={value.id} value={value.id}>
                            {value.moduleName}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-md-3">
                      <select
                        value={selectedSubModuleValue}
                        onChange={(e) => subModuleDropdownChangeHandler(e.target.value)}
                        className="form-control form-control-sm select2"
                      >
                        <option value=" ">Select Sub Module</option>
                        {allSubModule.map((value) => (
                          <option key={value.id} value={value.id}>
                            {value.subModuleName}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                </div>
                <div className="col-md-4 float-right">
                  <div className="card-tools float-right mt-1">
                    <button type="button" className="btn btn-tool" data-card-widget="maximize"><i className="fas fa-expand"></i>
                    </button>
                  </div>
                  <button className="btn btn-sm float-right btn-outline-danger" onClick={handlePreview} type="button">
                    Preview Form
                  </button>
                  {isLoaderActive ? (
                  <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                ) : (
                  <button className="btn btn-sm float-right btn-primary mr-1" type="button" onClick={() => handleSave(selectOption, selectedSubModuleValue)}>
                    Save Form
                  </button>
                )}
                </div>
              </div>

            </div>
            <div className="card-body" style={{background: 'rgb(249 249 249)'}}>
              <div id="form-builder-init-div"></div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        show={showModal}
        onHide={() => setShowModal(false)}
        size="xl"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title>Form Preview</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <style>
            {`
            
              .color-red{
                  color: red;
              }
            .color-grey{
                  color: #828282;
              }
            .rendered-form label{
                  font-weight: 400 !important;
                  font-size: 14px;
                  color: #828282;
            }
                /* Hide the input field for profile upload */
                /* Profile upload field styling */
              .profile-upload-field {
                width: 0;
                height: 0;
                overflow: hidden;
              }

              .profile-upload-field-label {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                width: 100px;
                height: 100px;
                border: 2px solid #ccc;
                border-radius: 50%;
                position: relative;
                cursor: pointer;
                text-align: center;
                overflow: hidden;
                background-color: #f8f9fa;
              }

              .formbuilder-file .image-preview {
                position: absolute;
                top: ;
                left: 0;
                width: 100%; /* Ensure the image fully fills the label */
                height: 100%; /* Maintain the label's size */
                object-fit: cover; /* Properly scale the image */
                border-radius: 50%; /* Keep the circular shape */
                z-index: 999;
              }
              .profile-upload-field-label img {
                        position: absolute;
                        width: 100%;
                        height: 100%;
                        object-fit: cover;
                      }

                /* Styling for the "+" overlay on the label */
                .profile-upload-field-label::after {
                  content: "+";
                  position: absolute;
                  bottom: 5px;
                  right: 5px;
                  width: 30px;
                  height: 30px;
                  background-color: #3366ff;
                  color: white;
                  font-size: 20px;
                  font-weight: bold;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  border: 2px solid white;
                  border-radius: 50%;
                  z-index: 999; /* Ensures the "+" overlay is on top of the image */
                  transition: 0.3s;
                }

                /* Hover effect for the "+" overlay */
                .profile-upload-field-label::after:hover {
                  background-color: #274bba;
                }
              .document-upload-field {
                  width: 0;
                  height: 0;
                  overflow: hidden;
              }
              .document-upload-field-label {
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  border: 2px dotted #007bff;
                  border-radius: 5px;
                  padding: 20px;
                  font-size: 14px;
                  cursor: pointer;
                  background-color: #f8f9fa;
                  margin-top: 10px;
                  max-height: 120px;
                  max-width: 350px;
              }
              .document-upload-field-label .icon {
                  margin-right: 8px;
              }
              .document-upload-field-label.file-name {
                  font-size: 14px;
                  color: #333;
              }
                  // .form-wrap.form-builder.formbuilder-embedded-bootstrap .btn-group {
                  //   display:none !important;
                  // }
            `}
          </style>
          <div id="preview-form"></div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
      <ToastContainer position="top-center" />
    </>
  )
}

export default FormBuilder