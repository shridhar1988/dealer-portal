import React, { useState, useRef, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useSelector } from "react-redux";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import $ from 'jquery';
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import config from "../../config/config.json";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


const BroadcastNotification = () => {
  const [departments, setDepartments] = useState([]);
  const [allNotifications, setAllNotifications] = useState([]);
  const [notificationToDeleteDetails, setNotificationToDeleteDetails] = useState({ notificationId: null, notificationCreatedBy: "", });
  const [selectedDepartment, setSelectedDepartment] = useState("all");
  const [addNewSectionsDisplay, setAddNewSectionsDisplay] = useState(false);
  const [notificationHeading, setNotificationHeading] = useState("");
  const [description, setDescription] = useState("");
  const notificationHeadingRef = useRef(null);
  const notificationDescriptionRef = useRef(null);
  const [loggedUser, setLoggedUser] = useState("");
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [collapsedState, setCollapsedState] = useState({});
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;


  useEffect(() => {
    GetDepartments();
    getAllNotifications();
  }, []);

  useEffect(() => {
    setLoggedUser(personalInfo.userRole);
  }, [personalInfo]);

  const GetDepartments = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}Department/GetAllDepartments`
      );
      const appsArray = response.data.data || [];
      setDepartments(appsArray);
      // window.initSummernoteFuncation();
    } catch(error) {
      console.error("Error fetching departments:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const getAllNotifications = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}NotificationBrodcast/GetAllNotification`
      );
      if(response.data.success == "True") {
        const appsArray = response.data.data || [];
        setAllNotifications(appsArray || []);
        if(appsArray) {
          window.setSummerNoteValueFuncation(appsArray.notificationDescription);
        }
        setTimeout(() => {
          window.initDataTableFuncation();
        }, 1000)
        window.initSummernoteFuncation();
        setTimeout(() => {
          window.$('#buttonCust0').click();
        }, 1000);
      } else {
        setAllNotifications([]);
        setTimeout(() => {
          window.initDataTableFuncation();
        }, 1000)
      }
    } catch(error) {
      console.error("Error fetching notifications:", error);
      toast.error('Error fetching notifications');
    } finally {
      setIsLoaderActive(false);
    }
  };

  const cancleSendNewNotificationClickHandler = (e) => {
    setAddNewSectionsDisplay(false);
  };

  const handleDepartmentChange = (e) => {
    setSelectedDepartment(e.target.value);
  };

  const sendNotificationClickHandler = (e) => {
    const textareaValue = window.getSummerNoteValueFuncation();

    if(!notificationHeading) {
      toast.error("Please enter notification subject.");
      notificationHeadingRef.current.focus();
      notificationHeadingRef.current.classList.add("is-invalid");
      setIsLoaderActive(false);

      return;
    }

    if(!textareaValue) {
      toast.error("Please enter notification description.");
      document.getElementById("summernote").focus();
      setIsLoaderActive(false);

      return;
    }

    const postData = {
      CreatedBy: personalInfo.userID,
      ModifiedBy: personalInfo.userID,
      NotificationHeading: notificationHeading,
      NotificationDescription: textareaValue,
      Department: selectedDepartment,
      isDeleted: false,
    };
    axios
      .post(
        `${config.API_URL}NotificationBrodcast/PostNotification`,
        postData,
        {
          headers: {
            ...config.headers3,
            "Content-Type": "application/json-patch+json",
          },
        }
      )
      .then((response) => {
        if(response.data.success) {
          toast.success("Email configuration saved successfully.");
          getAllNotifications();
          setAddNewSectionsDisplay(false);
          setSelectedDepartment("all");
          setNotificationHeading('');
        } else {
          toast.error(response.data.message);
        }
      })
      .catch((error) => {
        toast.error(
          error.response?.data?.message ||
          "Oops, something went wrong. Please try again later."
        );
      })
      .finally(() => {
        getAllNotifications();
        setIsLoaderActive(false);
      });
  };

  const SendNewNotificationClickHandler = (e) => {
    setAddNewSectionsDisplay(true);
    window.initSummernoteFuncation();
  };

  const hideModal = async () => {
    window.$("#deleteModal").modal("hide");
  };

  const deleteNotification = async (notificationId, notificationCreatedBy) => {
    try {
      setNotificationToDeleteDetails({ notificationId: notificationId, notificationCreatedBy: notificationCreatedBy });
      window.$("#deleteModal").modal({ backdrop: "static", keyboard: false });
      window.$("#deleteModal").modal("show");
    } catch(error) {
      console.error(
        "Error deleting employee:",
        error.response ? error.response.data : error.message
      );
    }
  };

  const confirmNotification = async () => {
    const response = await axios.post(
      `${config.apiEndPoint}/NotificationBrodcast/DeleteNotification?Id=${notificationToDeleteDetails.notificationId}&CreatedBy=${notificationToDeleteDetails.notificationCreatedBy}`
    );
    if(response.data.success == "True") {
      window.$("#deleteModal").modal("hide");
      toast.success(response.data.message);
      getAllNotifications();
    } else {
      toast.error(response.message);
    }
  };

  const toggleCollapse = (index) => {
    setCollapsedState((prevState) => ({
      ...prevState,
      [index]: !prevState[index],
    }));
  };

  const filteredNotifications = allNotifications.filter((n) =>
    n.notificationHeading.toLowerCase().includes(searchText.toLowerCase())
  );

  const indexOfLast = currentPage * rowsPerPage;
  const indexOfFirst = indexOfLast - rowsPerPage;
  const currentRows = filteredNotifications.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(filteredNotifications.length / rowsPerPage);

  const startEntry = indexOfFirst + 1;
  const endEntry = Math.min(indexOfLast, filteredNotifications.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };


  const exportToCSV = () => {
    let csv = "Heading,Date\n";
    filteredNotifications.forEach((n) => {
      csv += `"${n.notificationHeading}","${new Date(n.createdOn).toLocaleDateString("en-GB")}"\n`;
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "BroadcastNotifications.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredNotifications.map((n) => ({
        Heading: n.notificationHeading,
        Date: new Date(n.createdOn).toLocaleDateString("en-GB"),
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Notifications");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "BroadcastNotifications.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Broadcast Notifications", 14, 10);
    autoTable(doc, {
      head: [["Heading", "Date"]],
      body: filteredNotifications.map((n) => [
        n.notificationHeading,
        new Date(n.createdOn).toLocaleDateString("en-GB"),
      ]),
    });
    doc.save("BroadcastNotifications.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Notifications</title></head><body>");
    printWindow.document.write("<h3>Broadcast Notifications</h3>");
    printWindow.document.write("<table border='1'><thead><tr><th>Heading</th><th>Date</th></tr></thead><tbody>");
    filteredNotifications.forEach((n) => {
      printWindow.document.write(`<tr><td>${n.notificationHeading}</td><td>${new Date(n.createdOn).toLocaleDateString("en-GB")}</td></tr>`);
    });
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };



  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">Manage Broadcast Notification</h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/employee-dashboard">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Broadcast Notifications{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <section className="content scroll-content">
        {loggedUser == "HR" ? (
          <>
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-12">
                  <div className="card card-primary card-outline">
                    <div className="card-header">
                      <div className="col-md-6">
                        <h3 className="card-title text-sm">
                          Manage Broadcast Notifications
                        </h3>
                      </div>
                      <div className="col-md-6 float-right">
                        <div className="card-tools float-right mt-1">
                          <button
                            type="button"
                            className="btn btn-tool"
                            data-card-widget="maximize"
                          >
                            <i className="fas fa-expand"></i>
                          </button>
                        </div>

                        {addNewSectionsDisplay == false ? (
                          <button
                            className="btn btn-sm float-right btn-primary mr-1"
                            type="button"
                            onClick={() => SendNewNotificationClickHandler()}
                          >
                            Send New Notification
                          </button>
                        ) : (
                          <>
                            <button
                              className="btn btn-sm float-right btn-default mr-1"
                              onClick={() => {
                                cancleSendNewNotificationClickHandler();
                              }}
                              type="button"
                            >
                              Cancel
                            </button>
                            {isLoaderActive ? (
                              <PleaseWaitButton className="float-right btn-sm mr-2 font-weight-medium auth-form-btn" />
                            ) : (
                              <button
                                className="btn btn-sm float-right btn-primary mr-2"
                                onClick={() => {
                                  sendNotificationClickHandler();
                                }}
                                type="button"
                              >
                                Send Notification
                              </button>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                    {addNewSectionsDisplay == false ? (
                      <div className="card-body text-sm position-relative">
                        {isLoaderActive && (
                          <div
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              width: "100%",
                              height: "100%",
                              backgroundColor: "rgb(233 236 239 / 81%)",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              zIndex: 10,
                            }}
                          >
                            <i
                              className="fas fa-sync-alt fa-spin"
                              style={{ fontSize: "2rem", color: "#333" }}
                            ></i>
                          </div>
                        )}
                        {/* {addNewSectionsDisplay == true ? ( */}
                        <div className="row">
                          <div className="col-md-12 mt-3">

                            <div className="d-flex justify-content-between mb-2">
                              <div>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                              </div>
                              <input
                                type="text"
                                className="form-control form-control-sm w-25"
                                placeholder="Search by heading..."
                                onChange={(e) => {
                                  setSearchText(e.target.value);
                                  setCurrentPage(1);
                                }}
                              />
                            </div>
                            <div className="table-responsive">
                              <table
                                className="table table-bordered table-sm "
                              >
                                <thead>
                                  <tr className="text-sm">
                                    <th width="3%">Sr. No.</th>
                                    <th width="30%">Notification Heading </th>
                                    <th width="12%">Date</th>
                                    <th width="3%">Action</th>
                                  </tr>
                                </thead>
                                <tbody id="tblBodyId">
                                  {currentRows.length > 0
                                    ? currentRows.map((data, index) => (
                                      <tr>
                                        <td className="text-center">
                                          {index + 1}
                                        </td>
                                        <td className="p-0"><div id="accordion">
                                          <div className="card-header text-xs p-2 heading">
                                            <p
                                              className="d-flex w-100 collapsed mb-0"
                                              data-toggle="collapse"
                                              href={`#collapse${index}`}
                                              aria-expanded={!collapsedState[index]}
                                              aria-controls={`collapse${index}`}
                                              onClick={() => toggleCollapse(index)}
                                            >
                                              {data.notificationHeading}
                                              <span className="small-txt ml-auto mt-1">
                                                <i className={`fas ${collapsedState[index] ? "fa-chevron-up" : "fa-chevron-down"}`} />
                                              </span>
                                            </p>
                                          </div>
                                          <div id={`collapse${index}`} className="collapse" data-parent="#accordion">
                                            <div className="card-body p-1 px-2" dangerouslySetInnerHTML={{ __html: data.notificationDescription }} />
                                          </div>
                                        </div></td>
                                        <td>
                                          {new Date(
                                            data.createdOn
                                          ).toLocaleDateString("en-GB", {
                                            day: "2-digit",
                                            month: "2-digit",
                                            year: "numeric",
                                          })}
                                        </td>
                                        <td>
                                          {/* <span
                                          className={`btn btn-outline-warning btn-sm cursor-pointer mr-1 `}
                                          onClick={() => null}
                                        >
                                          <i className="fas fa-edit"></i>
                                        </span> */}
                                          <span
                                            className={`btn btn-outline-danger btn-xs cursor-pointer mr-1`}
                                            onClick={() =>
                                              deleteNotification(
                                                data.id,
                                                data.CreatedBy
                                              )
                                            }
                                          >
                                            <i className="fas fa-trash"></i>
                                          </span>
                                        </td>
                                      </tr>
                                    ))
                                    : null}
                                </tbody>
                              </table>
                            </div>
                            <div className="d-flex justify-content-between mt-2">
                              <div>
                                Showing {startEntry} to {endEntry} of {filteredNotifications.length} entries
                              </div>
                              <div>
                                <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                                  <i className="fas fa-angle-double-left"></i>
                                </button>
                                <span className="mx-2">Page {currentPage} of {totalPages}</span>
                                <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                                  <i className="fas fa-angle-double-right"></i>
                                </button>
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="card-body text-sm position-relative">
                        {isLoaderActive && (
                          <div
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              width: "100%",
                              height: "100%",
                              backgroundColor: "rgb(233 236 239 / 81%)",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              zIndex: 10,
                            }}
                          >
                            <i
                              className="fas fa-sync-alt fa-spin"
                              style={{ fontSize: "2rem", color: "#333" }}
                            ></i>
                          </div>
                        )}
                        <div className="row">
                          <div className="col-md-3">
                            <label htmlFor="notificationHeading">
                              Select Departments
                              <sup style={{ color: "red" }}>*</sup>
                            </label>
                            <select
                              className="form-control form-control-sm"
                              id="userRoleNameInput"
                              value={selectedDepartment}
                              onChange={handleDepartmentChange}
                            >
                              <option value="all" selected>
                                All Departments
                              </option>
                              {departments.map((role) => (
                                <option
                                  key={role.departmentID}
                                  value={role.departmentID}
                                >
                                  {role.departmentName}
                                </option>
                              ))}
                            </select>
                          </div>
                          <div className="col-md-9">
                            <div className="form-group">
                              <label htmlFor="notificationHeading">
                                Notification Heading
                                <sup style={{ color: "red" }}>*</sup>
                              </label>
                              <textarea
                                id="notificationHeading"
                                value={notificationHeading}
                                onChange={(e) =>
                                  setNotificationHeading(e.target.value)
                                }
                                ref={notificationHeadingRef}
                                className="form-control form-control-sm"
                                style={{ resize: 'none' }}
                                placeholder="Enter Notification Heading"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="form-group">
                          <label className="col-md-12">
                            Notification Description Details
                            <sup style={{ color: "red" }}>*</sup>
                          </label>
                          <textarea
                            id="summernote"
                            ref={notificationDescriptionRef}
                          ></textarea>
                        </div>


                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          <>
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-12">
                  <div className="card card-primary card-outline">
                    <div className="card-header">
                      <div className="col-md-6">
                        <h3 className="card-title text-sm">
                          Manage Broadcast Notifications
                        </h3>
                      </div>
                      <div className="col-md-6 float-right">
                        <div className="card-tools float-right">
                          <button
                            type="button"
                            className="btn btn-tool"
                            data-card-widget="maximize"
                          >
                            <i className="fas fa-expand"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                    {addNewSectionsDisplay == false ? (
                      <div className="card-body text-sm pt-0 position-relative">
                        {isLoaderActive && (
                          <div
                            style={{
                              position: "absolute",
                              top: 0,
                              left: 0,
                              width: "100%",
                              height: "100%",
                              backgroundColor: "rgb(233 236 239 / 81%)",
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "center",
                              zIndex: 10,
                            }}
                          >
                            <i
                              className="fas fa-sync-alt fa-spin"
                              style={{ fontSize: "2rem", color: "#333" }}
                            ></i>
                          </div>
                        )}
                        <div className="row">
                          <div className="col-md-12 mt-3">
                            <div className="table-responsive">
                              <div className="d-flex justify-content-between mb-2">
                                <div>
                                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                                </div>
                                <input
                                  type="text"
                                  className="form-control form-control-sm w-25"
                                  placeholder="Search by heading..."
                                  onChange={(e) => {
                                    setSearchText(e.target.value);
                                    setCurrentPage(1);
                                  }}
                                />
                              </div>

                              <table
                                className="table table-bordered table-sm table-striped"
                              >
                                <thead>
                                  <tr className="text-sm">
                                    <th >Sr. No.</th>
                                    <th >Notification Heading </th>
                                    <th >Date</th>
                                  </tr>
                                </thead>
                                <tbody id="tblBodyId">
                                  {currentRows.length > 0
                                    ? currentRows.map((data, index) => {
                                      const cleanHTML = data.notificationDescription
                                        .replace(/data-[^=]+="[^"]*"/g, '') // Remove data attributes
                                        .replace(/style="[^"]*"/g, ''); // Remove inline styles

                                      return (
                                        <tr key={index}>
                                          <td className="text-center">{index + 1}</td>
                                          <td className="p-0">
                                            <div id="accordion">
                                              <div className="card-header text-xs p-2 heading">
                                                <p
                                                  className="d-flex w-100 collapsed mb-0"
                                                  data-toggle="collapse"
                                                  href={`#collapse${index}`}
                                                  aria-expanded={!collapsedState[index]}
                                                  aria-controls={`collapse${index}`}
                                                  onClick={() => toggleCollapse(index)}
                                                >
                                                  {data.notificationHeading}
                                                  <span className="small-txt ml-auto mt-1">
                                                    <i className={`fas ${collapsedState[index] ? "fa-chevron-up" : "fa-chevron-down"}`} />
                                                  </span>
                                                </p>
                                              </div>
                                              <div id={`collapse${index}`} className="collapse" data-parent="#accordion">
                                                <div className="card-body p-1 px-2" dangerouslySetInnerHTML={{ __html: cleanHTML }} />

                                              </div>
                                            </div>
                                          </td>
                                          <td>
                                            {new Date(data.createdOn).toLocaleDateString("en-GB", {
                                              day: "2-digit",
                                              month: "2-digit",
                                              year: "numeric",
                                            })}
                                          </td>
                                        </tr>
                                      );
                                    })
                                    : null}
                                </tbody>
                              </table>
                            </div>
                            <div className="d-flex justify-content-between mt-2">
                              <div>
                                Showing {startEntry} to {endEntry} of {filteredNotifications.length} entries
                              </div>
                              <div>
                                <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                                  <i className="fas fa-angle-double-left"></i>
                                </button>
                                <span className="mx-2">Page {currentPage} of {totalPages}</span>
                                <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                                  <i className="fas fa-angle-double-right"></i>
                                </button>
                              </div>
                            </div>

                          </div>
                        </div>
                      </div>
                    ) : (null)}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}


        <div
          class="modal fade"
          id="deleteModal"
          data-backdrop="static"
          data-keyboard="false"
          tabindex="-1"
          aria-labelledby="staticBackdropLabel"
          aria-hidden="true"
        >
          <div
            class="modal-dialog modal-sm modal-dialog-centered"
            role="document"
          >
            <div class="modal-content">
              <div class="modal-header">
                <h6
                  class="modal-title w-100 text-center"
                  id="exampleModalLabel2"
                >
                  Are you sure?
                </h6>
                <button
                  type="button"
                  onClick={() => hideModal()}
                  class="close"
                  data-bs-dismiss="modal"
                  aria-label="Close"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body justify-content-center">
                <i
                  class="w-100 text-center text-warning mb-3 fa fa-ban"
                  style={{ fontSize: "3rem" }}
                ></i>
                <h6 class="text-center">
                  Do you really want to delete this notification?
                </h6>
                <h6 class="text-center text-danger">
                  This process cannot be undone.
                </h6>
              </div>
              <div class="modal-footer justify-content-center">
                <button
                  type="button"
                  class="btn btn-secondary"
                  onClick={() => hideModal()}
                  data-bs-dismiss="modal"
                  aria-label="Close"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  class="btn btn-danger"
                  onClick={() => confirmNotification()}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <ToastContainer position="top-center" />
    </>
  );
};

export default BroadcastNotification;