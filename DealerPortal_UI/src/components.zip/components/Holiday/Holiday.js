import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import $ from "jquery";
import axios, { formToJSON } from "axios";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { Link } from "react-router-dom";
import { setSelectedEmployeePersonalInformation } from "../../reduxStorage/selectedEmployeeInformation";
import PleaseWaitButton from "../../shared/PleaseWaitButton";

import "./Holiday.css";

let pageLoadCount = 0;

function Holiday() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const inputComponentReference = useRef(null);
  const [addNewSectionsDisplay, setAddNewSectionsDisplay] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState(
    new Date().getFullYear()
  );
  const [component, setComponent] = useState("");
  const [payrollTemplateName, setPayrollTemplateName] = useState("");
  const [probationType, setProbationType] = useState("");
  const [allTempalatesArray, setAllTempalatesArray] = useState([]);
  const [yearArray, setYearArray] = useState([]);

  const [showUpdateOption, setShowUpdateOption] = useState(false);

  const [payrollComponents, setPayrollComponents] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [holidayComponentsArray, setHolidayComponentsArray] = useState([
    {
      holidayName: "",
      holidayDate: "",
      holidayType: "compulsory",
    },
  ]);

  const holinamecomponent = useRef([]);
  const holidatecomponent = useRef([]);

  const AddNewPayrollTemplateClickHandler = (e) => {
    setShowUpdateOption(false);
    setAddNewSectionsDisplay(true);
  };

  const cancleAddNewPayrollTemplateClickHandler = (e) => {
    setAddNewSectionsDisplay(false);
    setSelectedTemplateId('');
    GetAllTempalates();
    setPayrollTemplateName("");
    setProbationType("");
    setHolidayComponentsArray([
      {
        holidayName: "",
        holidayDate: "",
        holidayType: "compulsory",
      },
    ]);
  };

  useEffect(() => {
    GetAllTempalates();
    GetAllPayrollComponents();
    var yearTemp = [];
    for (var i = 2016; i <= new Date().getFullYear(); i++) {
      yearTemp.push(i);
    }
    setYearArray(yearTemp);
    yearDropDownChangeHandler(new Date().getFullYear());
  }, []);

  const GetAllTempalates = async () => {
    try {
      const response = await axios.get(
        config.apiEndPoint + "/Payroll/GetTempalates"
      );
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);
      setAllTempalatesArray(tempalatesArray);
    } catch (error) {
      console.error("Error fetching tempalates:", error);
      toast.error("Error fetching tempalates");
    }
  };

  const dateOrRupeesChangeHandler = (
    getSelectedChangedValue,
    getIndexToChange
  ) => {
    setHolidayComponentsArray((prevArray) => {
      // Create a copy of the array and modify the object at the specified index
      const updatedArray = [...prevArray];
      updatedArray[getIndexToChange] = {
        ...updatedArray[getIndexToChange], // Copy the existing object at that index
        holidayType: getSelectedChangedValue,
      };
      return updatedArray; // Return the updated array
    });
  };

  const removeComponentFromArray = (indexToRemove) => {
    // Filter out the item at the provided index
    setHolidayComponentsArray((prevArray) =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(holidayComponentsArray);
  };

  const addNewSalaryComponents = () => {
    let tempObj = {
      holidayName: "",
      holidayDate: "",
      holidayType: "compulsory",
    };

    // Instead of mutating the array, create a new array
    setHolidayComponentsArray((prevArray) => [...prevArray, tempObj]);
    initSortableTable(holidayComponentsArray);
  };

  const initSortableTable = (getholidayComponentsArray) => {
    setTimeout(() => {
      window.$("#faqs").sortable({
        items: "tr:not(tr:first-child)",
        cursor: "pointer",
        axis: "y",
        dropOnEmpty: false,
        start: function (e, ui) {
          ui.item.addClass("selected");
        },
        stop: function (e, ui) {
          ui.item.removeClass("selected");
          $(this)
            .find("tr")
            .each(function (index) {
              if (index > 0) {
                // allTasksArray = projectTaskListData;
                // //console.log("Sort allTasksArray ===>", allTasksArray);
                // createTableDesign(allTasksArray)
              }
            });
        },
      });
    }, 1000);
  };

  const handleSalaryComponentsNameChange = (e, index, inputName) => {
    if (inputName == "SalaryComponentsNameInput") {
      const updatedValue = e.target.value; // Get the new value from the input field
      // console.log("updatedValue-->", updatedValue);

      // Update the holidayComponentsArray by creating a new array and modifying the object at the specific index
      setHolidayComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          holidayName: updatedValue, // Update the holidayName
        };

        // console.log("holidaycom---->", holidayComponentsArray);

        return updatedArray; // Return the updated array
      });
    } else {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the holidayComponentsArray by creating a new array and modifying the object at the specific index
      setHolidayComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          holidayDate: updatedValue, // Update the holidayName
        };

        // console.log("holidaycom---->", holidayComponentsArray);

        return updatedArray; // Return the updated array
      });
    }
  };

  const savePayrollTemplateClickHandler = async () => {
    if (!validateHolidayComponentInputs()) return;

    if(holidayComponentsArray == null || holidayComponentsArray.length == 0){
      toast.error("Please add holiday components before saving.");
      return;
    }
    
    try {
      const holidayDataArray = holidayComponentsArray.map((component) => ({
        holidayName: component.holidayName,
        holidayDate: component.holidayDate,
        holidayType: component.holidayType,
        createdBy: personalInfo.userID,
      }));
  
      const response = await axios.post(
        `${config.apiEndPoint}/Holiday/addHoliday`,
        holidayDataArray
      );
  
      if (response.data.success == "True") {
        toast.success("Holiday components saved successfully!");
      } else {
        console.error("Unexpected response status:", response.status);
        toast.error(
          response.data.message
        );
      }
    } catch (error) {
      console.error("Error saving holiday components:", error);
      toast.error(
        "Failed to save holiday components. Please check your connection or try again later."
      );
    } finally {
      setIsLoaderActive(false);
    }
  };
  

  const updatePayrollTemplateClickHandler = async () => {

    if(holidayComponentsArray == null || holidayComponentsArray.length == 0){
      toast.error("Please add holiday components before updating.");
      return;

    }
    if (!validateHolidayComponentInputs()) return;
  
    try {
      setIsLoaderActive(true);
  
      const holidayDataArray = holidayComponentsArray.map((component) => ({
        holidayName: component.holidayName,
        holidayDate: component.holidayDate,
        holidayType: component.holidayType,
        createdBy: personalInfo.userID,
      }));
  
      const response = await axios.post(
        `${config.apiEndPoint}/Holiday/updateHoliday?year=${selectedTemplateId}`,
        holidayDataArray,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
  
      if (response.data.success == "True") {
        toast.success("Holiday components updated successfully!");
      } else {
        console.error("Unexpected response status:", response.status);
        toast.error(
          "An error occurred while updating holiday components. Please try again."
        );
      }
    } catch (error) {
      console.error("Error updating holiday components:", error);
      toast.error(
        "Failed to update holiday components. Please check your connection or try again later."
      );
    } finally {
      setIsLoaderActive(false);
    }
  };
  


  const handlePayrollTemplateEditChange = (e, getInputName) => {
    const { name, value } = e.target;
    if (getInputName == "name") {
      setPayrollTemplateName(value);
    } else {
      setProbationType(value);
    }
  };

  const yearDropDownChangeHandler = async (getSelectedYear) => {
    setIsLoaderActive(true);

    setSelectedTemplateId(getSelectedYear);
    setShowUpdateOption(true);
    try {
      const response = await axios.get(
        config.apiEndPoint +
          "/Holiday/GetAllHolidayByYear?year=" +
          getSelectedYear
      );
      const tempalatesArray = response.data.data || [];
      // console.log("response ===> ", response);

      if (response.data.success == "True") {
        setHolidayComponentsArray(tempalatesArray);
        setAddNewSectionsDisplay(true);
        initSortableTable(tempalatesArray[0]["payrollComponents"]);
      } else {
        setHolidayComponentsArray(tempalatesArray || []);
        setAddNewSectionsDisplay(true);
        // initSortableTable(tempalatesArray[0]["payrollComponents"]);
        toast.error(response.data.message);
      }
      //setPayrollTemplateName()
      //   setAllTempalatesArray(tempalatesArray);
    } catch (error) {
      console.error("Error fetching tempalates:", error);
      toast.error("Error fetching tempalates");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const RemovePayrollTemplateClickHandler = async () => {
    window.$("#deleteModal").modal("show");
  };

  const hideModal = async () => {
    window.$("#deleteModal").modal("hide");
  };

  const confirmDeleteTemplate = async () => {
    const response = await axios.post(
      config.apiEndPoint +
        "/Payroll/deleteTempalate?templateId=" +
        selectedTemplateId
    );
    const tempalatesArray = response.data.data || [];
    // console.log("tempalatesArray ===> ", tempalatesArray);

    if (response.data.success) {
      // console.log("response ===> ", response);
      setPayrollTemplateName("");
      setProbationType("");
      setHolidayComponentsArray([
        {
          holidayName: "",
          holidayDate: "",
          holidayType: "compulsory",
        },
      ]);
      setAddNewSectionsDisplay(false);
      setIsLoaderActive(false);

      setSelectedTemplateId("");
      window.$("#deleteModal").modal("hide");
      GetAllTempalates();
      toast.error("Payroll template deleted successfully...");
    }
  };

  const showModal = async () => {
    window.$("#showModal").modal("show");
  };

  const closeModal = async () => {
    window.$("#showModal").modal("hide");
  };


  const validateHolidayComponentInputs = () => {
    let isValid = true;
  
    // Reset validation
    window.$("#tblBodyId tr").each(function () {
      $(this).find("input[name='SalaryComponentsNameInput']").removeClass("is-invalid");
      $(this).find("input[name='dateInput']").removeClass("is-invalid");
    });
  
    // Validate each row
    window.$("#tblBodyId tr").each(function () {
      const holidayNameInput = $(this).find("input[name='SalaryComponentsNameInput']");
      const dateInput = $(this).find("input[name='dateInput']");
  
      if (!holidayNameInput.val()) {
        holidayNameInput.addClass("is-invalid");
        toast.error("Enter Holiday Name");
        isValid = false;
        return false;
      }
  
      if (!dateInput.val()) {
        dateInput.addClass("is-invalid");
        toast.error("Select Holiday Date");
        isValid = false;
        return false;
      }
    });
  
    return isValid;
  };
  
  

  const handleSave = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.API_URL}Payroll/AddPayrollComponent`,
        {
          holidayName: component,
          createdBy: personalInfo.userID,
        }
      );

      if (response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
        setIsLoaderActive(false);

        setComponent("");
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch (error) {
      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        toast.error(error.response.data.message);
      } else {
        toast.error("Please try again later.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllPayrollComponents = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        config.apiEndPoint + "/Payroll/GetAllPayrollComponents"
      );
      const componentsArray = response.data.data || [];
      // console.log("GetAllPayrollComponents ===> ", componentsArray);
      setPayrollComponents(componentsArray);
    } catch (error) {
      console.error("Error fetching components:", error);
      setPayrollComponents([]);
      toast.error("Error fetching components");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleDelete = async (userObj) => {
    try {
      setIsLoaderActive(true);
      const response = await axios.post(
        `${config.apiEndPoint}/Payroll/DeleteComponent/${userObj.autoId}`
      );

      if (response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
        setIsLoaderActive(false);
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch (error) {
      if (error.response && error.response.data) {
        toast.error(error.response.data.message || "An error occurred.");
      } else {
        toast.error("Please try again later.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">
                Manage Holiday List Page
                <span
                  hover-tooltip="In this page you can manage the holidays by additing and deleting holidays by year."
                  tooltip-position="bottom"
                >
                  <i
                    class="fas fa-info-circle"
                    style={{
                      marginLeft: "5px",
                      cursor: "pointer",
                      color: "rgb(0 0 0 / 51%)",
                    }}
                  ></i>
                </span>{" "}
              </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Manage Holiday List page{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="col-md-12">
          {/* First Card Section */}
          <div className="card card-outline card-primary">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <h3 className="card-title">
                    Holiday List{" "}
                    {addNewSectionsDisplay == true ? (
                      <>
                        <span
                          hover-tooltip="In this page you need to select the year and according to year the holiday list will appear and in that holiday list you can add and delete holiday based on company guidelines."
                          tooltip-position="bottom"
                        >
                          <i
                            class="fas fa-info-circle"
                            style={{
                              marginLeft: "5px",
                              cursor: "pointer",
                              color: "rgb(0 0 0 / 51%)",
                            }}
                          ></i>
                        </span>
                      </>
                    ) : null}
                  </h3>

                  <div className="card-tools">
                    <select
                      className="form-control form-control-sm w-50 ml-5"
                      id="userRoleNameInput"
                      style={{ display: "inline-block" }}
                      value={selectedTemplateId}
                      onChange={(e) =>
                        yearDropDownChangeHandler(e.target.value)
                      }
                    >
                      <option value="">Select Year</option>

                      {yearArray.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="col-md-6 float-right">
                  <div className="card-tools float-right mt-1">
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                  {isLoaderActive ? (
                    <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                  ) : addNewSectionsDisplay === false ? (
                    <button
                      className="btn btn-sm float-right btn-primary mr-1"
                      type="button"
                      onClick={() => AddNewPayrollTemplateClickHandler()}
                    >
                      Add New Holiday
                    </button>
                  ) : (
                    <>
                      <button
                        className="btn btn-sm float-right btn-default mr-1"
                        onClick={() =>
                          cancleAddNewPayrollTemplateClickHandler()
                        }
                        type="button"
                      >
                        Cancel
                      </button>
                      {showUpdateOption === true ? (
                        <button
                          className="btn btn-sm float-right btn-primary mr-2"
                          onClick={() => updatePayrollTemplateClickHandler()}
                          type="button"
                        >
                          Update Holiday
                        </button>
                      ) : (
                        <button
                          className="btn btn-sm float-right btn-primary mr-2"
                          onClick={() => savePayrollTemplateClickHandler()}
                          type="button"
                        >
                          Save Holiday Template
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="card-body position-relative">
              {isLoaderActive && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgb(233 236 239 / 81%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 10,
                  }}
                >
                  <i
                    className="fas fa-sync-alt fa-spin"
                    style={{ fontSize: "2rem", color: "#333" }}
                  ></i>
                </div>
              )}
              {addNewSectionsDisplay == true ? (
                <div className="row">
                  <div className="col-md-12 mt-3">
                    <div className="table-responsive">
                      <table
                        id="faqs"
                        className="table table-bordered table-sm "
                      >
                        <thead>
                          <tr className="text-sm">
                            <th width="2%"></th>
                            <th width="6%">Sr. No.</th>
                            <th width="30%">Holiday Name </th>
                            <th width="12%">Date</th>
                            <th width="10%">Holiday Type</th>
                            <th width="6%">Status</th>
                          </tr>
                        </thead>
                        <tbody id="tblBodyId">
                          {holidayComponentsArray.length > 0
                            ? holidayComponentsArray.map((data, index) => (
                                <tr key={index}>
                                  <td
                                    className="text-center"
                                    style={{ background: "#238edc" }}
                                  >
                                    <span className="handle ui-sortable-handle mt-5">
                                      <i className="fas fa-ellipsis-v"></i>
                                      <i className="fas fa-ellipsis-v"></i>
                                    </span>
                                  </td>
                                  <td custAttr={index}>{index + 1}</td>
                                  <td>
                                    <input
                                      type="text"
                                      name="SalaryComponentsNameInput"
                                      className="form-control form-control-sm"
                                      ref={(el) =>
                                        (holinamecomponent.current[index] = el)
                                      }

                                      value={data.holidayName || ""}
                                      onChange={(e) =>
                                        handleSalaryComponentsNameChange(
                                          e,
                                          index,
                                          "SalaryComponentsNameInput"
                                        )
                                      }
                                      placeholder="Enter Holiday Name "
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="date"
                                      name="dateInput"
                                      placeholder="Select Date"
                                      value={data.holidayDate || ""}
                                      ref={(el) =>
                                        (holidatecomponent.current[index] = el)
                                      }
                                      onChange={(e) =>
                                        handleSalaryComponentsNameChange(
                                          e,
                                          index,
                                          "date"
                                        )
                                      }
                                      className="form-control form-control-sm"
                                    />
                                  </td>
                                  <td>
                                    <select
                                      className="form-control form-control-sm"
                                      id="dateOrRupees"
                                      defaultValue={data.holidayType}
                                      onChange={(e) =>
                                        dateOrRupeesChangeHandler(
                                          e.target.value,
                                          index
                                        )
                                      }
                                    >
                                      <option value="compulsory">
                                        Compulsory
                                      </option>
                                      <option value="optional">Optional</option>
                                    </select>
                                  </td>
                                  <td>
                                    <span
                                      className="btn btn-outline-danger btn-sm cursor-pointer"
                                      onClick={() =>
                                        removeComponentFromArray(index)
                                      }
                                      title="Delete"
                                    >
                                      <i className="fas fa-trash"></i>
                                    </span>
                                  </td>
                                </tr>
                              ))
                            : null}
                        </tbody>
                      </table>
                    </div>
                    <div className="text-right">
                      <button
                        onClick={() => addNewSalaryComponents()}
                        className="btn btn-sm float-right btn-light"
                      >
                        + Add New Holiday Components
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <h4></h4>
              )}
            </div>
          </div>
        </div>
      </div>
      <div
        class="modal fade"
        id="deleteModal"
        data-backdrop="static"
        data-keyboard="false"
        tabindex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          class="modal-dialog modal-sm modal-dialog-centered"
          role="document"
        >
          <div class="modal-content">
            <div class="modal-header">
              <h6 class="modal-title w-100 text-center" id="exampleModalLabel2">
                Are you sure?
              </h6>
              <button
                type="button"
                onClick={() => hideModal()}
                class="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body justify-content-center">
              <i
                class="w-100 text-center text-warning mb-3 fa fa-ban"
                style={{ fontSize: "3rem" }}
              ></i>
              <h6 class="text-center">
                Do you really want to delete these payroll template?
              </h6>
              <h6 class="text-center text-danger">
                This process cannot be undone.
              </h6>
            </div>
            <div class="modal-footer justify-content-center">
              <button
                type="button"
                class="btn btn-secondary"
                onClick={() => hideModal()}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-danger"
                onClick={() => confirmDeleteTemplate()}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id="showModal"
        data-backdrop="static"
        data-keyboard="false"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          className="modal-dialog modal-md modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="mb-0">Create New Payroll Component</h5>
              <button
                type="button"
                onClick={closeModal}
                className="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body justify-content-center">
              <div className="row">
                <div className="col-md-8">
                  <label>Component Name</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={component}
                    placeholder="Enter Component Name"
                    ref={inputComponentReference}
                    onChange={(e) => setComponent(e.target.value)}
                  />
                </div>
                <div
                  className="col-md-4 d-flex pl-4"
                  style={{ alignItems: "flex-end" }}
                >
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm mr-2"
                    onClick={closeModal}
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={handleSave}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <table className="table table-bordered table-striped table-sm">
                <thead>
                  <tr className="text-sm">
                    <th className="text-center">Sr. No.</th>
                    <th className="text-center">Component Name </th>
                    <th className="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {payrollComponents.length > 0 ? (
                    payrollComponents.map((userObj, index) => (
                      <tr
                        key={index}
                        style={{
                          textDecoration:
                            userObj.isDeleted == true ? "line-through" : "none",
                        }}
                      >
                        <td
                          style={{ fontWeight: 400, fontSize: "smaller" }}
                          className="text-center text-sm"
                        >
                          {index + 1}
                        </td>
                        <td style={{ fontWeight: 400, fontSize: "smaller" }}>
                          {userObj.holidayName || "N/A"}
                        </td>
                        <td
                          style={{ fontWeight: "400", fontSize: "smaller" }}
                          onClick={(e) => {
                            handleDelete(userObj);
                          }}
                          className="text-center text-sm"
                        >
                          {!userObj.isDeleted && (
                            <button
                              type="button"
                              className="btn bg-gradient-danger btn-xs ml-2"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="text-center text-muted">
                        No Payroll Components Available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-center" />
    </>
  );
}

export default Holiday;
