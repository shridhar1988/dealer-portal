import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
// import PleaseWaitButton from '../../shared/PleaseWaitButton';

function HolidayList() {
  const [holidays, setHolidays] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    window.$("#DateV").datetimepicker({
      format: "YYYY",
    });
    window.initDatePickerFuncation();
    const datePicker = window.$("#DateV");

    datePicker.on("change.datetimepicker", (e) => {
      let date = e.date ? e.date.format("YYYY") : e.target.value;
      if (!date) {
        console.error("No valid date provided.");
        return;
      }
      setSelectedYear(parseInt(date, 10));
    });

    return () => {
      datePicker.off("change.datetimepicker");
    };
  }, []);

  useEffect(() => {
    fetchHolidays(selectedYear);
  }, [selectedYear]);

  const fetchHolidays = async (year) => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Holiday/GetAllHolidayByYear?year=${year}`
      );
      const componentsArray = response.data.data || [];
      // console.log("Holidays fetched ===> ", componentsArray);
      setHolidays(componentsArray);
    } catch (error) {
      console.error("Error fetching holidays:", error);
      setHolidays([]);
      toast.error("Error fetching holidays");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleYearChange = (event) => {
    const year = event.target.value;
    if (year && !isNaN(year)) {
      // alert();
      setSelectedYear(parseInt(year, 10));
    }
  };

  // Table Search
  const searchedEmployees = holidays.filter((row) =>
    Object.values(row).some(
      (val) =>
        val && val.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  // Pagination Calculation
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = searchedEmployees.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(searchedEmployees.length / rowsPerPage);

  // Calculate the range of displayed entries
  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, searchedEmployees.length);

  // Page Change Handler
  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  // Export to CSV
  const exportToCSV = () => {
    let csvContent = "Holiday Name,Holiday Date,Holiday Type\n";

    holidays.forEach((row) => {
      csvContent += `${row.holidayName},${row.holidayDate},${row.holidayType}\n`;
    });

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "HolidayData.csv");
  };

  // Export to Excel
  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      holidays.map((row) => ({
        "Holiday Name": row.holidayName,
        "Holiday Date": row.holidayDate,
        "Holiday Type": row.holidayType,
      }))
    );

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Holidays");

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });

    saveAs(data, "HolidayData.xlsx");
  };

  // Export to PDF
  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Holiday List", 14, 10);

    autoTable(doc, {
      head: [["Holiday Name", "Holiday Date", "Holiday Type"]],
      body: holidays.map((row) => [
        row.holidayName,
        row.holidayDate,
        row.holidayType,
      ]),
    });

    doc.save("HolidayData.pdf");
  };

  // Print Table
  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");

    printWindow.document.write(
      "<html><head><title>Print Holiday Data</title></head><body>"
    );
    printWindow.document.write(
      "<table border='1' cellspacing='0' cellpadding='5'><tr>"
    );
    printWindow.document.write(
      "<th>Holiday Name</th><th>Holiday Date</th><th>Holiday Type</th>"
    );
    printWindow.document.write("</tr>");

    holidays.forEach((row) => {
      printWindow.document.write(
        `<tr><td>${row.holidayName}</td><td>${row.holidayDate}</td><td>${row.holidayType}</td></tr>`
      );
    });

    printWindow.document.write("</table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">
                Holiday List
                <span
                  hover-tooltip="In this page you can see the holidays for the current year, both mandatory and optional according to your company guidelines."
                  tooltip-position="bottom"
                >
                  <i
                    className="fas fa-info-circle"
                    style={{
                      marginLeft: "5px",
                      cursor: "pointer",
                      color: "rgb(0 0 0 / 51%)",
                    }}
                  ></i>
                </span>
              </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">Holiday List page</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid px-3">
        <div className="card card-outline card-primary">
          <div className="card-header p-0 px-3">
            <div className="row align-items-center">
              <div className="col-md-10">
                <h3 className="card-title">
                  Holiday List{" "}
                  <span
                    hover-tooltip="This page contains lists of holidays"
                    tooltip-position="bottom"
                  >
                    <i
                      className="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h3>
              </div>
              <div className="col-md-2 float-right">
                <div className="card-tools row mt-2">
                  <div className="col-md-10 form-group">
                    <div
                      className="input-group"
                      id="year"
                      data-target-input="nearest"
                    >
                      <input
                        type="number"
                        id="DateV"
                        className="form-control form-control-sm"
                        value={selectedYear}
                        onChange={handleYearChange}
                        placeholder="Select Year"
                      />
                      <div
                        className="input-group-append"
                        custDatePicker
                        data-target="#DateV"
                        data-toggle="datetimepicker"
                      >
                        <div className="input-group-text">
                          <i className="fa fa-calendar"></i>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-1 mt-1">
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body text-sm position-relative">
            {isLoaderActive && (
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  backgroundColor: "rgb(233 236 239 / 81%)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  zIndex: 10,
                }}
              >
                <i
                  className="fas fa-sync-alt fa-spin"
                  style={{ fontSize: "2rem", color: "#333" }}
                ></i>
              </div>
            )}
            <div className="d-flex justify-content-between mb-2">
              <div>
                <button
                  className="btn btn-default btn-sm mr-1 exportBtn"
                  onClick={exportToCSV}
                >
                  Export CSV
                </button>
                <button
                  className="btn btn-default btn-sm mr-1 exportBtn"
                  onClick={exportToExcel}
                >
                  Export Excel
                </button>
                <button
                  className="btn btn-default btn-sm mr-1 exportBtn"
                  onClick={exportToPDF}
                >
                  Export PDF
                </button>
                <button
                  className="btn btn-default btn-sm mr-1 exportBtn"
                  onClick={printTable}
                >
                  Print
                </button>
              </div>

              <input
                type="text"
                className="form-control form-control-sm w-25"
                placeholder="Search..."
                onChange={(e) => setSearchText(e.target.value)}
              />
            </div>

            <table className="table table-bordered table-sm table-striped">
              <thead>
                <tr>
                  <th
                    style={{
                      fontWeight: "500",
                      fontSize: "smaller",
                      width: "7%",
                    }}
                    className="text-center"
                  >
                    Sr. No.
                  </th>
                  <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                    Holiday Name
                  </th>
                  <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                    Holiday Date
                  </th>
                  <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                    Holiday Type
                  </th>
                </tr>
              </thead>
              <tbody>
                {currentRows.length > 0 ? (
                  currentRows.map((roleObj, index) => (
                    <tr key={index}>
                      <td
                        style={{ fontWeight: "400", fontSize: "smaller" }}
                        className="text-center text-sm"
                      >
                        {index + 1}
                      </td>
                      <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                        {roleObj.holidayName}
                      </td>
                      <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                        {roleObj.holidayDate}
                      </td>
                      <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                        {roleObj.holidayType}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="text-center">
                      No holidays available
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {/* Pagination */}
            <div className="d-flex justify-content-between mt-2">
              <div>
                Showing {startEntry} to {endEntry} of {searchedEmployees.length}{" "}
                entries
              </div>
              <div>
                <button
                  className="btn btn-xs btn-outline-primary"
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                >
                  <i className="fas fa-angle-double-left"></i>
                </button>
                <span className="m-1">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  className="btn btn-xs btn-outline-primary"
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                >
                  <i className="fas fa-angle-double-right"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}

export default HolidayList;
