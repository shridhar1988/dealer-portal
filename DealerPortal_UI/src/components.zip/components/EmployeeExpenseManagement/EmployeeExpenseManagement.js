import React, { useRef, useEffect, useState } from "react";
import axios from "axios";
import config from "../../config/config.json";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


function EmployeeExpenseManagement() {
  const [allExpenseArray, setAllExpeneseArray] = useState([]);
  const [allEmployeeArray, setAllEmployeeArray] = useState([]);
  const [empIdToNameMap, setEmpIdToNameMap] = useState({});
  const [remark, setRemark] = useState("");
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [showSelecteduser, setShowSelecteduser] = useState(false);
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [showModal_second, setShowModal_second] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchText, setSearchText] = useState("");
  const rowsPerPage = 10;

  const searchedExpenses = allExpenseArray.filter((row) =>
    Object.values(row).some(
      (val) =>
        val && val.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = searchedExpenses.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(searchedExpenses.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, searchedExpenses.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };



  useEffect(() => {
    GetAllEmployeeExpense();
    window.initDataTable();
    GetallEmployees();
  }, []);

  const ShowSelectedUser = (expense) => {
    // console.log("Selected Expense: ", expense);
    setSelectedExpense(expense);
    setShowSelecteduser(true);
  };

  const handleCloseContent = () => {
    setShowSelecteduser(false);
    setTimeout(() => {
      window.initDataTable();
    }, 500);
  };

  const handleClose = (e) => {
    setIsRejectModalVisible(false);
    setRemark("");
  };

  const handlePostRemark = async () => {
    PostRemark(remark);
  };

  const handleOpenRejectModal = () => {
    setIsRejectModalVisible(true);
  };

  const formattedTotal =
    selectedExpense?.expenseDetails?.length > 0
      ? new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
      }).format(
        selectedExpense.expenseDetails.reduce((total, detail) => {
          return total + (detail.amount || 0);
        }, 0)
      )
      : "N/A";

  const GetAllEmployeeExpense = async () => {
    setIsLoaderActive(true);
    // debugger;

    try {
      const response = await axios.get(
        config.apiEndPoint + "/ExpenseManagment/GetAllExpenses"
      );
      const appsArray = response.data.data || [];
      // console.log("appsArray ===> ", appsArray);
      setAllExpeneseArray(appsArray || []);

      setTimeout(() => {
        window.initDataTable();
      }, 1000);


    } catch(error) {
      console.error("Error fetching Expense Data", error);
      toast.error("Error fetching Data");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleApprove = async (selectedexpense) => {
    setIsLoaderActive(true);

    // console.log("Selected Expense: ", selectedexpense);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/ExpenseManagment/AcceptExpenseById?id=${selectedexpense}`
      );
      console.log("Response: ", response);
      if(response.data.success == true) {
        toast.success(response.data.message);
        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      toast.error("Failed to approve Expense!");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const PostRemark = async (remark) => {

    if (remark.trim() === "") {
      toast.error("Please enter remark");
        return false;
    }
    setIsLoaderActive(true);
    // console.log("Selected Expense: ", selectedExpense.id);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/ExpenseManagment/RejectExpenseById?id=${selectedExpense.id
        }&remark=${encodeURIComponent(remark)}`
      );
      if(response.data.success == true) {
        toast.success("Remark Sent!");
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch(error) {
      toast.error("Failed to send remark!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetallEmployees = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        config.apiEndPoint + "/AuthMaster/GetAllEmpInfo"
      );
      const empArray = response.data.data || [];
      // console.log("appsArray ===> ", empArray);
      const empMap = [];
      empArray.forEach((emp) => {
        empMap[emp.empId] = emp.firstName; // Assuming `name` is the property holding the employee's name
      });
      setEmpIdToNameMap(empMap || []);
      setAllEmployeeArray(empArray || []);
    } catch(error) {
      console.error("Error fetching Employee Data", error);
      toast.error("Error fetching Data");
    } finally {
      setIsLoaderActive(false);
    }
  };


  const exportToCSV = () => {
    let csvContent = "Employee Name,Expense Type,From Date,To Date,Status\n";
    allExpenseArray.forEach((row) => {
      const status = row.status || "Pending";
      csvContent += `${empIdToNameMap[row.empId]},${row.expenseHeading},${new Date(row.fromDate).toLocaleDateString("en-GB")},${new Date(row.toDate).toLocaleDateString("en-GB")},${status}\n`;
    });
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "ExpenseData.csv");
  };



  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      allExpenseArray.map((row) => ({
        "Employee Name": empIdToNameMap[row.empId],
        "Expense Type": row.expenseHeading,
        "From Date": new Date(row.fromDate).toLocaleDateString("en-GB"),
        "To Date": new Date(row.toDate).toLocaleDateString("en-GB"),
        Status: row.status || "Pending",
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Expenses");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
    });
    saveAs(data, "ExpenseData.xlsx");
  };
  

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Expense List", 14, 10);
    autoTable(doc, {
      head: [["Employee Name", "Expense Type", "From Date", "To Date", "Status"]],
      body: allExpenseArray.map((row) => [
        empIdToNameMap[row.empId],
        row.expenseHeading,
        new Date(row.fromDate).toLocaleDateString("en-GB"),
        new Date(row.toDate).toLocaleDateString("en-GB"),
        row.status || "Pending"
      ]),
    });
    doc.save("ExpenseData.pdf");
  };
  


  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print</title>");
    printWindow.document.write("<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #000; padding: 8px; text-align: left; }</style>");
    printWindow.document.write("</head><body>");
    printWindow.document.write("<h3>Expenses List</h3>");
    printWindow.document.write("<table><thead><tr><th>Employee Name</th><th>Expense Type</th><th>From Date</th><th>To Date</th><th>Status</th></tr></thead><tbody>");
  
    allExpenseArray.forEach((exp) => {
      const empName = empIdToNameMap[exp.empId] || "Unknown";
      const fromDate = new Date(exp.fromDate).toLocaleDateString("en-GB");
      const toDate = new Date(exp.toDate).toLocaleDateString("en-GB");
      const status = exp.status || "Pending";
      printWindow.document.write(`
        <tr>
          <td>${empName}</td>
          <td>${exp.expenseHeading}</td>
          <td>${fromDate}</td>
          <td>${toDate}</td>
          <td>${status}</td>
        </tr>
      `);
    });
  
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };
  



  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">
                Manage Employee Reimbursement{" "}
                <span
                  hover-tooltip="In this page you can manage the reimbursement request."
                  tooltip-position="bottom"
                >
                  <i
                    class="fas fa-info-circle"
                    style={{
                      marginLeft: "5px",
                      cursor: "pointer",
                      color: "rgb(0 0 0 / 51%)",
                    }}
                  ></i>
                </span>{" "}
              </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Manage Employee Expense{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="card card-outline card-primary">
          <div className="card-header">
            <div className="row d-flex  justify-content-between">
              {showSelecteduser === false ? (
                <>
                  <div className="card-title">
                    <h5>Manage Reimbursement</h5>
                  </div>
                </>
              ) : (
                <>
                  <div className="card-title">
                    <h5>{empIdToNameMap[selectedExpense.empId]}'s Expense Details</h5>
                  </div>
                  <div className="float-right ml-auto">
                    <button
                      className="btn btn-default btn-sm float-end"
                      onClick={() => handleCloseContent()}
                    >
                      Close
                    </button>
                  </div>
                </>
              )}

              <div className="card-tools">
                <button
                  type="button"
                  className="btn btn-tool"
                  data-card-widget="maximize"
                >
                  <i className="fas fa-expand"></i>
                </button>
              </div>
            </div>
          </div>
          <div className="card-body position-relative">
            {isLoaderActive && (
              <div
                style={{
                  position: "absolute",
                  top: 0,
                  left: 0,
                  width: "100%",
                  height: "100%",
                  backgroundColor: "rgb(233 236 239 / 81%)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  zIndex: 10,
                }}
              >
                <i
                  className="fas fa-sync-alt fa-spin"
                  style={{ fontSize: "2rem", color: "#333" }}
                ></i>
              </div>
            )}
            {showSelecteduser == false ? (
              <div className="row">
                <div className="col-md-12">
                  <div className="d-flex justify-content-between mb-2">
                    <div>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>
                        Export CSV
                      </button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>
                        Export Excel
                      </button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>
                        Export PDF
                      </button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                    </div>
                    <input
                      type="text"
                      className="form-control form-control-sm w-25"
                      placeholder="Search..."
                      onChange={(e) => setSearchText(e.target.value)}
                    />
                  </div>
                  <table
                    className="table table-bordered table-sm table-striped tableBody"
                  >
                    <thead>
                      <tr className="text-sm">
                        <th>Sr No.</th>
                        <th>Employee Name</th>
                        <th>Expense Type</th>
                        <th>From Date</th>
                        <th>To Date</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentRows.length > 0 ? (
                        currentRows.map((expense, index) => (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{empIdToNameMap[expense.empId]}</td>
                            <td>{expense.expenseHeading}</td>

                            <td>
                              {new Date(expense.fromDate).toLocaleDateString(
                                "en-GB"
                              )}
                            </td>
                            <td>
                              {new Date(expense.toDate).toLocaleDateString(
                                "en-GB"
                              )}
                            </td>
                            <td>
                              <span
                                className={
                                  expense.status === "pending"
                                    ? "badge rounded-pill bg-warning text-light"
                                    : expense.status === "Processing"
                                      ? "badge rounded-pill bg-yellow text-white text-light" // Orange for "Processing"
                                      : expense.status === "processed"
                                        ? "badge rounded-pill bg-success text-white text-light" // Green for "Processed"
                                        : expense.status === "rejected" || expense.status === "deleted"
                                          ? "badge rounded-pill bg-danger"
                                          : "badge rounded-pill bg-secondary"
                                }
                                style={{ textTransform: "uppercase" }}
                              >
                                {expense.status || "Pending"}
                              </span>
                            </td>
                            <td onClick={() => ShowSelectedUser(expense)}>
                              <button className="btn btn-outline-info btn-sm cursor-pointer mr-1">
                                <i class="fas fa-eye"></i>
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="7" className="text-center">
                            No data available
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>

                  <div className="d-flex justify-content-between mt-2">
                    <div>
                      Showing {startEntry} to {endEntry} of {searchedExpenses.length} entries
                    </div>
                    <div>
                      <button
                        className="btn btn-xs btn-outline-primary"
                        onClick={() => handlePageChange(currentPage - 1)}
                        disabled={currentPage === 1}
                      >
                        <i className="fas fa-angle-double-left"></i>
                      </button>
                      <span className="m-1">
                        Page {currentPage} of {totalPages}
                      </span>
                      <button
                        className="btn btn-xs btn-outline-primary"
                        onClick={() => handlePageChange(currentPage + 1)}
                        disabled={currentPage === totalPages}
                      >
                        <i className="fas fa-angle-double-right"></i>
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            ) : null}
            {showSelecteduser == true && selectedExpense ? (
              <div className="row">
                <div className="col-md-6">
                  <label>Name</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={
                      empIdToNameMap[selectedExpense.empId] ||
                      "Unknown Employee"
                    }
                    disabled
                  />
                </div>
                <div className="col-md-6">
                  <label>Expense Type</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={selectedExpense.expenseHeading}
                    disabled
                  />
                </div>
                <div className="col-md-12 mt-4">
                  <table className="table table-bordered table-sm table-striped tableBody">
                    <thead>
                      <tr className="text-sm">
                        <th>Sr No.</th>
                        <th>Expense Detail</th>
                        <th>Expense Date</th>
                        <th>Amount</th>
                        <th>Attachments</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedExpense.expenseDetails.length > 0 ? (
                        selectedExpense.expenseDetails.map((detail, index) => (
                          <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{detail.expenseDescription}</td>
                            <td>
                              {new Date(detail.date).toLocaleDateString(
                                "en-GB"
                              )}
                            </td>
                            <td>{detail.amount || "N/A"}</td>{" "}
                            {/* Handle missing amounts */}
                            <td>
                              {detail.filePath ? (
                                <a
                                  href={config.file_URL + detail.filePath}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="btn btn-outline-info btn-sm cursor-pointer mr-1"
                                >
                                  <i className="fas fa-eye"></i>
                                </a>
                              ) : (
                                "No Attachment"
                              )}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="3" className="text-center">
                            No expense details available
                          </td>
                        </tr>
                      )}
                    </tbody>
                    <tfoot>
                      <tr>
                        <td></td>
                        <td></td>
                        <td>
                          <strong>Total : </strong>
                        </td>
                        <td>
                          <strong>{formattedTotal || "N/A"}</strong>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                <div className="col-md-12">
                  {selectedExpense.status === null && (
                    <>
                      <button
                        className="btn btn-primary float-right btn-sm"
                        onClick={() => handleApprove(selectedExpense.id)}
                      >
                        Approve
                      </button>

                      <button
                        className="btn btn-danger float-right mr-2 btn-sm"
                        onClick={handleOpenRejectModal}
                      >
                        Reject
                      </button>
                    </>
                  )}

                  {selectedExpense.status === "Processing" && (
                    <button
                      className="btn btn-secondary float-right btn-sm"
                      onClick={() => handleApprove(selectedExpense.id)}
                    >
                      Processed
                    </button>
                  )}
                </div>
              </div>
            ) : null}
            {showModal_second ? (
              <>
                <div
                  className="modal fade show"
                  id="modal-default"
                  style={{
                    display: "block",
                    paddingRight: "17px",
                    boxShadow: "#5d5858b 8",
                    backgroundColor: "#5d5858b8",
                  }}
                  aria-modal="true"
                  role="dialog"
                >
                  <div className="modal-dialog">
                    <div className="modal-content">
                      <div class="modal-header">
                        <h4 class="modal-title">Approve Expense</h4>
                        <button
                          type="button"
                          class="close btn-secondary"
                          data-dismiss="modal"
                          aria-label="Close"
                          onClick={() => {
                            setShowModal_second(false);
                          }}
                        >
                          <span aria-hidden="true">×</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : null}
            {isRejectModalVisible && (
              <div
                className="modal fade show"
                id="modal-default"
                style={{
                  display: "block",
                  paddingRight: "17px",
                  boxShadow: "#5d5858b 8",
                  backgroundColor: "#5d5858b8",
                }}
                aria-modal="true"
                role="dialog"
              >
                <div className="modal-dialog">
                  <div className="modal-content">
                    <div class="modal-header">
                      <h4 class="modal-title">
                        Remark<span className="text-danger"> *</span>{" "}
                        <span
                          hover-tooltip="Describe your remark"
                          tooltip-position="bottom"
                        >
                          <i
                            className="fas fa-info-circle my-1 ml-2"
                            style={{ color: "rgb(0 0 0 / 51%)" }}
                          ></i>
                        </span>
                      </h4>
                      <button
                        type="button"
                        class="close btn-secondary"
                        data-dismiss="modal"
                        aria-label="Close"
                        onClick={() => {
                          setIsRejectModalVisible(false);
                        }}
                      >
                        <span aria-hidden="true">×</span>
                      </button>
                    </div>
                    <div class="modal-body">
                    <p>
                            Are you sure you want to reject the employee reimbursement<strong></strong>?
                          </p>
                      <textarea
                        class=" w-100 form-control"
                        placeholder="Describe your remark"
                        value={remark} // Controlled input
                        onChange={(e) => setRemark(e.target.value)} // Update state on change
                      />
                    </div>
                    <div class="modal-footer justify-content-between">
                      <button
                        type="button"
                        class="btn btn-secondary closebtn"
                        data-dismiss="modal"
                        onClick={() => {
                          handleClose();
                        }}
                      >
                        Close
                      </button>
                      <button
                        type="button"
                        className="btn btn-primary savebtn"
                        onClick={handlePostRemark} // Call handleSend on click
                      >
                        Send
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}

export default EmployeeExpenseManagement;
