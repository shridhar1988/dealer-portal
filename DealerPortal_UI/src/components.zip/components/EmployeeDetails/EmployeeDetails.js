import React, { useRef, useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import default_image from "../../assets/images/default_img.png";
import { ToastContainer, toast } from "react-toastify";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import axios from "axios";
import $ from "jquery";
import config from "../../config/config.json";
import "./EmployeeDetails.css";

const EmployeeDetails = () => {
  const [subModuleID, setSubModuleID] = useState(null);
  const [jsonData, setJsonData] = useState(null);
  const toastId = React.useRef(null);
  const inputJoiningDateReference = useRef(null);
  const emailref = useRef(null);
  const departmentref = useRef(null);
  const managerref = useRef(null);
  const deisgnationref = useRef(null);
  const joiningdateref = useRef(null);
  const ctcref = useRef(null);
  const templateref = useRef(null);

  const [documentsObject, setDocumentsObject] = useState([]);
  const [allTempalatesArray, setAllTempalatesArray] = useState([]);
  const currentYear = new Date().getFullYear();
  const [documentsName, setDocumentsName] = useState([]);
  const [showbtn, setShowbtn] = useState(false);
  const [showRejectAcceptBtn, setShowRejectAcceptBtn] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [showModal_second, setShowModal_second] = useState(false);
  const [profileImage, setProfileImage] = useState("");
  const [remark, setRemark] = useState("");
  const [verificationInput, setVerificationInput] = useState("");
  const [isEditable, setIsEditable] = useState(false);
  const [email, setEmail] = useState("");
  const [ctcvalue, setctcvalue] = useState("");
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [empName, setEmpName] = useState(false);
  const [empContact, setEmpContact] = useState(false);
  const [empEmail, setEmpEmail] = useState(false);
  const [allDepartment, setAllDepartment] = useState("");
  const [allManager, setAllManager] = useState([]);
  const [allDeptManager, setAllDeptManager] = useState([]);
  const [designation, setDesignation] = useState("");
  const [acceptRemark, setAcceptRemark] = useState("");
  const [rejectRemark, setRejectRemark] = useState("");
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [selectedManager, setSelectedManager] = useState("");
  const [selectedtemplate, setSelectedTemplate] = useState("");
  const [profilePath, setProfilePath] = useState("");
  const [appendIndexId, setAppendIndexId] = useState(1);
  const [isProbation, setIsProbation] = useState(false);
  const [joiningDate, setJoiningDate] = useState(null);
  const today = new Date().toISOString().split("T")[0];
  const [adharVarified, setAdharVarified] = useState(false);
  const [panVarified, setPanVarified] = useState(false);
  const [isModal, setIsModal] = useState(true);
  const [showbutton, setShowButton] = useState(false);
  const [declarations, setDeclarations] = useState([]);

  const navigate = useNavigate();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  
  const selectedEmployeeDetails = useSelector(
    (state) => state.selectedEmployeeInformationReducer
  );
  const [getEditOnboardingEmployeeAccess, setGetEditOnboardingEmployeeAccess] =
    useState(false);
  const showAcceptRejectButton = localStorage.getItem(
    "setShowAcceptRejectButton"
  );
  const isEmployeeActive = localStorage.getItem("isEmployeeActive");
  const isDeleted = localStorage.getItem("isDeleted");

  const [checkThisForAttachmentClick, setCheckThisForAttachmentClick] =
    useState("");

  const inputAccNoReference = useRef(null);
  const inputBankNameReference = useRef(null);
  const inputAccHolderNameReference = useRef(null);
  const inputBranchNameReference = useRef(null);
  // const inputBranchAddressReference = useRef(null);
  const inputConfirmAccNoReference = useRef(null);
  const inputIfscCodeReference = useRef(null);

  const [bankData, setBankData] = useState("");
  const [bank, setBank] = useState("");
  const [bankName, setBankName] = useState("");
  const [accHolderName, setAccHolderName] = useState("");
  const [confirmAccountNumber, setConfirmAccountNumber] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [branchName, setBranchName] = useState("");
  const [ifscCode, setIfscCode] = useState("");
  // const [branchAddress, setBranchAddress] = useState("");
  const [hasError, setHasError] = useState(false);
  const [salaryComponentsArray, setSalaryComponentsArray] = useState([]);
  const [showModalAccept, setShowModalAccept] = useState(false);
  const [showModalReject, setShowModalReject] = useState(false);
  const [selectedEmpInfo, setSelectedEmpInfo] = useState("");

  $(document).ready(function () {
    $(document)
      .off("click", ".verify-btn")
      .on("click", ".verify-btn", function () {
        if (!$(this).hasClass("verified")) {
          const parentDiv = $(this).parent(); // Get this.parent()
          const prevDiv = parentDiv.prev();
          setCheckThisForAttachmentClick(prevDiv.find("input").attr("name"));
          $(".modal-verify-document-class").removeClass("d-none");
        }
      });
  });

  const GetSelectedEmpInfo = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetEmpInfoByEmpId?id=${selectedEmployeeDetails.selectedEmployeeID}`
      );
      
      if (response.data.success == true) {
       
        setSelectedEmpInfo(response.data.data); // Store data in state
        setProfilePath(response.data.data.userInfo.picDbPath ||response.data.data.userInfo.profilePath || "" );
      } else {
        setSelectedEmpInfo("");
        // console.error("Error fetching empInfo:");
      }
    } catch (error) {
      setSelectedEmpInfo("");
      // console.error("Error fetching empInfo:");
    }
  };
  const handleErrorToast = (error) => {
    if (!toast.isActive(toastId.current)) {
      toast.error(error, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
    
  };


  const [probationPeriod, setProbationPeriod] = useState(false);
 
 
  const handleProbationChange = (e) => {
    setIsProbation(e.target.checked ? true : false); // Set value to 1 if checked, 0 otherwise
  };
  
  const handleErrorToastUsingMessage = (message) => {
    if (!toast.isActive(toastId.current)) {
      toast.error(message, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };
  const handleSuccesToastWithMessage = (message) => {
    if (!toast.isActive(toastId.current)) {
      toast.success(message, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };
  const setDepartment = (e) => {
    const department = e.target.value;
    setSelectedDepartment(department);
    GetAllManagerByDept(department);
    departmentref.current.classList.remove("is-invalid");
  };
  const handleClose = (e) => {
    setShowModal(false);
    setRemark("");
    setShowModal_second(false);
    setEmail("");
    setSelectedManager("");
    // setDepartment("");
    setProbationPeriod(false);  

    setDesignation("");
    setJoiningDate("");
    setSelectedTemplate("");
    setctcvalue("");
    setVerificationInput("");
    setIsProbation(false);
    $(".modal-verify-document-class").addClass("d-none");
  };
  const handleAcceptClose = () => {
    setShowModalAccept(false);
    setAcceptRemark("");
  };
  const handleRejectClose = () => {
    setShowModalReject(false);
    setRejectRemark("");
  };
  // Get Json Data
  const getSubModuleJsonByUserId = async (empId, formId) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AdminFormFormat/GetUserJsonDataByUserIdANDFormId`,
        {
          params: { empId, formId },
        }
      );

      if (response.data.success === "True") {
        if (response.data.data.isData === "True") {
          // console.log("form data------->", response.data.data);
          // console.log("adhar------->", response.data.data.isAdharVarified);

          setAdharVarified(response.data.data.isAdharVarified ? response.data.data.isAdharVarified : false);
          setPanVarified(response.data.data.isPanVarified ? response.data.data.isPanVarified : false);

          setJsonData(response.data.data.data.jsonData);
          // console.log("response--->", response.data.data.data.jsonData);

          return response.data.data.data.jsonData;
        } else {
          const response = await axios.get(
            `${config.apiEndPoint}/AdminFormFormat/GetFormFormatById/1/${formId}`
          );

          if (response.data.success === "True") {
            // console.log("form data------->", response.data.data);

            setJsonData(response.data.data.jsonData);
            return response.data.data.jsonData;
          } else {
            return false;
          }
        }
      } else {
        return false;
      }
    } catch (error) {
      console.error("Error fetching form data:", error);
      return false;
    }
  };
  const loadData = async (subModuleId) => {
    setSubModuleID(subModuleId);
    if (showAcceptRejectButton == "t") {
      setShowRejectAcceptBtn(true);
    } else {
      setShowRejectAcceptBtn(false);
    }
    $("#dynamic-form-container-home").html();
    const getResult = await getSubModuleJsonByUserId(
      selectedEmployeeDetails.selectedEmployeeID,
      subModuleId
    );

    addDetails("dynamic-form-container-home", getResult);

    // if(!getEditOnboardingEmployeeAccess){
    //   $(".add-more").hide();
    //   $(".remove-more").hide();
    //   $(".Removebtn").addClass("d-none");

    // } else {
    //   $(".add-more").show();
    //   $(".remove-more").show();
    // }
  };
  const addDetails = (id, getJsonData) => {
    if (getJsonData) {
      const $ = window.jQuery;
      const formContainer = document.getElementById(id);
      if (formContainer) {
        $(formContainer).formRender({ formData: getJsonData });
        fileUploadDiv();
        // Calling the function to find file path
        const filePath = findFilePath(JSON.parse(getJsonData));
        if (filePath != null) {
          const container = $(".profile-upload-field").closest(
            ".formbuilder-file"
          );
          container.find(".image-preview").remove();
          container.append(
            '<img src="' +
              filePath +
              '" class="image-preview" alt="Image Preview" />'
          );
        }

        // // // console.log("filePath----------->>>>>>>", filePath); // Output the filePath
        if (filePath != null) {
          const container = $(".profile-upload-field").closest(
            ".formbuilder-file"
          );
          container.find(".image-preview").remove();
          container.append(
            '<img src="' +
              filePath +
              '" class="image-preview" alt="Image Preview" />'
          );
        }

        // Calling the function for document path
        const fileDocumentPath = findDocumentFilePath(JSON.parse(getJsonData));
        // // // console.log("fileDocumentPath----------->>>>>>>", fileDocumentPath); // Output the fileDocumentPath
        const containerr = $(".profile-upload-field").closest(
          ".formbuilder-file"
        );

        // Apply custom script for additional functionality
        const script = document.createElement("script");
        script.innerHTML = `
          $(document).ready(function() {
            const formData = ${JSON.stringify(getJsonData)};
            // Apply dynamic classes for file upload fields
            $('.formbuilder-file').each(function(i, obj) {
              if($(this).find('input').attr('class') == "profile-upload-field") {
                $(this).addClass('profile-upload-field-label');
              }
            });
            $('.formbuilder-file').each(function(i, obj) {
              if($(this).find('input').attr('class') == "document-upload-field") {
                $(this).addClass('document-upload-field-label');
              }
            });
          });
        `;
        document.body.appendChild(script);

        // Apply the 'row' class to the rendered form
        const renderedForm = $(formContainer).find(".rendered-form");
        if (renderedForm.length) {
          renderedForm.addClass("row");
        }

        const uploadFields = document.querySelectorAll(
          ".document-upload-field"
        );
        if (uploadFields) {
          uploadFields.forEach((field) => {
            readDocumentURL(field);
          });
        }

        // ...................... Edit Acces to HR....................................

        // if (getEditOnboardingEmployeeAccess == false) {
        document
          .querySelectorAll(
            "#dynamic-form-container-home input, #dynamic-form-container-home select, #dynamic-form-container-home textarea,#dynamic-form-container-home file"
          )
          .forEach((el) => {
            el.disabled = true;
          });

        setShowbtn(false);
        setGetEditOnboardingEmployeeAccess(false);
        $(".Removebtn").addClass("d-none");
        $(".add-more").hide();
        // } else if (getEditOnboardingEmployeeAccess == true) {
        //   alert(getEditOnboardingEmployeeAccess);
        //   document
        //     .querySelectorAll(
        //       "#dynamic-form-container-home input, #dynamic-form-container-home select, #dynamic-form-container-home textarea,#dynamic-form-container-home file"
        //     )
        //     .forEach((el) => {
        //       el.disabled = false;
        //     });

        //   setShowbtn(true);
        // }
        // ...................... End edit acces to HR....................................

        // Select the first two div elements inside .rendered-form and hide them
        $(".rendered-form div").slice(0, 2).hide();

        // Saving employee info to states
        $(document).ready(function () {
          // Check if #fname exists and update the value if present
          if ($("#fname").length > 0) {
            setEmpName($("#fname").val());
          }

          // Check if #cno exists and update the value if present
          if ($("#cno").length > 0) {
            setEmpContact($("#cno").val());
          }

          // Check if #cmail exists and update the value if present
          if ($("#cmail").length > 0) {
            setEmpEmail($("#cmail").val());
          }


          // if(profilePath == ""){
          //   if ($(".profile-upload-field-label").length > 0) {
          //     setProfilePath($(".profile-upload-field").attr("file-path"));
          //   }
          // }

          if (profilePath == "") {
            const filePath = $(".profile-upload-field").attr("file-path");
            if (filePath !== "" && filePath !== null) {
              if ($(".profile-upload-field-label").length > 0) {
                setProfilePath(filePath);
              }
            }
          }
          
         

        });

        $(".rendered-form label").each(function () {
          if ($(this).text().trim() === "") {
            $(this).hide(); // Hide the label if it has no text
          }
        });

        //end

        //.....hide dates
        $(document).ready(function () {
          const today = new Date().toISOString().split("T")[0];

          $("input[type='date']#dob").each(function () {
            $(this).attr("max", today);
          });
          $("input[type='date']").each(function () {
            $(this).attr("max", today);
          });
        });
        // if ($("input[name='adharAttachment']") || $("input[name='pancardAttachment']")){
          
        //   $(".tick")
        //   .parent("div")
        //   .after(
        //     `<div class="verification-btn col-md-2">
        //     <button class="verify-btn" type="button">Verify</button>
        //   </div>`
        //   );
        // }

        if ($("input[name='adharAttachment']").length) {
          $("input[name='adharAttachment']").parent("div")
            .after(
              `<div class="verification-btn col-md-2">
                <button class="verify-btn" type="button">Verify</button>
              </div>`
            );
        }
        
        if ($("input[name='pancardAttachment']").length) {
          $("input[name='pancardAttachment']").parent("div")
            .after(
              `<div class="verification-btn col-md-2">
                <button class="verify-btn" type="button">Verify</button>
              </div>`
            );
        }
        
      }

      if ($("input[name='adharAttachment']")) {
        // alert(adharVarified);
        if (adharVarified) {
          $("input[name='adharAttachment' ]")
            .parent()
            .next()
            .find(".verify-btn")
            .addClass("verified");
          $("input[name= 'adharAttachment']")
            .parent()
            .next()
            .find(".verify-btn")
            .html('<i class="fa fa-check"> </i>')
            .css({
              "background-color": "#28a745",
              color: "#fff",
              "border-radius": "50%",
              width: "30px",
              height: "30px",
              "line-height": "30px",
              "text-align": "center",
              padding: "0",
              "font-size": "12px",
              border: "none",
              "margin-top": "2px",
            });
        }
      }
      if ($("input[name='pancardAttachment']").length) {
        if (panVarified) {
          $("input[name='pancardAttachment' ]")
            .parent()
            .next()
            .find(".verify-btn")
            .addClass("verified");
          $("input[name= 'pancardAttachment']")
            .parent()
            .next()
            .find(".verify-btn")
            .html('<i class="fa fa-check"> </i>')
            .css({
              "background-color": "#28a745",
              color: "#fff",
              "border-radius": "50%",
              width: "30px",
              height: "30px",
              "line-height": "30px",
              "text-align": "center",
              padding: "0",
              "font-size": "12px",
              border: "none",
              "margin-top": "2px",
            });
        }
      }
    }
  };
  function findFilePath(jsonArray) {
    // Iterate through each item in the array
    for (let item of jsonArray) {
      if (item.filePath) {
        return item.filePath; // Return the filePath if found
      }
    }
    return null; // Return null if filePath is not found
  }
  const readDocumentURL = function (Input) {
    if (
      $(Input).attr("file-document-path") &&
      $(Input).attr("file-document-path") != ""
    ) {
      let getAttrId = $(Input).attr("id");

      var label = $(Input).closest("input").prev("label");

      var anchor = $("<a>", {
        text: "Download File",
        href: $(Input).attr("file-document-path"),
        target: "_blank",
      });

      var button = $("<button>", { class: "file-button" }).append(anchor);

      var container = $(".document-upload-field-label");

      if (container.length) {
        $("#" + getAttrId)
          .parent("div")
          .append(button);
      } else {
        console.error(".document-upload-field container not found");
      }
    } else {
      $(label).hide();
      $(Input).hide();
    }
  };
  function findDocumentFilePath(jsonArray) {
    // Iterate through each item in the array
    for (let item of jsonArray) {
      if (item.fileDocumentPath) {
        // console.log("Shridhar------> ", item);
        let $fileInput = $("#" + item.name);
        $fileInput.parent("div").addClass("activeB");
        $fileInput.parent("div").find(".file-select-button").addClass("active");
        // $fileInput.parent('div').append(`<div class="tick"></div>`);
        $fileInput
          .parent("div")
          .append(
            `<div class="tick"><a href="${item.fileDocumentPath}" target="_blank" title="${item.value}"><i class="fa fa-eye" aria-hidden="true"></i></a></div>`
          );
        $fileInput.parent("div").find(".noFile").text(add3Dots(item.value, 55));
        $fileInput.parent("div").find(".cross").css("display", "inline-block");
      }
    }
    return null; // Return null if filePath is not found
  }
  // Save JSON Data
  const validateForm = () => {
    const $ = window.jQuery;
    let isValid = true;

    $(".rendered-form [required]").each(function () {
      const field = $(this);

      let className;
      if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("Aadhar-Number")
      ) {
        className = "Aadhar-Number";
      } else if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("pincode")
      ) {
        className = "pincode";
      } else if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("pan-card")
      ) {
        className = "pan-card";
      }
      const value = field.val();
      const type = field.attr("type");
      const label = field.attr("label");

      const fieldName = field.attr("name");
      // console.log("field--->", field.attr());
      if (!value) {
        isValid = false;
        highlightError(field);
        toast.error(field.attr("placeholder"));
        return isValid;
      } else {
        removeHighlight(field);
      }

      if (type === "email" && value && !validateEmail(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid email address");
        return isValid;
      }

      if (type === "tel" && value && !validateTel(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid contact number");
        return isValid;
      }

      if (type === "number" && value && isNaN(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid number");
        return isValid;
      }
      if (fieldName === "bno" || fieldName === "cbno") {
        const bankAccountNumber = $("input[name='bno']").val();
        const confirmBankAccountNumber = $("input[name='cbno']").val();

        if (
          bankAccountNumber &&
          confirmBankAccountNumber &&
          bankAccountNumber !== confirmBankAccountNumber
        ) {
          isValid = false;
          highlightError($("input[name='cbno']"));
          toast.error("Plase enter a valid bank account number");
          return isValid;
        } else {
          removeHighlight($("input[name='cbno']"));
        }
      }

      if (className === "Aadhar-Number" && value && !validateAadhaar(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid adhar number");
        return isValid;
      }
      // debugger
      if (className === "pincode" && value && !validatePincode(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid pincode");
        return isValid;
      }

      if (className === "pan-card" && value && !validatePancard(value)) {
        // alert("");
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid pancard number");
        return isValid;
      }
    });

    return isValid;
  };
  const validateEmail = (email) => {
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return regex.test(email);
  };
  const validateTel = (tel) => {
    const regex = /^[1-9][0-9]{9}$/;
    return regex.test(tel);
  };
  const validateAadhaar = (aadhaar) => {
    if (aadhaar.length === 12) {
      return true;
    } else {
      return false;
    }
  };
  const validatePincode = (pincode) => {
    const pincodeRegex = /^[0-9]{6}$/; // Regex to match exactly 6 numeric digits
    return pincodeRegex.test(pincode); // Returns true if valid, false otherwise
  };
  const validatePancard = (pancard) => {
    // alert("");
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/i;
    if (pancard.length === 10 && panRegex.test(pancard)) {
      return true;
    } else {
      return false;
    }
  };
  const highlightError = (element) => {
    element.css("border", "2px solid red");
  };
  const removeHighlight = (element) => {
    element.css("border", "");
  };
  const getNewJsonDataWithValues = () => {
    const $ = window.jQuery;
    const formContainer = document.getElementById(
      "dynamic-form-container-home"
    );

    if (!formContainer || !jsonData) {
      // console.error("Form container or jsonData is missing.");
      return null;
    }

    // Parse jsonData if it's a string
    let parsedJsonData = jsonData;
    if (typeof jsonData === "string") {
      try {
        parsedJsonData = JSON.parse(jsonData);
      } catch (error) {
        // console.error("Failed to parse jsonData:", error);
        return null;
      }
    }

    // Ensure it's an array
    const jsonDataArray = Array.isArray(parsedJsonData)
      ? parsedJsonData
      : Object.values(parsedJsonData);

    // Map through the array to attach values
    const newJsonData = jsonDataArray.map((field) => {
      const fieldName = field.name;
      const fieldType = field.type;

      // Find the corresponding input element in the form
      const inputElement = $(formContainer).find(`[name="${fieldName}"]`);
      if (!inputElement.length) return field; // Skip if the field doesn't exist in the form

      let fieldValue;

      // Extract value based on field type
      if (fieldType === "checkbox") {
        fieldValue = inputElement.is(":checked");
      } else if (fieldType === "radio") {
        fieldValue = $(formContainer)
          .find(`input[name="${fieldName}"]:checked`)
          .val();
      } else if (fieldType === "file") {
        const file = inputElement[0]?.files[0];
        fieldValue = file ? file.name : null; // Get the file name or null
      } else {
        fieldValue = inputElement.val(); // Get the input value for text, email, etc.
      }

      // Return updated field object with the new value
      return { ...field, value: fieldValue };
    });
    // console.log("newjsonData-->", newJsonData);

    return newJsonData;
  };
  const handleNext = async (event) => {
    event.preventDefault();
    if (validateForm()) {
      const newJsonData = getNewJsonDataWithValues();

      if (newJsonData) {
        let tempAllDocumentNameArray = [];
        let tempAllSelectedDocumentNameArray = [];
        let tempAllGetSelectedFilesArray = [];

        $("#dynamic-form-container-home")
          .find("input:file")
          .each(function () {
            let getThis = $(this);
            let getDocumentClassName = $(this).attr("name");
            tempAllDocumentNameArray.push(getDocumentClassName);
            if ($("#" + getThis.attr("id"))[0].files.length > 0) {
              tempAllSelectedDocumentNameArray.push(getDocumentClassName);
              const getSelectedFile = $("#" + getThis.attr("id"))[0].files[0];
              tempAllGetSelectedFilesArray.push(getSelectedFile);
            }
          });

        const formData = {
          empId: selectedEmployeeDetails.selectedEmployeeID,
          subModuleId: subModuleID,
          jsonData: JSON.stringify(newJsonData),
          formStatusFromUI: "direct",
          profileImage: profileImage,
          attachments: tempAllGetSelectedFilesArray,
          attachmentsNames: tempAllDocumentNameArray,
          selectedAttachmentsNames: tempAllSelectedDocumentNameArray,
          createdBy: personalInfo.userID,
        };
        setIsLoaderActive(true);
        try {
          const check = await postFormData(formData);
          if (check === true) {
            handleSuccesToastWithMessage("Saved successfully!");
            setIsLoaderActive(false);

          } else {
            handleErrorToastUsingMessage("Error while storing data!");
            setIsLoaderActive(false);

          }
        } catch (error) {
          handleErrorToastUsingMessage("Unexpected error while storing data!");
        } finally {
          setIsLoaderActive(false);
        }
      }
    }
  };
  const postFormData = async (formData) => {
    setIsLoaderActive(true);
    try {
      const documentObject = window.getDocumentObject();
      const documentName = window.getDocumentName();
      setDocumentsObject(formData.attachments);
      setDocumentsName(documentName);
      const formDataToSend = new FormData();
      formDataToSend.append("empId", formData.empId);
      formDataToSend.append("subModuleId", formData.subModuleId);
      formDataToSend.append("jsonData", formData.jsonData);
      formDataToSend.append("formStatusFromUI", formData.formStatusFromUI);
      formDataToSend.append("profileImage", formData.profileImage);

      formData.attachments.forEach((attach, index) => {
        formDataToSend.append(`docAttachments`, attach);
      });
      //formDataToSend.append(`attachments`, formData.attachments);
      formData.attachmentsNames.forEach((attachmentName, index) => {
        formDataToSend.append(`attachmentsNames[${index}]`, attachmentName);
      });

      formData.selectedAttachmentsNames.forEach(
        (attachmentSelectedName, index) => {
          formDataToSend.append(
            `selectedAttachmentsNames[${index}]`,
            attachmentSelectedName
          );
        }
      );

      formDataToSend.append("createdBy", formData.createdBy);
      const response = await axios.post(
        `${config.apiEndPoint}/AdminFormFormat/PostUserJsonFormData`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            ...config.header3,
          },
        }
      );
      setIsLoaderActive(false);

      return true;
      
    } catch (error) {
      // console.error("Error saving data:", error);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  // Document from JSON
  function fileUploadDiv() {
    $("#dynamic-form-container-home")
      .find("input[type='file']")
      .each(function () {
        const $fileInput = $(this);
        if ($fileInput.attr("class") == "document-upload-field") {
          $fileInput.parent("div").parent("div").addClass("file-upload");
          $fileInput.parent("div").addClass("file-select");
          $fileInput.parent("div").find("label").addClass("file-select-button");
          $fileInput.parent("div").find("label").html("Choose File");
          $fileInput
            .parent("div")
            .append(
              `<div class="file-select-name noFile">No file chosen...</div>`
            );

          let $removeButtond = $fileInput.siblings("label").find(".Removebtn");

          if (!$removeButtond.length) {
            // const newDiv = $("<div>").addClass("tickbox col-lg-2").css({
            //   display: "inline-block",
            //   marginLeft: "10px",
            // });

            $removeButtond = $("<div>")
              .addClass("cross Removebtn")
              .css("display", "none")
              .on("click", function (event) {
                // alert("");
                event.preventDefault();
                $fileInput.val("");
                // Set the file-document-path attribute to an empty string
                $fileInput.removeAttr("file-document-path");

                $fileInput.removeAttr("value");

                $fileInput
                  .parent("div")
                  .find(".noFile")
                  .text("No file chosen...");
                $fileInput.parent("div").removeClass("activeB");
                $fileInput
                  .parent("div")
                  .find(".file-select-button")
                  .removeClass("active");
                $fileInput.parent("div").find(".tick").remove();
                $(this).css("display", "none");
              });

            // newDiv.append($removeButtond);
            $fileInput.parent().append($removeButtond);
          }

          $fileInput.on("input change", function () {
            $fileInput.parent("div").find(".tick").remove();
            if ($fileInput.val()) {
              $removeButtond.css("display", "inline-block");
              $fileInput.parent("div").addClass("activeB");
              $fileInput
                .parent("div")
                .find(".file-select-button")
                .addClass("active");
              // if ($fileInput.parent('div').hasClass('tick')) {

              // } else {
              var file = $fileInput[0].files[0];
              var fileUrl = URL.createObjectURL(file);
              $fileInput
                .parent("div")
                .append(
                  `<div class="tick"><a href="${fileUrl}" target="_blank" title="${file.name}"><i class="fa fa-eye" aria-hidden="true"></i></a></div>`
                );

              // }

              $fileInput
                .parent("div")
                .find(".noFile")
                .text(
                  add3Dots($fileInput.val().replace("C:\\fakepath\\", ""), 55)
                );
            } else {
              $removeButtond.css("display", "none");
              $fileInput
                .parent("div")
                .find(".noFile")
                .text("No file chosen...");
              $fileInput.parent("div").removeClass("activeB");
              $fileInput
                .parent("div")
                .find(".file-select-button")
                .removeClass("active");
            }
          });
        }
      });
  }
  function add3Dots(string, limit) {
    var dots = "...";
    if (string) {
      if (string.length > limit) {
        // you can also use substr instead of substring
        string = string.substring(0, limit) + dots;
      }
    }

    return string;
  }
  const EditAccessHandler = () => {
    if (getEditOnboardingEmployeeAccess == false) {
      document
        .querySelectorAll(
          "#dynamic-form-container-home input, #dynamic-form-container-home select, #dynamic-form-container-home textarea,#dynamic-form-container-home file"
        )
        .forEach((el) => {
          el.disabled = false;
        });
      setShowbtn(true);
      $(".add-more").show();
      $(".remove-more").show();
      $(".activeB").find(".Removebtn").removeClass("d-none");
      setGetEditOnboardingEmployeeAccess(!getEditOnboardingEmployeeAccess);
    } else {
      loadData(subModuleID);
      document
        .querySelectorAll(
          "#dynamic-form-container-home input, #dynamic-form-container-home select, #dynamic-form-container-home textarea, #dynamic-form-container-home file"
        )
        .forEach((el) => {
          el.disabled = true;
        });
      $(".add-more").hide();
      $(".remove-more").hide();
      $(".Removebtn").addClass("d-none");
      // setGetEditOnboardingEmployeeAccess(false);
      setGetEditOnboardingEmployeeAccess(!getEditOnboardingEmployeeAccess);

      setShowbtn(false);
    }
  };
  useEffect(() => {
    // alert("");
    // GetAllTaxSlab();
    GetAllDepartments();
    GetAllManager();
    GetAllTempalates();
    GetBankDetails();
    GetAllItDeclarations();
    GetSelectedEmpInfo();
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    GetEmpTaxComponents(defaultYear);
    loadData(1); // Calls loadData when the component mounts
    window.initDatePickerFuncation();
  }, []);
  // below useEffect is for Add-more btn
  useEffect(() => {
    if (jsonData) {
      $(document).on("click", ".add-more", function () {
        let currentJsonData = getNewJsonDataWithValues();
        const getHowManyObjectsWeNeedToCopy = $(this)
          .attr("class")
          .split(" ")
          .pop();
        const getCurrentObjectId = $(this).attr("id");
        let getUpdatedJsonArray = copyAndPastePreviousObjects(
          currentJsonData,
          getCurrentObjectId,
          getHowManyObjectsWeNeedToCopy,
          appendIndexId
        );
        setJsonData(JSON.stringify(getUpdatedJsonArray));
        setAppendIndexId(appendIndexId + 1);
      });
      $(document).on("click", ".remove-more", function () {
        let getHowManyObjectNeedToRemove = $(".add-more")
          .attr("class")
          .split(" ")
          .pop();
        let currentJsonData = JSON.parse(jsonData);
        const searchName = $(this).attr("id");
        let getUpdatedJsonArray = removePreviousObjects(
          currentJsonData,
          searchName,
          getHowManyObjectNeedToRemove - 1
        );
        // // console.log("Akshay --",currentJsonData);
        setJsonData(JSON.stringify(getUpdatedJsonArray));
        addDetails(
          "dynamic-form-container-home",
          JSON.stringify(getUpdatedJsonArray)
        );

        setAppendIndexId(appendIndexId - 1);
      });
      return () => {
        $(document).off("click", ".add-more");
        $(document).off("click", ".remove-more");
      };
    }
  }, [jsonData]);
  const removePreviousObjects = (
    getJsonArray,
    searchName,
    howManyObjectWeNeedToCopy
  ) => {
    // Find the index of the element with the specific name
    let index = getJsonArray.findIndex((item) => item.name === searchName);
    const heading = getJsonArray[index - howManyObjectWeNeedToCopy - 1];

    if (index !== -1) {
      // Remove the previous 6 objects (if they exist)
      let removeCount = Math.min(
        parseInt(howManyObjectWeNeedToCopy) + 1,
        index
      ); // Ensure we don't remove negative indices
      // console.log("removeCount---->",removeCount);
      // console.log("index---->",index);

      getJsonArray.splice(index - removeCount, removeCount + 1); // Remove the previous 6 items and the found item
    }
    // console.log("getJsonArray after op---->",getJsonArray);

    setTimeout(() => {
      $(".myCustomClass").each(function (i, obj) {
        $(this).html(i + 1 + " " + heading["label"]);
      });
    }, 500);
    return getJsonArray;
  };
  const GetEmpTaxComponents = async (year) => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ITDeclarationMaster/GetAllEmplyeeSubmittedITDeclarationByEmpIdAndYear?FinancialYear=${year}&EmpID=${selectedEmployeeDetails.selectedEmployeeID}`
      );
      const componentsArray = response.data.data;

      // console.log("empsubmitted ===> ", componentsArray);
      if (componentsArray) {
        setSalaryComponentsArray(componentsArray || []);
      } else {
        setSalaryComponentsArray([]);
      }
    } catch (error) {
      console.error("Error fetching employee tax details:", error);
      toast.error("Error fetching employee tax details");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const copyAndPastePreviousObjects = (
    getJsonArray,
    searchName,
    howManyObjectWeNeedToCopy,
    appendIndexId
  ) => {
    // Find the index of the object with the specific "name" field
    const index = getJsonArray.findIndex((item) => item.name === searchName);

    // If the name is found and index is valid
    if (index !== -1) {
      var removeBtnLength = $(".remove-more").length;

      let howmanyObjectNeedToCopy =
        removeBtnLength == 0
          ? howManyObjectWeNeedToCopy
          : parseInt(howManyObjectWeNeedToCopy) + 1;

      // Get the previous 6 objects from the found index (considering boundary cases)
      const startIndex = Math.max(0, index - howmanyObjectNeedToCopy); // Ensure we don't go out of bounds
      const previousObjects = getJsonArray.slice(startIndex, index); // Extract the previous objects

      const modifiedObjects = previousObjects.slice(1).map((item) => {
        return { ...item, name: item.name + "-" + appendIndexId, value: "" }; // Append '+1' to the "name"
      });

      let tempObject = {
        type: "header",
        subtype: "h6",
        label: previousObjects[0]["label"],
        className: "myCustomClass w-100 col-md-12 " + appendIndexId,
        access: false,
      };
      modifiedObjects.unshift(tempObject);
      if (removeBtnLength == 0) {
        let removeTempObject = {
          type: "button",
          label: "- Remove",
          subtype: "button",
          className: "btn-danger btn remove-more col-md-2",
          name: "button-1733230103748-0" + "-" + appendIndexId,
          access: false,
          style: "danger",
        };
        modifiedObjects.push(removeTempObject);
      }
      getJsonArray.splice(index, 0, ...modifiedObjects); // Insert at the found index

      setTimeout(() => {
        $(".myCustomClass").each(function (i, obj) {
          $(this).html(i + 1 + " " + previousObjects[0]["label"]);
        });
      }, 10);
      addDetails("dynamic-form-container-home", JSON.stringify(getJsonArray));

      return getJsonArray;
    } else {
      return null; // Return null if the name was not found
    }
  };
  var loadFile = function (event) {
    var image = document.getElementById("output");
    image.src = URL.createObjectURL(event.target.files[0]);
    setProfileImage(event.target.files[0]);
    let getTempJsonDataArray = JSON.parse(jsonData);
    const index = getTempJsonDataArray.findIndex(
      (item) =>
        item.type === "file" && item.className === "profile-upload-field"
    );
    // getTempJsonDataArray[index]["filePath"] = "";
    setJsonData(JSON.stringify(getTempJsonDataArray));
  };
  //Approve/Reject Employee
  const GetAllDepartments = async () => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Department/GetAllDepartments`
      );
      if (response.data.success == "True") {
        setAllDepartment(response.data.data); // Store data in state
      } else {
        console.error("Error fetching departments:");
      }
    } catch (error) {
      console.error("Error fetching departments:");
    }
  };
  const GetAllManagerByDept = async (department) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllManagersByDept`,
        {
          params: { deptName: department },
        }
      );

      if (response.data.success == "success") {
        // console.log("all manager---->", response.data.data);

        setAllManager(response.data.data); // Store data in state
      } else {
        console.error("Error fetching Manager:");
      }
    } catch (error) {
      console.error("Error fetching Manager:");
    }
  };
  const GetAllManager = async (department) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllManagers`
      );
      if (response.data.success == "success") {
        setAllDeptManager(response.data.data);
        // console.log("getallmanagers---->", response.data);
      } else {
        console.error("Error fetching Manager:");
      }
    } catch (error) {
      console.error("Error fetching Manager:");
    }
  };
  const handleSend = () => {
    if (remark.trim() === "") {
      handleErrorToast("Please enter a remark before sending.");
      setIsLoaderActive(false);

      return;
    }
    postRemark(remark); // Pass the remark to the parent or process it
    setRemark("");
    setShowModal(false);
  };
  const handleVerify = () => {
    // console.log(
    //   "checkThisForAttachmentClick------->",
    //   checkThisForAttachmentClick
    // );

    if (verificationInput.trim() === "") {
      handleErrorToast("Please enter a document number before sending.");
      setIsLoaderActive(false);

      return;
    }
    // postRemark(remark);
    verifyDocument();
    setVerificationInput("");
    $(".modal-verify-document-class").addClass("d-none");
  };
  const verifyDocument = async () => {
    let api = "";
    if (checkThisForAttachmentClick == "adharAttachment") {
      api = `${config.apiEndPoint}/AdminFormFormat/verifyAadharNumber?EmpId=${selectedEmployeeDetails.selectedEmployeeID}&aadharNumber=${verificationInput}`;
    } else {
      api = `${config.apiEndPoint}/AdminFormFormat/verifyPanNumber?EmpId=${selectedEmployeeDetails.selectedEmployeeID}&panNumber=${verificationInput}`;
    }

    try {
      const response = await axios.post(api);

      if (response.data.success == "True") {
        toast.success(response.data.message);

        $("input[name='" + checkThisForAttachmentClick + "' ]")
          .parent()
          .next()
          .find(".verify-btn")
          .addClass("verified");
        $("input[name= '" + checkThisForAttachmentClick + "']")
          .parent()
          .next()
          .find(".verify-btn")
          .html('<i class="fa fa-check"> </i>')
          .css({
            "background-color": "#28a745",
            color: "#fff",
            "border-radius": "50%",
            width: "30px",
            height: "30px",
            "line-height": "30px",
            "text-align": "center",
            padding: "0",
            "font-size": "12px",
            border: "none",
            "margin-top": "2px",
          });
          
          if(checkThisForAttachmentClick == "adharAttachment")
          {
            setAdharVarified(true);
          }else{
            setPanVarified(true);
          }

      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      toast.error("Failed to verify data.");
      return false;
    }
  };
  const handleAssign = () => {
    
    if (!email.trim()) {
      emailref.current.focus();
      emailref.current.classList.add("is-invalid");
      handleErrorToast("Official Email is required.");
      return;
    }

    // Regular expression to validate the email format
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email.trim())) {
      emailref.current.focus();
      emailref.current.classList.add("is-invalid");
      handleErrorToast("Please enter a valid email address.");
      return;
    }

    // Once the email is valid, move focus to the next field (e.g., department)

    departmentref.current.focus();

    if (!selectedDepartment) {
      departmentref.current.classList.add("is-invalid");
      handleErrorToast("Department is required.");
      return;
    }

    // managerref.current.focus();

    // if (!selectedManager) {
    //   managerref.current.focus();
    //   managerref.current.classList.add("is-invalid");
    //   handleErrorToast("Manager is required.");
    //   return;
    // }

    deisgnationref.current.focus();

    if (!designation) {
      deisgnationref.current.focus();
      deisgnationref.current.classList.add("is-invalid");
      handleErrorToast("Deignation is required.");
      return;
    }

    // joiningdateref.current.focus();

    if (!joiningDate) {
      joiningdateref.current.focus();
      joiningdateref.current.classList.add("is-invalid");
      handleErrorToast("Joining Date is required.");
      return;
    }

    ctcref.current.focus();

    if (!ctcvalue) {
      ctcref.current.focus();
      ctcref.current.classList.add("is-invalid");
      handleErrorToast("CTC is required.");
      return;
    }
    templateref.current.focus();

    if (!selectedtemplate) {
      templateref.current.focus();
      templateref.current.classList.add("is-invalid");
      handleErrorToast("Payroll Template is required.");
      return;
    }

    if(adharVarified == false){
      toast.error("Please verify Aadhar Number");
      return;
    }

    if(panVarified == false){
      toast.error("Please verify Pan Number");
      return;
    }

   
    // Proceed with the assignment if everything is valid
    AssignEmployeeToOnboarding(email);
    setShowModal_second(false);
  };
  const AssignEmployeeToOnboarding = async (email) => {
    setIsLoaderActive(true);
    try {
      const url = `${config.apiEndPoint}/EmployeeData/approvalMailByHr`;
      const params = new URLSearchParams({
        empID: selectedEmployeeDetails.selectedEmployeeID, // Assuming `employeeID` is already a string or number
        officialEmail: email,
        departmentName: selectedDepartment,
        AssignedManager: selectedManager || "NA",
        Designation: designation,
        isProbation: isProbation,
        joiningDate: joiningDate,
        profilePath: profilePath ? profilePath : null,
        ctc: ctcvalue,
        templateId: selectedtemplate,
        ProbationPeriod:probationPeriod,
      });
      // console.log("Probation",probationPeriod);
      const response = await axios.post(`${url}?${params.toString()}`);
      // const response = "";
      if (response.data.success === "True") {
        toast.success("Employement Succesful");
        setTimeout(() => {
          navigate("/manage-employee");
        }, 1000);

        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch (error) {
      toast.error("Failed to add employee!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const GetAllTempalates = async () => {
    try {
      const response = await axios.get(
        config.apiEndPoint + "/Payroll/GetTempalates"
      );
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);
      setAllTempalatesArray(tempalatesArray);
    } catch (error) {
      console.error("Error fetching tempalates:", error);
      toast.error("Error fetching tempalates");
    }
  };
  const postRemark = async (remark) => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeData/rejectionMailByHr?empID=
          ${selectedEmployeeDetails.selectedEmployeeID}
        &msg=${encodeURIComponent(remark)}`
      );
      if (response.data.success === "True") {
        toast.success("Remark Send! ");
        setTimeout(() => {
          navigate("/manage-employee");
        }, 1000);
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch (error) {
      toast.error("Failed to send remark!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const handleIfscCodeBlur = () => {
    if (ifscCode.length === 11) {
      const ifscCodePattern = /^[a-zA-Z]{4}0[a-zA-Z0-9]{6}$/;

      if (ifscCodePattern.test(ifscCode)) {
        setHasError(false);
        GetIfscCode(ifscCode);
      } else {
        setHasError(true);
        toast.error("Invalid IFSC Code format.");
      }
    }
  };
  const GetIfscCode = async (ifscCode) => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `https://bank-apis.justinclicks.com/API/V1/IFSC/${ifscCode}/`
      );

      if (response.status === 200) {
        // console.log(response, 'RES');
        setBankData(response.data);
        if (response.data) {
          setBankName(response.data.BANK);
          setBranchName(response.data.BRANCH);
          // setBranchAddress(response.data.ADDRESS);
        }
      } else {
        console.error("No details found for the provided IFSC Code.");
      }
    } catch (error) {
      console.error("Error fetching IFSC Code details:", error);
      // toast.error("Failed to fetch IFSC details. Please try again.");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const handleBankDetailsSubmit = async () => {
    if (!accountNumber) {
      inputAccNoReference.current.focus();
      inputAccNoReference.current.classList.add("is-invalid");
      toast.error("Please enter bank account number");
      return;
    }
    if (!confirmAccountNumber) {
      inputConfirmAccNoReference.current.focus();
      inputConfirmAccNoReference.current.classList.add("is-invalid");
      toast.error("Please confirm your bank account number");
      return;
    }
    if (accountNumber != confirmAccountNumber) {
      inputConfirmAccNoReference.current.focus();
      inputConfirmAccNoReference.current.classList.add("is-invalid");
      toast.error("Account number and confirm account number do not match");
      return;
    }
    if (!ifscCode) {
      inputIfscCodeReference.current.focus();
      inputIfscCodeReference.current.classList.add("is-invalid");
      toast.error("Please enter ifsc code of your bank");
      return;
    }
    // if (!accHolderName) {
    //   inputAccHolderNameReference.current.focus();
    //   inputAccHolderNameReference.current.classList.add("is-invalid");
    //   toast.error("Please enter account holder name");
    //   return;
    // }
    if (!bankName) {
      inputBankNameReference.current.focus();
      inputBankNameReference.current.classList.add("is-invalid");
      toast.error("Please enter bank name");
      return;
    }
    if (!branchName) {
      inputBranchNameReference.current.focus();
      inputBranchNameReference.current.classList.add("is-invalid");
      toast.error("Please enter your bank branch name");
      return;
    }
    // if (!branchAddress) {
    //   inputBranchAddressReference.current.focus();
    //   inputBranchAddressReference.current.classList.add("is-invalid");
    //   toast.error("Please enter your bank branch Address");
    //   return;
    // }

    setIsLoaderActive(true);

    try {
      const bankData = {
        empId: selectedEmployeeDetails.selectedEmployeeID,
        bankName: bankName,
        accountNumber: confirmAccountNumber,
        ifscCode: ifscCode,
        branchName: branchName,
        createdBy: personalInfo.userID,
      };

      const response = await axios.post(
        `${config.API_URL}BankDetails/AddBankDetails`,
        bankData
      );

      if (response.data.success) {
        toast.success("Bank Details Updated Successfully.");
        setAccHolderName("");
        setAccountNumber("");
        setBankName("");
        // setBranchAddress("");
        setBranchName("");
        setIfscCode("");
        setConfirmAccountNumber("");
        GetBankDetails();
      } else {
        toast.error(response.data.message || "Error processing request");
      }
    } catch (error) {
      toast.error(error.response?.data || "An error occurred");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const GetBankDetails = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/BankDetails/GetBankDetailsId?empId=${selectedEmployeeDetails.selectedEmployeeID}`
      );
      if (response.data.success == "True") {
        setBank(response.data.data);
        if (response.data.data) {
          setAccHolderName(response.data.data.accountHolderName);
          setAccountNumber(response.data.data.accountNumber);
          setConfirmAccountNumber(response.data.data.accountNumber);
          setBankName(response.data.data.bankName);
          setIfscCode(response.data.data.ifscCode);
          setBranchName(response.data.data.branchName);
        }
        GetIfscCode(response.data.data.ifscCode);
      } else {
        console.error("Error fetching bank details:");
        setBank("");
      }
    } catch (error) {
      console.error("Error fetching bank details:");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const handleEditClick = () => {
    setIsEditable(true);
  };
  const handleSaveClick = (e) => {
    handleBankDetailsSubmit(e); // Call your existing submit function
    setIsEditable(false);
  };
  const handleCancelClick = () => {
    setIsEditable(false);
  };
  // const GetAllTaxSlab = async () => {
  //   try {
  //     const response = await axios.get(
  //       `${config.apiEndPoint}/TaxSlabMaster/GetAllItDeclaration`
  //     );

  //     if (response.data && response.data.data) {
  //       // Filter only "New Regime" data and extract needed fields
  //       const formattedData = response.data.data
  //         .filter((item) => item.regime === "new")
  //         .map((item) => ({
  //           componentName: item.taxSlabDes, // Assign taxSlabDes to componentName
  //           percentage: item.taxRate, // Assign taxRate to percentage
  //         }));

  //       setSalaryComponentsArray(formattedData);
  //     }
  //   } catch (error) {
  //     toast.error("Slab not acquired");
  //   }
  // };
  const handleAcceptSend = async () => {
    setIsLoaderActive(true);
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/ITDeclarationMaster/ApproveITDeclarationByHR`,
        {
          employeeIdTobeApproved: selectedEmployeeDetails.selectedEmployeeID,
          hrRemarks: acceptRemark,
          financialYear: defaultYear,
          modifiedBy: personalInfo.userID,
        }
      );
      if (response.data.success === "True") {
        toast.success(response.data.message);
        setAcceptRemark("");
        setShowButton(false);
        setShowModalAccept(false);
        setTimeout(() => {
          navigate("/manage-employee");
        }, 1000);
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch (error) {
      toast.error("Failed to send remark!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const handleRejectSend = async () => {
    setIsLoaderActive(true);
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    if(!rejectRemark){
      toast.error("Plese enter remark!");
    setIsLoaderActive(false);

      return;
    }
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/ITDeclarationMaster/RejectITDeclarationByHR`,
        {
          employeeIdTobeApproved: selectedEmployeeDetails.selectedEmployeeID,
          hrRemarks: rejectRemark,
          financialYear: defaultYear,
          modifiedBy: personalInfo.userID,
        }
      );
      if (response.data.success === "True") {
        toast.success(response.data.message);
        setRejectRemark("");
        setShowModalReject(false);
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch (error) {
      toast.error("Failed to send remark!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllItDeclarations = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ITDeclarationMaster/GetAllItDeclaration`
      );
      if (response.data.success === "True") {
        setDeclarations(response.data.data);
        // console.log("data", response.data.data);
      } else {
        setDeclarations([]);
      }
    } catch (error) {
      console.error("Error fetching declarations:", error);
      toast.error("Error fetching declarations");
    } finally {
      setIsLoaderActive(false);
    }
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">Employee Details </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Employee Page</Link>
                </li>
                <li className="breadcrumb-item active">Employee Details </li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-3">
              <div class="card card-primary card-outline">
                <div class="card-body box-profile mb-0 position-relative">
                  {isLoaderActive && (
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgb(233 236 239 / 81%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 10,
                      }}
                    >
                      <i
                        className="fas fa-sync-alt fa-spin"
                        style={{ fontSize: "2rem", color: "#333" }}
                      ></i>
                    </div>
                  )}
                  <div class="text-center">
                    {/* <img class="profile-user-img img-fluid img-circle" src={profilepic} alt="User profile picture" /> */}
                  </div>
                  {showbtn == false ? (
                    <div className="imgBeforeEdit d-flex align-items-center justify-content-center">
                      <img
                        src={
                          profilePath
                            ? profilePath
                            : selectedEmployeeDetails.gender?.toLowerCase() === 'male'
                              ? require('../../assets/images/default_img.png')
                              : require('../../assets/images/download.jpeg')
                        }
                        id="output"
                        width="100"
                        style={{ width: "160px", height: "160px" }}
                      />
                    </div>
                  ) : (
                    <div class="profile-pic d-flex align-items-center justify-content-center">
                      <label
                        class="-label mb-0"
                        for="file"
                        style={{ width: "160px", height: "160px" }}
                      >
                        <span class="glyphicon glyphicon-camera"></span>
                        <span>Change Image</span>
                      </label>
                      <input
                        id="file"
                        type="file"
                        onChange={(event) => loadFile(event)}
                      />
                      <img
                         src={
                          profilePath
                            ? profilePath
                            : selectedEmployeeDetails.gender?.toLowerCase() === 'male'
                              ? require('../../assets/images/default_img.png')
                              : require('../../assets/images/download.jpeg')
                        }
                        id="output"
                        width="100"
                        style={{ width: "160px", height: "160px" }}
                      />
                    </div>
                  )}

                  <h3 class="profile-username text-center">{empName}</h3>

                  {/* <p class="text-muted text-center">Software Engineer {selectedEmployeeDetails.Designation}</p> */}

                  <ul class="list-group list-group-unbordered mb-3">
                    <li class="list-group-item employeeDetailsList">
                      <b className="listHead">Name</b>{" "}
                      <a class="float-right text-clr">{empName || (selectedEmployeeDetails.firstName +" "+((selectedEmployeeDetails.lastName && selectedEmployeeDetails.lastName != null)?selectedEmployeeDetails.lastName: " ") || "NA")}</a>
                    </li>
                    <li class="list-group-item employeeDetailsList">
                      <b className="listHead">Contact</b>{" "}
                      <a class="float-right text-clr">{empContact ||selectedEmployeeDetails.mobile || "NA"}</a>
                    </li>
                    <li class="list-group-item employeeDetailsList">
                      <b className="listHead">Email</b>{" "}
                      <a
                        class="float-right text-clr ellipsis"
                        title="abcxyz@iteos.in"
                      >
                        {selectedEmployeeDetails.email || empEmail || "NA"}
                      </a>
                    </li>
                    {showAcceptRejectButton != "t" ? (
                      <li class="list-group-item employeeDetailsList">
                        <b className="listHead">Assigned Manager</b>{" "}
                        <a class="float-right text-clr ellipsis">
                          {selectedEmployeeDetails.assignedManager &&
                          allDeptManager != null
                            ? (() => {
                                const manager = allDeptManager.find(
                                  (manager) =>
                                    manager.userID ===
                                    selectedEmployeeDetails.assignedManager.toLowerCase()
                                );
                                return manager
                                  ? `${manager.firstName || "NA"} ${
                                      manager.lastName || ""
                                    }`
                                  : "NA";
                              })()
                            : "NA"}
                        </a>
                      </li>
                    ) : null}
                  </ul>
                </div>
                <div>
                  {showRejectAcceptBtn && (
                    <div className="action-buttons row p-3">
                      {!isLoaderActive ? (
                        <button
                          type="button"
                          className="btn btn-danger saveBtn col-md-5 btn-sm mr-4 ml-2"
                          onClick={() => setShowModal(true)}
                        >
                          Reject
                        </button>
                      ) : null}
                      {isLoaderActive ? (
                        <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn ml-5" />
                      ) : (
                        <button
                          type="button"
                          className="btn btn-primary saveBtn col-md-5 btn-sm"
                          onClick={() => setShowModal_second(true)}
                        >
                          Accept
                        </button>
                      )}
                    </div>
                  )}
                </div>
                <div className="row p-3">
                  {showbtn && (
                    <>
                      {isLoaderActive ? (
                        <PleaseWaitButton className="btn-sm font-weight-medium auth-form-btn mr-2" />
                      ) : (
                        <button
                          type="button"
                          className="btn btn-primary saveBtn col-md-5 btn-sm mr-2 ml-3"
                          onClick={handleNext}
                        >
                          Save
                        </button>
                      )}
                    </>
                  )}
                  {isEmployeeActive == "true" && showRejectAcceptBtn == false && isDeleted == "false" ? (
                    <button
                      type="button"
                      className={
                        getEditOnboardingEmployeeAccess
                          ? "btn btn-secondary saveBtn col-md-5 btn-sm"
                          : "btn btn-warning col-md-12 btn-sm"
                      }
                      onClick={() => EditAccessHandler()}
                    >
                      {getEditOnboardingEmployeeAccess ? "Cancel" : "Edit"}
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
            <div class="col-md-9">
              <div class="card">
                <div class="card-header p-2">
                  <ul class="nav nav-pills">
                    <li class="nav-item">
                      <a
                        class="nav-link active"
                        href="#json-information"
                        data-toggle="tab"
                        onClick={() => loadData(1)}
                      >
                        Personal Information
                      </a>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#json-information"
                        data-toggle="tab"
                        onClick={() => loadData(2)}
                      >
                        Previous Employement
                      </a>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link "
                        href="#json-information"
                        data-toggle="tab"
                        onClick={() => loadData(3)}
                      >
                        Education Details
                      </a>
                    </li>
                    <li class="nav-item">
                      <a
                        class="nav-link"
                        href="#json-information"
                        data-toggle="tab"
                        onClick={() => loadData(4)}
                      >
                        Attach Documents
                      </a>
                    </li>
                    {showAcceptRejectButton != 't'?(<>
                    <li class="nav-item">
                    <a
                      class="nav-link"
                      href="#bankDetails"
                      data-toggle="tab"
                      onClick={() => setIsModal(false)}
                    >
                      Bank Details
                    </a>
                  </li>
                  <li class="nav-item">
                    <a
                      class="nav-link"
                      href="#taxDetails"
                      data-toggle="tab"
                      onClick={() => setIsModal(false)}
                    >
                      Tax Details
                    </a>
                  </li></>):null
                  }
                    
                  </ul>
                </div>
                <div class="card-body position-relative">
                  {isLoaderActive && (
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgb(233 236 239 / 81%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 10,
                      }}
                    >
                      <i
                        className="fas fa-sync-alt fa-spin"
                        style={{ fontSize: "2rem", color: "#333" }}
                      ></i>
                    </div>
                  )}
                  <div class="tab-content">
                    <div class="tab-pane active" id="json-information">
                      <div id="dynamic-form-container-home"></div>
                      <div className="button-group float-right">
                        {showModal ? (
                          <>
                            <div
                              class="modal fade show"
                              id="modal-default"
                              style={{
                                display: "block",
                                paddingRight: "17px",
                                boxShadow: "#5d5858b 8",
                                backgroundColor: "#5d5858b8",
                              }}
                              aria-modal="true"
                              role="dialog"
                            >
                              <div class="modal-dialog">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h4 class="modal-title">
                                      Remark{" "}
                                      <span
                                        hover-tooltip="Here you can verify the aadhar number and pan number of employee. If you not verify this then the employment process will not complete."
                                        tooltip-position="bottom"
                                      >
                                        <i
                                          className="fas fa-info-circle my-1 ml-2"
                                          style={{ color: "rgb(0 0 0 / 51%)" }}
                                        ></i>
                                      </span>
                                    </h4>
                                    <button
                                      type="button"
                                      class="close btn-secondary"
                                      data-dismiss="modal"
                                      aria-label="Close"
                                      onClick={() => {
                                        setShowModal(false);
                                      }}
                                    >
                                      <span aria-hidden="true">×</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <textarea
                                      class=" w-100 form-control"
                                      placeholder="Describe your remark"
                                      value={remark} // Controlled input
                                      onChange={(e) =>
                                        setRemark(e.target.value)
                                      } // Update state on change
                                    />
                                  </div>
                                  <div class="modal-footer justify-content-between">
                                    <button
                                      type="button"
                                      class="btn btn-secondary closebtn"
                                      data-dismiss="modal"
                                      onClick={() => {
                                        handleClose();
                                      }}
                                    >
                                      Close
                                    </button>
                                    <button
                                      type="button"
                                      className="btn btn-primary savebtn"
                                      onClick={handleSend} // Call handleSend on click
                                    >
                                      Send
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        ) : null}

                        {showModal_second ? (
                          <>
                            <div
                              className="modal fade show"
                              id="modal-default"
                              style={{
                                display: "block",
                                paddingRight: "17px",
                                boxShadow: "#5d5858b 8",
                                backgroundColor: "#5d5858b8",
                              }}
                              aria-modal="true"
                              role="dialog"
                            >
                              <div className="modal-dialog">
                                <div className="modal-content">
                                  {/* Modal Header */}
                                  <div className="modal-header">
                                    <h4 className="modal-title">
                                      Remark{" "}
                                      <span
                                        hover-tooltip="Fill in the employee's official email, department, manager, designation, joining date, CTC, and payroll template. Check the probation box if applicable. These details will be used for role assignment and payroll processing."
                                        tooltip-position="bottom"
                                      >
                                        <i
                                          className="fas fa-info-circle my-1 ml-2"
                                          style={{ color: "rgb(0 0 0 / 51%)" }}
                                        ></i>
                                      </span>
                                    </h4>
                                    <button
                                      type="button"
                                      className="close btn-secondary"
                                      data-dismiss="modal"
                                      aria-label="Close"
                                      onClick={() => {
                                        setShowModal_second(false);
                                      }}
                                    >
                                      <span aria-hidden="true">×</span>
                                    </button>
                                  </div>

                                  {/* Modal Body */}
                                  <div className="modal-body">
                                    <div className="row">
                                      <div className="col-md-6">
                                        {/* Assign Email Field */}
                                        <div className="form-group">
                                          <label htmlFor="assignEmail">
                                            Assign Official Email
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>
                                          <input
                                            type="email"
                                            id="assignEmail"
                                            ref={emailref}
                                            className="form-control form-control-sm"
                                            placeholder="Enter email"
                                            value={email} // Controlled input
                                            onChange={(e) => {
                                              setEmail(e.target.value);
                                              emailref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                          />
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        {/* Select Department Field */}
                                        <div className="form-group">
                                          <label htmlFor="selectDepartment">
                                            Select Department
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>
                                          <select
                                            id="selectDepartment"
                                            ref={departmentref}
                                            className="form-control form-control-sm"
                                            value={selectedDepartment}
                                            onChange={setDepartment}
                                          >
                                            <option value="">
                                              Select a department
                                            </option>
                                            {allDepartment.length > 0 ? (
                                              allDepartment.map(
                                                (department) => (
                                                  <option
                                                    key={
                                                      department.departmentID
                                                    }
                                                    value={
                                                      department.departmentID
                                                    }
                                                  >
                                                    {department.departmentName}
                                                  </option>
                                                )
                                              )
                                            ) : (
                                              <option disabled>
                                                No departments available
                                              </option>
                                            )}
                                          </select>
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        {/* Select Manager Field */}
                                        <div className="form-group">
                                          <label htmlFor="selectManager">
                                            Select Manager
                                            {/* <span className="text-danger">
                                              {" "}
                                              *
                                            </span> */}
                                          </label>
                                          <select
                                            id="selectManager"
                                            ref={managerref}
                                            className="form-control form-control-sm"
                                            value={selectedManager}
                                            onChange={(e) => {
                                              setSelectedManager(
                                                e.target.value
                                              );
                                              managerref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                          >
                                            <option value="" disabled>
                                              Select a Manager
                                            </option>
                                            {allDeptManager.length > 0 ? (
                                              allDeptManager.map((allManager) => (
                                                <option
                                                  key={allManager.userID}
                                                  value={allManager.userID}
                                                >
                                                  {allManager.firstName}
                                                </option>
                                              ))
                                            ) : (
                                              <option disabled>
                                                No Manager available
                                              </option>
                                            )}
                                          </select>
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        {/* Select Designation Field */}

                                        <div className="form-group">
                                          <label htmlFor="assignEmail">
                                            Assign Designation
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>
                                          <input
                                            type="text"
                                            id="assignDesignation"
                                            ref={deisgnationref}
                                            className="form-control form-control-sm"
                                            placeholder="Enter designation"
                                            value={designation} // Controlled input
                                            onChange={(e) => {
                                              setDesignation(e.target.value);
                                              deisgnationref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                          />
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        {/* Select Joining Date Field */}

                                        <div className="form-group">
                                          <label htmlFor="joiningDate">
                                            Joining Date
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>

                                          <input
                                            type="date"
                                            id="joiningDate"
                                            ref={joiningdateref}
                                            className="form-control en-GB form-control-sm"
                                            value={joiningDate} // Controlled input
                                            onChange={(e) => {
                                              setJoiningDate(e.target.value);
                                              joiningdateref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                            min={today}
                                          />
                                        </div>
                                      </div>
                                      <div className="col-md-6">
                                        {/* Assign CtC to the employee */}
                                        <div className="form-group">
                                          <label htmlFor="assignCtc">
                                            Assign CTC
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>
                                          <input
                                            type="number"
                                            ref={ctcref}
                                            value={ctcvalue}
                                            className="form-control form-control-sm"
                                            placeholder="Enter Ctc"
                                            onChange={(e) => {
                                              setctcvalue(e.target.value);
                                              ctcref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                          />
                                        </div>
                                      </div>
                                      <div className="col-md-12">
                                        {/* Assign template to the employee */}
                                        <div className="form-group">
                                          <label>
                                            Assign Payroll Template
                                            <span className="text-danger">
                                              {" "}
                                              *
                                            </span>
                                          </label>
                                          <select
                                            className="form-control form-control-sm "
                                            id="userRoleNameInput"
                                            ref={templateref}
                                            style={{ display: "inline-block" }}
                                            value={selectedtemplate}
                                            onChange={(e) => {
                                              setSelectedTemplate(
                                                e.target.value
                                              );
                                              templateref.current.classList.remove(
                                                "is-invalid"
                                              );
                                            }}
                                          >
                                            <option value="">
                                              Select Template
                                            </option>
                                            {allTempalatesArray.map(
                                              (tempalate) => (
                                                <option
                                                  key={tempalate.autoId}
                                                  value={tempalate.autoId}
                                                >
                                                  {tempalate.templateName}
                                                </option>
                                              )
                                            )}
                                          </select>
                                        </div>
                                      </div>
                                    </div>

                                    {/* Select Probatin Field */}

                                    <div class="form-check form-switch">
                                      <input
                                        class="form-check-input"
                                        type="checkbox"
                                        role="switch"
                                        id="flexSwitchCheckDefault"
                                        onChange={handleProbationChange}
                                      />
                                      <label
                                        class="form-check-label"
                                        for="flexSwitchCheckDefault"
                                      >
                                        Add to probation period
                                      </label>
                                    </div>

                                    {isProbation == true ? (
                                      <div className="form-group mt-3">
                                        <select
                                          className="form-control form-control-sm"
                                          value={probationPeriod}
                                          onChange={(e) => {
                                            setProbationPeriod(e.target.value);
                                          }}
                                        >
                                          <option value="">
                                            Select period
                                          </option>
                                          <option value="3">3 months</option>
                                          <option value="6">6 months</option>
                                        </select>
                                      </div>
                                    ) : null}
                                    </div>

                                  {/* Modal Footer */}
                                  <div className="modal-footer justify-content-between">
                                    <button
                                      type="button"
                                      className="btn btn-secondary closebtn"
                                      data-dismiss="modal"
                                      onClick={() => {
                                        handleClose();
                                      }}
                                    >
                                      Close
                                    </button>
                                    <button
                                      type="button"
                                      className="btn btn-primary savebtn"
                                      onClick={handleAssign}
                                    >
                                      Assign
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        ) : null}
                      </div>
                    </div>
                    {/* {Bank Details} */}
                    <div className="tab-pane" id="bankDetails">
                      <form className="form row">
                        <div className="col-md-3 mb-3">
                          <label
                            htmlFor="accountNumber"
                            style={{ color: "#000" }}
                          >
                            Account Number<sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="number"
                            className="form-control form-control-sm"
                            id="accountNumber"
                            placeholder="Enter Account Number"
                            ref={inputAccNoReference}
                            value={accountNumber}
                            onChange={(e) => {
                              const value = e.target.value;
                              if (/^\d{0,18}$/.test(value)) {
                                setAccountNumber(value);
                              }
                              inputAccNoReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            onPaste={(e) => e.preventDefault()}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        <div className="col-md-3">
                          <label
                            htmlFor="confirmAccountNumber"
                            style={{ color: "#000" }}
                          >
                            Confirm Account Number
                            <sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="number"
                            className="form-control form-control-sm"
                            id="confirmAccountNumber"
                            placeholder="Confirm Account Number"
                            ref={inputConfirmAccNoReference}
                            value={confirmAccountNumber}
                            onChange={(e) => {
                              const value = e.target.value;
                              if (/^\d{0,18}$/.test(value)) {
                                setConfirmAccountNumber(value);
                              }
                              inputConfirmAccNoReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            onPaste={(e) => e.preventDefault()}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        <div className="col-md-3">
                          <label htmlFor="ifscCode" style={{ color: "#000" }}>
                            IFSC Code<sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            id="ifscCode"
                            placeholder="Enter IFSC Code"
                            ref={inputIfscCodeReference}
                            value={ifscCode}
                            onChange={(e) => {
                              setIfscCode(e.target.value);
                              inputIfscCodeReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            onBlur={handleIfscCodeBlur}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        <div className="col-md-3">
                          <label
                            htmlFor="accHolderName"
                            style={{ color: "#000" }}
                          >
                            Account Holder Name
                            <sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            id="accHolderName"
                            placeholder="Enter Account Holder Name"
                            ref={inputAccHolderNameReference}
                            value={accHolderName || empName}
                            onChange={(e) => {
                              setAccHolderName(e.target.value);
                              inputAccHolderNameReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        <div className="col-md-3">
                          <label htmlFor="bankName" style={{ color: "#000" }}>
                            Bank Name<sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            id="bankName"
                            placeholder="Enter Bank Name"
                            ref={inputBankNameReference}
                            value={bankName}
                            onChange={(e) => {
                              setBankName(e.target.value);
                              inputBankNameReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        <div className="col-md-3">
                          <label htmlFor="branchName" style={{ color: "#000" }}>
                            Branch Name<sup style={{ color: "red" }}>*</sup>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-sm"
                            id="branchName"
                            placeholder="Enter Branch Name"
                            ref={inputBranchNameReference}
                            value={branchName}
                            onChange={(e) => {
                              setBranchName(e.target.value);
                              inputBranchNameReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div>
                        {/* <div className="col-md-6">
                          <label
                            htmlFor="branchAddress"
                            style={{ color: "#000" }}
                          >
                            Branch Address
                          </label>
                          <textarea
                            className="form-control form-control-sm"
                            id="branchAddress"
                            placeholder="Enter Branch Address"
                            ref={inputBranchAddressReference}
                            value={branchAddress}
                            onChange={(e) => {
                              setBranchAddress(e.target.value);
                              inputBranchAddressReference.current.classList.remove(
                                "is-invalid"
                              );
                            }}
                            disabled={!isEditable} // <-- Disable when not in edit mode
                          />
                        </div> */}
                        <div className="form-group row mt-3">
                          <div className="offset-sm-2 col-sm-10 form-control-sm ml-2">
                            {isLoaderActive ? (
                              <PleaseWaitButton className="btn-sm font-weight-medium auth-form-btn" />
                            ) : isEditable ? (
                              <>
                                <div className="d-flex align-items-center">
                                  <button
                                    type="button"
                                    className="btn btn-primary form-control-sm mr-2"
                                    onClick={handleSaveClick}
                                  >
                                    Save
                                  </button>
                                  <button
                                    type="button"
                                    className="btn btn-danger form-control-sm"
                                    onClick={handleCancelClick}
                                  >
                                    Cancel
                                  </button>
                                </div>
                              </>
                            ) : (
                              <button
                                type="button"
                                className="btn btn-success form-control-sm"
                                onClick={handleEditClick}
                              >
                                Edit
                              </button>
                            )}
                          </div>
                        </div>
                      </form>
                    </div>
                    {/* {Tax Details} */}
                    <div className="tab-pane" id="taxDetails">
                      <div className="col-md-12 mt-3">
                        <div className="table-responsive">
                          <table
                            id="faqs"
                            className="table table-bordered table-sm"
                          >
                            <thead>
                              <tr className="text-sm">
                                <th>Sr. No.</th>
                                <th>Tax Name</th>
                                <th>Amount</th>
                                <th>Attachment</th>
                              </tr>
                            </thead>
                            <tbody>
                              {salaryComponentsArray.length > 0 ? (
                                salaryComponentsArray.map((data, index) => (
                                  <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td>
                                      <input
                                        className="form-control form-control-sm disable"
                                        value={
                                          declarations.find((item) => item.delarationId == data.delarationId )?.delarationType || ""}
                                          // data.delarationId && data.delarationId.length > 30 ? data.delarationId.substring(0, 30) + "..." : data.delarationId || ""}
                                        // title={data.delarationId || "No Declaration ID"}
                                        style={{ cursor: 'help' }}
                                        disabled
                                      />
                                    </td>
                                    <td>
                                      <input
                                        type="text"
                                        className="form-control form-control-sm disable"
                                        value={data.amount}
                                        disabled
                                      />
                                    </td>
                                    <td className="text-center">
                                      {data.prevAttachment ? (
                                        <a
                                          href={`${config.file_URL}${data.prevAttachment}`}
                                          target="_blank"
                                          rel="noopener noreferrer"
                                        >
                                          <i className="far fa-file-alt mr-1" aria-hidden="true"></i>
                                          View
                                        </a>
                                      ) : (
                                        <p className="mb-0 pt-1">No Attchement Found</p>
                                      )}
                                    </td>
                                  </tr>
                                ))
                              ) : (
                                <tr>
                                  <td colSpan="3" className="text-center">
                                    No data available
                                  </td>
                                </tr>
                              )}
                            </tbody>
                          </table>
                        </div>
                        {salaryComponentsArray.some(data => data.status === 'pending' && !(data.status === 'Rejected' || data.status === 'Approved')) && (
                          <div className="float-right">
                            <button type="button" className="btn btn-xs btn-danger mr-2" onClick={() => setShowModalReject(true)}>Reject</button>
                            <button type="button" className="btn btn-xs btn-primary" onClick={handleAcceptSend}>Approve</button>
                          </div>
                        )}
                      </div>
                    </div>

                    {showModalReject ? (
                      <>
                        <div
                          class="modal fade show"
                          id="modal-default"
                          style={{
                            display: "block",
                            paddingRight: "17px",
                            boxShadow: "#5d5858b 8",
                            backgroundColor: "#5d5858b8",
                          }}
                          aria-modal="true"
                          role="dialog"
                        >
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h4 class="modal-title">
                                  HR Remark<sup style={{ color: "red" }}>*</sup>{" "}
                                  <span
                                    hover-tooltip="Describe your remark"
                                    tooltip-position="bottom"
                                  >
                                    <i
                                      className="fas fa-info-circle my-1 ml-2"
                                      style={{ color: "rgb(0 0 0 / 51%)" }}
                                    ></i>
                                  </span>
                                </h4>
                                <button
                                  type="button"
                                  class="close btn-secondary"
                                  data-dismiss="modal"
                                  aria-label="Close"
                                  onClick={() => {
                                    setShowModalReject(false);
                                  }}
                                >
                                  <span aria-hidden="true">×</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <textarea
                                  class=" w-100 form-control"
                                  placeholder="Describe your remark"
                                  value={rejectRemark}
                                  onChange={(e) =>
                                    setRejectRemark(e.target.value)
                                  }
                                />
                              </div>
                              <div class="modal-footer justify-content-between">
                                <button
                                  type="button"
                                  class="btn btn-secondary closebtn"
                                  data-dismiss="modal"
                                  onClick={() => {
                                    handleRejectClose();
                                  }}
                                >
                                  Close
                                </button>
                                <button
                                  type="button"
                                  className="btn btn-primary savebtn"
                                  onClick={handleRejectSend}
                                >
                                  Reject
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : null}
                  </div>

                  <div
                    class="modal modal-verify-document-class d-none"
                    id="modal-verify-document "
                    style={{
                      display: "block",
                      paddingRight: "17px",
                      boxShadow: "#5d5858b 8",
                      backgroundColor: "#5d5858b8",
                    }}
                    aria-modal="true"
                    role="dialog"
                  >
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">
                            Verify{" "}
                            <span
                              hover-tooltip="Describe your remark"
                              tooltip-position="bottom"
                            >
                              <i
                                className="fas fa-info-circle my-1 ml-2"
                                style={{ color: "rgb(0 0 0 / 51%)" }}
                              ></i>
                            </span>
                          </h4>
                          <button
                            type="button"
                            class="close btn-secondary"
                            data-dismiss="modal"
                            aria-label="Close"
                            onClick={() => {
                              setShowModal(false);
                            }}
                          >
                            <span aria-hidden="true">×</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          {checkThisForAttachmentClick == 'adharAttachment'? <h5>Enter aadhar number
                          <span className="text-danger"> *</span>

                          </h5>: <h5>Enter pan number
                          <span className="text-danger"> *</span>

                          </h5>}
                          
                          <input
                            class=" w-100 form-control"
                           
                            placeholder= {checkThisForAttachmentClick == 'adharAttachment'?"Enter aadhar number":"Enter pan number"}
                            
                            
                            value={verificationInput} // Controlled input
                            onChange={(e) =>
                              setVerificationInput(e.target.value)
                            } // Update state on change
                          />
                        </div>
                        <div class="modal-footer justify-content-betsetRemarkween">
                          <button
                            type="button"
                            class="btn btn-secondary closebtn"
                            data-dismiss="modal"
                            onClick={() => {
                              handleClose();
                            }}
                          >
                            Close
                          </button>
                          <button
                            type="button"
                            className="btn btn-primary savebtn"
                            onClick={() => {
                              handleVerify();
                            }} // Call handleSend on click
                          >
                            Verify
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <ToastContainer position="top-center" />
    </>
  );
};

export default EmployeeDetails;
