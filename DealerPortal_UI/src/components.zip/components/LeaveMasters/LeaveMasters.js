import React, { useEffect, useState, useRef } from "react";
import { Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import axios from "axios";
import config from "../../config/config.json";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


function LeaveMasters() {
  const [showModal, setShowModal] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [selectedDepartment, setSelectedDepartment] = useState(null);
  const [data, setData] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [employees, setEmployees] = useState([]);
  const [selectedData, setSelectedData] = useState(null);
  const [leavesType, setLeavesType] = useState([]);
  const [leaveType, setLeaveType] = useState("");
  const [noOfDays, setNoOfDays] = useState("");
  const [remarks, setRemarks] = useState("");
  const [leaveData, setLeaveData] = useState([]);
  const leaveTypeRef = useRef(null);
  const daysRef = useRef(null);
  const remarkRef = useRef(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [searchText, setSearchText] = useState("");
  const rowsPerPage = 10;

  useEffect(() => {
    GetLeaves();
    GetDepartments();
    GetAllLeaves();
    GetAllEmployees();
  }, []);

  const GetLeaves = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveType/GetAllLeaveTypes`
      );
      const leaveArray = response.data.data || [];
      setLeavesType(leaveArray);
    } catch(error) {
      console.error("Error fetching LeaveTypes:", error);
      toast.error("Error fetching LeaveTypes");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetEmployeeLeaveById = async (employee) => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveQuotaMaster/getEmpleaveinfobyId?empId=${employee.empId}`
      );
      const appsArray = response.data.data || [];
      setLeaveData(appsArray);
    } catch(error) {
      console.error("Error fetching Employee Data", error);
      toast.error("Error fetching Employee Data");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllEmployees = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}AuthMaster/GetAllEmpInfo`
      );

      const appsArray = response.data.data || [];
      const filteredAppsArray = appsArray.filter((app) => !app.isDelete);
      // console.log("all employee-->", appsArray);
      setEmployees(filteredAppsArray);
      setTimeout(() => {
        // if(!$.fn.DataTable.isDataTable('#example1')) {
        //   $('#example1').DataTable({ ...});
        // }

        window.initDataTable();
      }, 500);
    } catch(error) {
      console.error("Error fetching employees:", error);
      toast.error("Error fetching employees");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetDepartments = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}Department/GetAllDepartments`
      );
      const deptArray = response.data.data || [];

      setDepartments(deptArray);
    } catch(error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllLeaves = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveQuotaMaster/getLeaveBalanceQuotaMaster`
      );
      const appsArray = response.data.data || [];

      setData(appsArray);
    } catch(error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleViewClick = (employee) => {
    window.initDestroyDataTableFuncation();
    setTimeout(() => {
      setSelectedData(employee);
      setShowModal(true);
      setLeaveData([]);
      GetEmployeeLeaveById(employee);
    }, 500);
    setTimeout(() => {
      window.initAgainDestroyDataTableFuncation();
    }, 500);
  };

  const handleCloseModal = () => {
    clearAllFields();
    setShowModal(false);
    window.initDestroyDataTableFuncation();
    setTimeout(() => {
      window.initDataTable();
    }, 500);
    setSelectedData(null);
    setLeaveData([]);
  };


  const clearAllFields = () => {
    setRemarks("");
    setLeaveType("");
    setNoOfDays("");
  }

  const handleSendData = async () => {
    leaveTypeRef.current.classList.remove("is-invalid");
    daysRef.current.classList.remove("is-invalid");
    remarkRef.current.classList.remove("is-invalid");

    if(!leaveTypeRef.current.value) {
      leaveTypeRef.current.focus();
      leaveTypeRef.current.classList.add("is-invalid");
      toast.error("Please select a Leave Type.");
      setIsLoaderActive(false);

      return;
    }
    if(!noOfDays || noOfDays <= 0) {
      daysRef.current.focus();
      daysRef.current.classList.add("is-invalid");
      toast.error("Please enter a valid number of days.");
      setIsLoaderActive(false);

      return;
    }
    if(!remarks) {
      remarkRef.current.focus();
      remarkRef.current.classList.add("is-invalid");
      toast.error("Please enter remark.");
      setIsLoaderActive(false);

      return;
    }

    setIsLoaderActive(true);
    try {
      const payload = {
        EmpId: selectedData.empId,
        LeaveType: leaveType,
        TotalLeaves: String(noOfDays),
        Remarks: remarks || "",
      };

      const response = await axios.post(
        `${config.API_URL}LeaveQuotaMaster/addLeaveQuotaMaster`,
        payload
      );

      toast.success("Leave quota added successfully.");
      leaveTypeRef.current.classList.remove("is-invalid");
      daysRef.current.classList.remove("is-invalid");
      remarkRef.current.classList.remove("is-invalid");
      setNoOfDays("");
      setRemarks("");
      setLeaveType("");
      GetEmployeeLeaveById(selectedData);

      setIsLoaderActive(false);
    } catch(error) {
      console.error(
        "Error adding leave quota:",
        error.response?.data || error.message
      );

      if(error.response?.data?.title) {
        toast.error(error.response.data.title);
      } else {
        toast.error("Error adding leave quota.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const filteredEmployees = selectedDepartment
    ? employees.filter((employee) => employee.department == selectedDepartment)
    : employees;


  const filteredSearch = filteredEmployees.filter((emp) =>
    Object.values(emp).some(
      (val) =>
        val && val.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredSearch.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredSearch.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, filteredSearch.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };



  const exportToCSV = () => {
    let csvContent = "Name,Department\n";
    filteredSearch.forEach((emp) => {
      const department = departments.find(d => d.departmentID == emp.department)?.departmentName || "NA";
      csvContent += `${emp.firstName},${department}\n`;
    });
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "LeaveMasterData.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredSearch.map(emp => ({
        Name: emp.firstName,
        Department: departments.find(d => d.departmentID == emp.department)?.departmentName || "NA",
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "LeaveMasters");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "LeaveMasterData.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Leave Masters", 14, 10);
    autoTable(doc, {
      head: [["Name", "Department"]],
      body: filteredSearch.map(emp => [
        emp.firstName,
        departments.find(d => d.departmentID == emp.department)?.departmentName || "NA"
      ]),
    });
    doc.save("LeaveMasterData.pdf");
  };
  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print Leave Masters</title></head><body>");
    printWindow.document.write("<h3>Leave Masters</h3>");
    printWindow.document.write("<table border='1' cellspacing='0' cellpadding='5'><thead><tr><th>Sr No</th><th>Name</th><th>Department</th></tr></thead><tbody>");

    filteredSearch.forEach((emp, index) => {
      const department = departments.find(d => d.departmentID == emp.department)?.departmentName || "NA";
      printWindow.document.write(`<tr><td>${index + 1}</td><td>${emp.firstName}</td><td>${department}</td></tr>`);
    });

    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };





  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-lg-6">
              <h5 className="m-0">Leave Masters</h5>
            </div>

            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">Leave Masters </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div className="container-fluid">
          <div className="col-md-12">
            <div className="card card-primary card-outline">
              <div className="card-header">
                <div className="row align-items-center">
                  <div className="col-md-6">
                    {!showModal && !selectedData ? (
                      <h3 className="card-title ml-1">
                        Leave Masters ({filteredEmployees.length})
                        <span
                          hover-tooltip="This Leave Master screen allows HR to view all employees by department and manage their leave assignments. HR can assign leaves by using the action button available in the table for each employee."
                          tooltip-position="bottom"
                        >
                          <i
                            class="fas fa-info-circle ml-2"
                            style={{ color: "rgb(0 0 0 / 51%)" }}
                          ></i>
                        </span>
                      </h3>
                    ) : (
                      <h3 className="card-title ml-1">Employee Details
                        <span
                          hover-tooltip="This page enables HR to assign new leaves to employees. If existing leaves have expired, HR can add new ones. In cases where an employee has pending leaves of the same type, the previous leaves will be replaced with the newly assigned leaves."
                          tooltip-position="bottom"
                        >
                          <i
                            class="fas fa-info-circle ml-2"
                            style={{ color: "rgb(0 0 0 / 51%)" }}
                          ></i>
                        </span>
                      </h3>
                    )}
                  </div>
                  <div className="col-md-6">
                    {!showModal ? (
                      <div className="card-tools float-right">
                        <button
                          type="button"
                          className="btn btn-tool float-right"
                          data-card-widget="maximize"
                        >
                          <i className="fas fa-expand"></i>
                        </button>
                      </div>
                    ) : (
                      <div className="float-right d-flex align-items-center justify-content-center">
                        {isLoaderActive ? (
                          <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                        ) : (
                          <button
                            className="btn btn-primary btn-sm mr-2"
                            onClick={handleSendData}
                          >
                            Save
                          </button>
                        )}
                        <button
                          className="btn btn-danger btn-sm"
                          onClick={handleCloseModal}
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          className="btn btn-tool float-right ml-2"
                          data-card-widget="maximize"
                        >
                          <i className="fas fa-expand"></i>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {!showModal && !selectedData && (
                <div
                  className="card-header"
                  style={{ backgroundColor: "rgb(153 198 241 / 39%)" }}
                >
                  <div className="col-md-12">
                    <div className="row">
                      <div
                        className="button-container d-flex"
                        style={{
                          overflowX: "auto",
                          whiteSpace: "nowrap",
                          paddingBottom: "5px",
                          paddingTop: "5px",
                          scrollbarWidth: "none",
                          msOverflowStyle: "none",
                        }}
                      >
                        <style>
                          {`.button-container::-webkit-scrollbar {display: none; }`}
                        </style>
                        <button
                          className={`btn btn-sm mr-2 d-flex justify-content-center align-items-center ${selectedDepartment == null
                            ? "btn-primary active-btn"
                            : ""
                            }`}
                          style={{
                            border: "2px solid #FFFFFF",
                            backgroundColor:
                              selectedDepartment == null ? "" : "#FFFFFF",
                            boxShadow:
                              selectedDepartment == null
                                ? "0px 4px 8px rgba(0, 0, 0, 0.4), 0px 2px 6px rgba(0, 0, 0, 0.2)"
                                : "0px 2px 6px rgba(0, 0, 0, 0.2)",
                            transition:
                              "box-shadow 0.2s ease, transform 0.2s ease",
                            transform:
                              selectedDepartment == null
                                ? "translateY(-2px)"
                                : "none",
                          }}
                          onClick={() => setSelectedDepartment(null)}
                        >
                          All Departments
                        </button>
                        {departments.map((dept, index) => (
                          <button
                            key={index}
                            className={`btn btn-sm mr-2 d-flex justify-content-center align-items-center ${selectedDepartment == dept.departmentID
                              ? "btn-primary active-btn"
                              : ""
                              }`}
                            style={{
                              border: "2px solid #FFFFFF",
                              backgroundColor:
                                selectedDepartment == dept.departmentID
                                  ? ""
                                  : "#FFFFFF",
                              boxShadow:
                                selectedDepartment == dept.departmentID
                                  ? "0px 4px 6px rgba(0, 0, 0, 0.4), 0px 2px 4px rgba(0, 0, 0, 0.2)"
                                  : "0px 2px 4px rgba(0, 0, 0, 0.2)",
                              transition:
                                "box-shadow 0.5s ease, transform 0.2s ease",
                              transform:
                                selectedDepartment == dept.departmentID
                                  ? "translateY(-2px)"
                                  : "none",
                            }}
                            onClick={() =>
                              setSelectedDepartment(dept.departmentID)
                            }
                          >
                            {dept.departmentName}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="card-body position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div className="row">
                  <div className="col-md-12 ">

                    {!showModal && !selectedData && (
                      <>
                        <div className="d-flex justify-content-between mb-2">
                          <div>
                            <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                            <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                            <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                            <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                          </div>
                          <input
                            type="text"
                            className="form-control form-control-sm w-25"
                            placeholder="Search..."
                            onChange={(e) => {
                              setSearchText(e.target.value);
                              setCurrentPage(1);
                            }}
                          />
                        </div>
                        <table
                          className="table table-bordered table-sm"
                        >
                          <thead>
                            <tr>
                              <th>Sr NO</th>
                              <th>Name</th>
                              <th>Department</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody className="text-sm">
                            {filteredEmployees.length == 0 ? (
                              <tr>
                                <td colSpan="4" className="text-center">
                                  No data found
                                </td>
                              </tr>
                            ) : (
                              currentRows.map((employee, index) => (
                                <tr
                                  key={employee.empId || index}
                                  style={{
                                    backgroundColor:
                                      index % 2 !== 0 ? "white" : "#e9ecef",
                                  }}
                                >
                                  <td>{indexOfFirstRow + index + 1}</td>
                                  <td>{employee.firstName || "N/A"}</td>
                                  <td>
                                    {employee.department
                                      ? departments.find(
                                        (dept) =>
                                          dept.departmentID ==
                                          employee.department
                                      )?.departmentName
                                      : "NA"}
                                  </td>
                                  <td className="text-center">
                                    <span
                                      className="btn btn-outline-primary btn-xs cursor-pointer mr-1"
                                      title="View Employee"
                                      onClick={() => handleViewClick(employee)}
                                    >
                                      <i className="fas fa-eye"></i>
                                    </span>
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                        <div className="d-flex justify-content-between mt-2">
                          <div>
                            Showing {startEntry} to {endEntry} of {filteredSearch.length} entries
                          </div>
                          <div>
                            <button
                              className="btn btn-xs btn-outline-primary"
                              onClick={() => handlePageChange(currentPage - 1)}
                              disabled={currentPage === 1}
                            >
                              <i className="fas fa-angle-double-left"></i>
                            </button>
                            <span className="m-1">Page {currentPage} of {totalPages}</span>
                            <button
                              className="btn btn-xs btn-outline-primary"
                              onClick={() => handlePageChange(currentPage + 1)}
                              disabled={currentPage === totalPages}
                            >
                              <i className="fas fa-angle-double-right"></i>
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                    {showModal && selectedData && (
                      <>
                        <div className="container-fluid">
                          <div className="row mb-4">
                            <div class="col-md-4 mb-3">
                              <label className="pr-2">Name</label>
                              <input
                                type="text"
                                className="form-control form-control-sm"
                                value={selectedData.firstName}
                                readOnly
                              />
                            </div>
                            <div class="col-md-4 mb-3">
                              <label className="pr-2">Department</label>
                              <input
                                type="text"
                                className="form-control form-control-sm"
                                value={
                                  selectedData.department
                                    ? departments.find(
                                      (dept) =>
                                        dept.departmentID ==
                                        selectedData.department
                                    )?.departmentName
                                    : "NA"
                                }
                                readOnly
                              />
                            </div>
                            <div className="col-md-4 mb-3">
                              <label className="pr-2">Leave Type
                              <span className="text-danger"> *</span>
                              </label>
                              <select
                                className="form-control form-control-sm col-sm-12"
                                name="leaveType"
                                value={leaveType}
                                ref={leaveTypeRef}
                                onChange={(e) => setLeaveType(e.target.value)}
                              >
                                <option value="">
                                  -- Select Leave Type --
                                </option>
                                {leavesType.map((role, index) => (
                                  <option key={role.id} value={role.id}>
                                    {role.leaveTypeName}
                                  </option>
                                ))}
                              </select>
                            </div>
                            <div className="col-md-4 mb-3">
                              <label className="pr-2">No of days<span className="text-danger"> *</span></label>                                                  
                              <input
                                type="number"
                                className="form-control form-control-sm"
                                placeholder="No of days"
                                ref={daysRef}
                                name="noOfDays"
                                value={noOfDays}
                                onChange={(e) => setNoOfDays(e.target.value)}
                              ></input>
                            </div>
                            <div className="col-lg-8 mb-3">
                              <label className="pr-2">Remarks
                              <span className="text-danger"> *</span>
                              </label>
                              <textarea
                                className="form-control form-control-sm"
                                style={{ resize: "none" }}
                                placeholder="Enter your remarks..."
                                name="remarks"
                                ref={remarkRef}
                                value={remarks}
                                onChange={(e) => setRemarks(e.target.value)}
                              ></textarea>
                            </div>
                          </div>
                        </div>

                        <div className="container-fluid">
                          <div className="row">
                            <div className="col-md-12">
                              <table
                                className="table table-bordered table-sm"
                                id="d"
                              >
                                <thead>
                                  <tr>
                                    <th>Sr NO</th>
                                    <th>Leave Type</th>
                                    <th>No of Days


                                    </th>
                                    <th>From</th>
                                    <th>To</th>
                                    <th>Remarks</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {leaveData.length == 0 ? (
                                    <tr>
                                      <td
                                        colSpan="6"
                                        style={{ textAlign: "center" }}
                                      >
                                        No data available
                                      </td>
                                    </tr>
                                  ) : (
                                    leaveData
                                      .slice()
                                      .reverse()
                                      .map((item, index) => {
                                        const leaveTypeMapping = leavesType
                                          ? leavesType.find(
                                            (l) => l.id == item.leaveType
                                          )?.leaveTypeName || "N/A"
                                          : "N/A";
                                        // return (
                                        //   <tr
                                        //     key={item.empId || index}
                                        //     style={{
                                        //       background:
                                        //         item.totalLeaves -
                                        //           item.takenLeaves ===
                                        //           0
                                        //           ? "red"
                                        //           : index % 2 !== 0
                                        //             ? "white !important"
                                        //             : "#e9ecef",
                                        //       color:
                                        //         item.totalLeaves -
                                        //           item.takenLeaves ===
                                        //           0
                                        //           ? "white"
                                        //           : item.isExpired
                                        //             ? "#726D6A"
                                        //             : "black",
                                        //       textDecoration:
                                        //         item.isExpired ||
                                        //           item.totalLeaves -
                                        //           item.takenLeaves ===
                                        //           0
                                        //           ? "line-through"
                                        //           : "none",
                                        //     }}
                                        //   >
                                        //     <td> {index + 1} </td>
                                        //     <td> {leaveTypeMapping} </td>
                                        //     <td>
                                        //       {" "}
                                        //       {item.totalLeaves -
                                        //         item.takenLeaves}{" "}
                                        //     </td>
                                        //     <td>
                                        //       {new Date(item.fromDate)
                                        //         .toISOString()
                                        //         .split("T")[0]
                                        //         .split("-")
                                        //         .reverse()
                                        //         .join("-")}
                                        //     </td>
                                        //     <td>
                                        //       {new Date(item.toDate)
                                        //         .toISOString()
                                        //         .split("T")[0]
                                        //         .split("-")
                                        //         .reverse()
                                        //         .join("-")}
                                        //     </td>

                                        //     <td> {item.remarks} </td>
                                        //   </tr>
                                        // );
                                        return (
                                          (item.totalLeaves - item.takenLeaves !== 0 && !item.isExpired) && (
                                            <tr
                                              key={item.empId || index}
                                              style={{
                                                background: index % 2 !== 0 ? "white" : "#e9ecef",
                                                color: "black",
                                                textDecoration: "none",
                                              }}
                                            >
                                              <td>{index + 1}</td>
                                              <td>{leaveTypeMapping}</td>
                                              <td>{item.totalLeaves - item.takenLeaves}</td>
                                              <td>
                                                {new Date(item.fromDate)
                                                  .toISOString()
                                                  .split("T")[0]
                                                  .split("-")
                                                  .reverse()
                                                  .join("-")}
                                              </td>
                                              <td>
                                                {new Date(item.toDate)
                                                  .toISOString()
                                                  .split("T")[0]
                                                  .split("-")
                                                  .reverse()
                                                  .join("-")}
                                              </td>
                                              <td>{item.remarks}</td>
                                            </tr>
                                          )
                                        );

                                      })
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <ToastContainer position="top-center" />
      </div>
    </>
  );
}

export default LeaveMasters;
