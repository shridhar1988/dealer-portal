import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import "./EmployeeLeave.css";

function EmployeeApplyLeave() {
  const navigate = useNavigate();

  return (
    <>
      <div className="container-fluid">
        <div className="col-md-12">
          <div class="row"></div>
        </div>
      </div>

      <div className="container-fluid">
        <div className="col-md-12 p-3">
          {/* First Card Section */}
          <div class="row">
            <div class="col-lg-4 col-4">
              <div class="small-box bg-info-card4 card2">
                <div class="inner">
                  <h3 class="ng-binding">1</h3>
                  <p>Sick Leave</p>
                </div>
                <div class="icon">
                  <i class="fas fa-user-tie img-fluid"></i>
                </div>
                <div class="go-corner" href="#">
                  <div class="go-arrow">→</div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-4">
              <div class="small-box bg-info-card3 card3">
                <div class="inner">
                  <h3 class="ng-binding">2</h3>
                  <p>Casual Leave</p>
                </div>
                <div class="icon">
                  <i class="fas fa-user-plus img-fluid"></i>
                </div>
                <div class="go-corner" href="#">
                  <div class="go-arrow">→</div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-4">
              <div class="small-box bg-info-card5 card4">
                <div class="inner">
                  <h3 class="ng-binding">3</h3>
                  <p>Paid Leave</p>
                </div>
                <div class="icon">
                  <i class="fas fa-user-check img-fluid"></i>
                </div>
                <div class="go-corner" href="#">
                  <div class="go-arrow">→</div>
                </div>
              </div>
            </div>
          </div>

          <div className="card card-outline card-danger">
            <div className="card-header">
              {" "}
              <i class="fas fa-arrow-left ml-2"></i> Apply Leave
            </div>
            <div className="card-body">
              {/* Leave Type */}
              <div class="row">
                <div class="col-lg-1 col-md-2 col-sm-4">
                  <label>Leave Type</label>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-8">
                  <select class="form-control form-control-sm">
                    <option value="" key="">
                      --Select--
                    </option>
                    <option value="1" key="">
                      1
                    </option>
                    <option value="2" key="">
                      2
                    </option>
                  </select>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-1 col-md-2 col-sm-4">
                  <label>From</label>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-8">
                  <div className="row">
                    <div class="form-group col-lg-5 col-md-6 col-sm-8">
                      <input
                        type="date"
                        class="form-control form-control-sm"
                      ></input>
                    </div>
                    <div class="form-group col-lg-2 col-md-6 col-sm-8">
                      <label>TO</label>
                    </div>
                    <div class="form-group col-lg-5 col-md-6 col-sm-8">
                      <input
                        type="date"
                        class="form-control form-control-sm"
                      ></input>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-1 col-md-2 col-sm-4">
                  <label>Reason</label>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-8">
                  <textarea
                    type="text"
                    class="input-group form-control form-control-sm"
                    style={{ minHeight: "60px" }}
                  ></textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-1 col-md-2 col-sm-4">
                  <label>Attachments</label>
                </div>
                <div class="form-group col-lg-6 col-md-6 col-sm-8">
                  <div class="form-group">
                    <label for="exampleInputFile">File input</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input
                          type="file"
                          class="custom-file-input"
                          id="exampleInputFile"
                        ></input>
                        <label class="custom-file-label" for="exampleInputFile">
                          Choose file
                        </label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text">Upload</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row p-2">
                <button class="btn btn-success btn-sm mr-2">Submit</button>
                <button class="btn btn-danger btn-sm mr-2">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default EmployeeApplyLeave;
