import React, { useEffect, useState, useRef } from "react";
import { ToastContainer, toast } from "react-toastify";
import { useSelector } from "react-redux";
import axios from "axios";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import config from "../../config/config.json";
import "./EmployeeLeave.css";
import $ from "jquery";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


export default function EmployeeLeave() {
  const [isApply, setIsApply] = useState(false);
  const [disableToDate, setDisableToDate] = useState(false);
  const [leaveEntries, setLeaveEntries] = useState([]);
  const [leaveData, setLeaveData] = useState([]);
  const [leaveEmpData, setLeaveEmpData] = useState([]);
  const [optiondata, setoptiondata] = useState([]);
  const [attachment, setAttachment] = useState(null);
  const [leaveSession, setLeaveSession] = useState("");
  const [leavesType, setLeavesType] = useState([]);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;


  const [appId, setAppId] = useState("");
  const [manager, setManager] = useState("");
  const [managerName, setManagerName] = useState("");
  const [leavesTypeName, setLeavesTypeName] = useState([]);
  const [leavesTypeNameForemp, setLeavesTypeNameForemp] = useState([]);

  const [managers, setManagers] = useState([]);
  const [empData, setEmpData] = useState();
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [empleaveinfo, setEmpleaveinfo] = useState(false);

  const [pendingLeaves, setPendingLeaves] = useState(0);
  const [totalLeaves, setTotalLeaves] = useState(0);
  const [takenLeaves, setTakenLeaves] = useState(0);
  const selectAppsReference = useRef(null);
  const radioBtnRef = useRef(null);
  const fromDateRef = useRef(null);
  const toDateRef = useRef(null);
  const reasonRef = useRef(null);
  const fromSessionReference = useRef(null);
  const toSessionReference = useRef(null);
  const attachmentRef = useRef(null);
  const leaveTypeRef = useRef(null);

  const [formData, setFormData] = useState({
    fromSession: "",
    toSession: "",
    fromDate: new Date().toISOString().split("T")[0],
    toDate: new Date().toISOString().split("T")[0],
    reason: "",
  });

  const personalInfo = useSelector((state) => state.personalInformationReducer);

  const filteredEntries = leaveEntries.filter((entry) =>
    (leavesTypeName[entry.leaveType] || "Unknown Type")
      .toLowerCase()
      .includes(searchText.toLowerCase())
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredEntries.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredEntries.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, filteredEntries.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };


  // const empId = "9f46ccc0-349b-47b1-b87b-c50b369ae529";
  const empId = personalInfo.userID;

  const resetForm = () => {
    setFormData({
      fromSession: "",
      toSession: "",
      fromDate: "",
      toDate: "",
      reason: "",
    });
    setDisableToDate(false);
    setLeaveSession("");
    setAttachment(null);
  };

  useEffect(() => {
    window.initDatePickerFuncation();
    GetAllManagers();
    fetchLeaveData();
    GetLeaves();
    GetLeaveBalanceFromEmpid();
    isEmpLeaveValid();
    GetRemainingLeavesBasedonEmpid();
    setTimeout(() => {
      // GetManager();
    }, 500);
  }, []);

  const isEmpLeaveValid = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AuthMaster/GetAllEmpInfo`
      );
      if(response.data.success == true) {
        let data = response.data.data;
        // console.log("data--->", data);

        const isEmpIdPresentAndLeavesValid = data.some(
          (item) => item.empId === empId && item.isProbation != true
        );
        // console.log(
        //   "isEmpIdPresentAndLeavesValid--->",
        //   isEmpIdPresentAndLeavesValid
        // );

        setEmpleaveinfo(isEmpIdPresentAndLeavesValid || false);
      } else {
        console.error("Error fetching Employee leave information:");
      }
    } catch(error) {
      console.error("Error fetching Employee leave information:");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const GetManager = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}AuthMaster/GetEmpInfoByEmpId?id=${empId}`
      );
      // console.log("response----->",response);

      if(response.data.success == true) {
        setEmpData(response.data.data);
        // console.log(
        //   "response.data.data.empInfo.assignedManager----->",
        //   response.data.data.empInfo.assignedManager
        // );

        if(response.data.data.empInfo.assignedManager) {
          let managerName = managers.find(
            (m) => m.userID == response.data.data.empInfo.assignedManager
          );
          // console.log("managerName----->", managerName.firstName);
          setManager(response.data.data.empInfo.assignedManager || []);
          setManagerName(managerName.firstName || "");
        }
        // setManager(response.data.data.empInfo.assignedManager);
      } else {
        toast.error("Error fetching Manager");
      }
    } catch(error) {
      console.error("Error fetching Manager:", error);
      // toast.error('Error fetching Manager');
    } finally {
      setIsLoaderActive(false);
    }
  };
  function formatDate(date) {
    const d = new Date(date);
    const day = String(d.getDate()).padStart(2, "0"); // Add leading zero if necessary
    const month = String(d.getMonth() + 1).padStart(2, "0"); // Months are 0-indexed
    const year = d.getFullYear();
    return `${day}-${month}-${year}`;
  }

  const GetAllManagers = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}AuthMaster/GetAllManagers`
      );
      const appsArray = response.data.data || [];
      // console.log("all managers---->", appsArray);
      setManagers(appsArray);
    } catch(error) {
      console.error("Error fetching Manager:", error);
      toast.error("Error fetching Manager");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetLeaveBalanceFromEmpid = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveQuotaMaster/getEmpleaveinfobyId?EmpId=${empId}`
      );
      if(response.data.success) {
        const processedEntries = response.data.data;
        // console.log("Leaves--->", processedEntries);
        let total = 0;
        let pending = 0;

        processedEntries.forEach((element) => {
          pending += parseFloat(element.takenLeaves) || 0;
          total += parseFloat(element.totalLeaves) || 0;
        });
        setTotalLeaves(total);
        setTakenLeaves(pending);
        setPendingLeaves(total - pending);
        setLeaveData(processedEntries);
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      console.error("Error fetching leave data", error);
    } finally {
      setIsLoaderActive(false);
    }
  };
  const GetRemainingLeavesBasedonEmpid = async () => {
    try {
      const response = await axios.get(
        `${config.API_URL}LeaveQuotaMaster/getEmpleaveinfobyId?EmpId=${empId}`
      );
      if(response.data.success) {
        const appsArray = response.data.data || [];
        setLeaveEmpData(appsArray);
        setoptiondata(appsArray);
        // console.log("data -------------->", appsArray);
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      toast.error("Error Fetching Data");
    }
  };

  const GetLeaves = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveType/GetAllLeaveTypes`
      );
      const appsArray = response.data.data || [];
      // console.log("leave types---->", response.data.data);
      const leaveTypeMapping = appsArray.reduce((acc, type) => {
        acc[type.id] = type.leaveTypeName; // Use leaveTypeName here
        return acc;
      }, {});
      // console.log("leavetypename----------->", leaveTypeMapping);
      setLeavesTypeName(leaveTypeMapping);
      setLeavesTypeNameForemp(leaveTypeMapping);
      setLeavesType(appsArray);
    } catch(error) {
      console.error("Error fetching LeaveTypes:", error);
      toast.error("Error fetching LeaveTypes");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const fetchLeaveData = async () => {
    setIsLoaderActive(true);

    try {
      window.initDestroyDataTableFuncation();
      const response = await axios.get(
        `${config.API_URL}LeaveManagement/GetAllAppledLeavesByUserId?EmpId=${empId}`
      );
      if(response.data.success) {
        const processedEntries = response.data.data;
        // console.log("processedEntries--->", processedEntries);

        processedEntries.map((entry) => {
          const fileName = entry.attachmentPath?.split("\\").pop() || "";

          const isImage =
            fileName.endsWith(".png") ||
            fileName.endsWith(".jpg") ||
            fileName.endsWith(".jpeg");
          const isPDF = fileName.endsWith(".pdf");

          return {
            ...entry,
            fileName,
            isImage,
            isPDF,
          };
        });
        // console.log("processedEntries--->", processedEntries);

        setLeaveEntries(processedEntries);

        setTimeout(() => {
          window.initDataTable();
        }, 1000);
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      console.error("Error fetching leave data", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleDateChange = (event) => {
    toDateRef.current.classList.remove("is-invalid");
    fromDateRef.current.classList.remove("is-invalid");
    const { name, value } = event.target;

    if(disableToDate && name == "fromDate") {
      setFormData({ ...formData, fromDate: value, toDate: value });
    } else {
      if(name === "fromDate" && new Date(value) > new Date(formData.toDate)) {
        setFormData({ ...formData, fromDate: value, toDate: value });
        // toast.error(
        //   "From date cannot be greater than To date. To date has been adjusted."
        // );
        return;
      }
      if(name === "toDate" && new Date(value) < new Date(formData.fromDate)) {
        toast.error("To date cannot be less than From date");
        return;
      }
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleLeaveTypeChange = (event) => {
    leaveTypeRef.current.classList.remove("is-invalid");
    formData.reason = "";
    setFormData({ ...formData, leaveType: event.target.value });
  };

  const handleToSessionChange = (event) => {
    toSessionReference.current.classList.remove("is-invalid");
    formData.toSession = "";
    setFormData({ ...formData, toSession: event.target.value });
  };

  const handleFromSessionChange = (event) => {
    fromSessionReference.current.classList.remove("is-invalid");
    formData.fromSession = "";
    setFormData({ ...formData, fromSession: event.target.value });
  };

  const handleDelete = async (entry) => {
    // console.log("entry---->", entry);

    try {
      const payload = {
        empId: empId,
        leaveId: entry.leaveId,
        leaveType: entry.leaveType,
        createdBy: empId,
        leaveCount: entry.leaveCount || 0,
      };

      const response = await axios.post(
        `${config.API_URL}LeaveManagement/DeleteLeave`,
        payload
      );

      if(response.data.success) {
        toast.error("Leave deleted successfully!");
        fetchLeaveData();
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      toast.error("Error occurred during leave deletion:", error);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if(file) {
      setAttachment(file);
    }
  };

  const handleRemoveFile = (e) => {
    setAttachment(null);
  };

  const handleChange = (e) => {
    setIsApply(false);

    // setTimeout(() => {
    //   window.initMultiSelectFuncation();
    // }, 500);
  };

  const handleLeaveApplicationToggle = () => {
    GetManager();
    // if (empleaveinfo == false) {
    //   toast.error("Leaves not available! You are on probation period");
    // } else {
    setIsApply(!isApply);
    setTimeout(() => {
      window.$(".select2").select2();
    }, 500);
    // }
  };

  const handleSubmit = async (event) => {
    debugger;
    event.preventDefault();
    let getAllSelectedApps = $(".select2").val();

    leaveTypeRef.current?.classList.remove("is-invalid");
    radioBtnRef.current?.classList.remove("is-invalid");
    toSessionReference.current?.classList.remove("is-invalid");
    fromSessionReference.current?.classList.remove("is-invalid");
    attachmentRef.current?.classList.remove("is-invalid");
    toDateRef.current?.classList.remove("is-invalid");
    fromDateRef.current?.classList.remove("is-invalid");
    reasonRef.current?.classList.remove("is-invalid");

    if(!formData.leaveType) {
      leaveTypeRef.current.focus();
      leaveTypeRef.current.classList.add("is-invalid");
      toast.error("Please select leave type");
      return;
    }

    
    if(!formData.fromSession) {
      fromSessionReference.current.focus();
      fromSessionReference.current.classList.add("is-invalid");
      toast.error("Please select from session");
      return;
    }

    if(!formData.toSession) {
      toSessionReference.current.focus();
      toSessionReference.current.classList.add("is-invalid");
      toast.error("Please select to session");
      return;
    }

    if(!formData.fromDate) {
      fromDateRef.current.focus();
      fromDateRef.current.classList.add("is-invalid");
      toast.error("Please select from date");
      return;
    }

    if(!formData.toDate) {
      toDateRef.current.focus();
      toDateRef.current.classList.add("is-invalid");
      toast.error("Please select To date");
      return;
    }

    if(!formData.reason) {
      reasonRef.current.focus();
      reasonRef.current.classList.add("is-invalid");
      toast.error("Please type reason");
      return;
    }

    if(!getAllSelectedApps) {
      selectAppsReference.current.focus();
      selectAppsReference.current.classList.add("is-invalid");
      toast.error("Select Managers.");
      return;
    }

    const fromDate = event.target.fromDate.value;
    let toDate = event.target.toDate.value;
    if(toDate.length === 0) toDate = fromDate;

    const payload = new FormData();
    payload.append("EmpId", empId);
    payload.append("RoleName", "Employee");
    payload.append("LeaveType", formData.leaveType);
    payload.append("FromDate", formData.fromDate);
    payload.append(
      "ToDate",
      disableToDate ? formData.fromDate : formData.toDate
    );
    payload.append("leaveSession", leaveSession || null);
    payload.append("LeaveReason", formData.reason);
    // payload.append("managers", getAllSelectedApps);
    payload.append("fromSession", formData.fromSession);
    payload.append("toSession", formData.toSession);
    payload.append("applyTo", getAllSelectedApps);

    payload.append("CreatedBy", "HR");

    const newFromDate = new Date(formData.fromDate);
    const newToDate = new Date(formData.toDate);
    const differenceInMs = newToDate.getTime() - newFromDate.getTime();
    const differenceInDays = differenceInMs / (1000 * 60 * 60 * 24) + 1;
    {
      disableToDate
        ? payload.append("appliedDays", differenceInDays)
        : payload.append("appliedDays", 1);
    }
    // debugger
    if(attachment) {
      payload.append("attachments", attachment);
    }
    for(let [key, value] of payload.entries()) {
      // console.log("payload value: --> ", `${key}: ${value}`);
    }
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.API_URL}LeaveManagement/ApplyLeave`,
        payload,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      if(response.data.success == "True") {
        fetchLeaveData();
        setIsApply(false);
        resetForm();
        GetLeaveBalanceFromEmpid();
        setIsLoaderActive(false);

        toast.success("Leave applied successfully!");
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);


      }
    } catch(error) {
      console.error("Error applying for leave", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const exportToCSV = () => {
    let csvContent = "Leave Type,From,To,Reason,Status,HR Remarks\n";
    filteredEntries.forEach((entry) => {
      csvContent += `"${leavesTypeName[entry.leaveType] || "Unknown"}","${entry.fromDate.split("T")[0]}","${entry.toDate.split("T")[0]}","${entry.leaveReason}","${entry.leaveStatus}","${entry.hrRemarks || ''}"\n`;
    });
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "LeaveList.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredEntries.map((entry) => ({
        "Leave Type": leavesTypeName[entry.leaveType] || "Unknown",
        "From": entry.fromDate.split("T")[0],
        "To": entry.toDate.split("T")[0],
        "Reason": entry.leaveReason,
        "Status": entry.leaveStatus,
        "HR Remarks": entry.hrRemarks || "",
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Leaves");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "LeaveList.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Leave List", 14, 10);
    autoTable(doc, {
      head: [["Leave Type", "From", "To", "Reason", "Status", "HR Remarks"]],
      body: filteredEntries.map((entry) => [
        leavesTypeName[entry.leaveType] || "Unknown",
        entry.fromDate.split("T")[0],
        entry.toDate.split("T")[0],
        entry.leaveReason,
        entry.leaveStatus,
        entry.hrRemarks || "",
      ]),
    });
    doc.save("LeaveList.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Leave List</title></head><body>");
    printWindow.document.write("<h3>Leave List</h3>");
    printWindow.document.write("<table border='1' cellspacing='0' cellpadding='5'><thead><tr><th>Leave Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th>HR Remarks</th></tr></thead><tbody>");
    filteredEntries.forEach((entry) => {
      printWindow.document.write(`<tr><td>${leavesTypeName[entry.leaveType] || "Unknown"}</td><td>${entry.fromDate.split("T")[0]}</td><td>${entry.toDate.split("T")[0]}</td><td>${entry.leaveReason}</td><td>${entry.leaveStatus}</td><td>${entry.hrRemarks || ""}</td></tr>`);
    });
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };


  return (
    <>
      <div className="container-fluid p-3">
        <div class="row">
          <div class="col-sm-6">
            <h5 class="m-0">My Leaves</h5>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right bg-none p-0">
              <li class="breadcrumb-item">
                <a href="/employee-dashboard">Home</a>
              </li>
              <li class="breadcrumb-item active">My Leaves</li>
            </ol>
          </div>
        </div>
        <div className="container-fluid px-2">
          <div className="row mb-3 px-1">
            <div className="col-md-12 d-flex" style={{ marginLeft: "-15px" }}>
              <div class="col-md-4 left2 m-1">
                <div class="small-box2">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0">Total Assigned Leaves</h6>
                    </div>
                    <div
                      className="col-md-3 mb-0 count d-flex align-items-center justify-content-center"
                      style={{
                        height: "100px",
                        borderTopRightRadius: "10px",
                        borderBottomRightRadius: "10px",
                        borderLeft: "2px solid #FFFFFF",
                      }}
                    >
                      <span className="">{totalLeaves ? totalLeaves : 0}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4 left3 mx-2 my-1">
                <div class="small-box3">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0">Total Available Leaves</h6>
                    </div>
                    <div
                      className="col-md-3 count mb-0 d-flex align-items-center justify-content-center"
                      style={{
                        height: "100px",
                        borderTopRightRadius: "10px",
                        borderBottomRightRadius: "10px",
                        borderLeft: "2px solid #FFFFFF",
                      }}
                    >
                      <span className="ml-2">
                        {pendingLeaves ? pendingLeaves : 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4 left4 m-1">
                <div class="small-box4">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0 no-wrap">Total Leaves Taken</h6>
                    </div>
                    <div
                      className="col-md-3 count mb-0 d-flex align-items-center justify-content-center"
                      style={{
                        height: "100px",
                        borderTopRightRadius: "10px",
                        borderBottomRightRadius: "10px",
                        borderLeft: "2px solid #FFFFFF",
                      }}
                    >
                      <span className="ml-2">
                        {takenLeaves ? takenLeaves : 0}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid leavelist mb-2 text-center">
          <div className="row">
            {leaveEmpData.map((leave, index) => (
              !leave.isExpired && (
                <div className="col-md-2 m-1" key={index}>
                  <div
                    className={`col-md-12 py-1 leavelist`}
                    style={{
                      background:
                        leave.totalLeaves - leave.takenLeaves === 0
                          ? "linear-gradient(135deg, #feffb5, rgb(32 201 151 / 49%))"
                          : "linear-gradient(135deg, #fff, #85d5e2)",
                    }}
                  >
                    <label className="mb-0">
                      {leavesTypeNameForemp[leave.leaveType] || "Unknown Leave"} :{" "}
                      <span>
                        {leave.takenLeaves}/{leave.totalLeaves}
                      </span>
                    </label>
                  </div>
                </div>
              )
            ))}
          </div>
        </div>

        <div className="card card-outline card-primary">
          <div className="card-header">
            <h3 className="card-title text-sm">
              {isApply
                ? "Apply Leave"
                : `Leave Table ( ${leaveEntries.length} )`}

              {isApply ? (
                <span
                  hover-tooltip="This Apply for Leave feature allows employees to submit leave requests.
                 First, the employee must fill out all required fields marked with an asterisk (*) and 
                 can also select additional managers for approval. After submitting the leave request,
                  HR and the assigned manager can review and accept/reject the leave. 
                  Other managers will receive an email notification about the leave request. 
                  Once HR or the manager approves or rejects the leave,
                   the employee will be notified via email or the HR portal."
                  tooltip-position="bottom"
                >
                  <i
                    class="fas fa-info-circle ml-2"
                    style={{ color: "rgb(0 0 0 / 51%)" }}
                  ></i>
                </span>
              ) : (
                <span
                  hover-tooltip="This My Leave page allows employees to apply for leave. The top three cards display key leave information: the total assigned leaves, available leaves, and the total leaves taken. If available leaves are 0, the employee will not be able to apply for leave. This page also shows a summary of all current leave applications, including HR remarks (approved, rejected, or deleted by the employee), as well as previously applied leave data."
                  tooltip-position="bottom"
                >
                  <i
                    class="fas fa-info-circle ml-2"
                    style={{ color: "rgb(0 0 0 / 51%)" }}
                  ></i>
                </span>
              )}
            </h3>
            <div className="card-tools">
              {!isApply && (
                <button
                  className="btn btn-sm btn-primary ml-auto"
                  onClick={handleLeaveApplicationToggle}
                >
                  Apply For Leave
                </button>
              )}
              <button
                type="button"
                className="btn btn-tool"
                data-card-widget="maximize"
              >
                <i className="fas fa-expand"></i>
              </button>
            </div>
          </div>

          {isApply && (
            <div className="card-body">
              <div className="container mt-2">
                <form onSubmit={handleSubmit}>
                  <div className="mb-3 row">
                    <label className="col-sm-2 col-form-label">
                      Leave Type<sup style={{ color: "red" }}>*</sup>
                    </label>

                    <div className="col-sm-4">
                      <select
                        className="form-control form-control-sm col-sm-12"
                        name="leaveType"
                        value={formData.leaveType}
                        ref={leaveTypeRef}
                        onChange={handleLeaveTypeChange}
                      >
                        <option value="">-- Select Leave Type --</option>
                        {leavesType.map((leave, index) => (
                          <option key={leave.id} value={leave.id}>
                            {leave.leaveTypeName}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="mb-3 row">
                    <label className="col-sm-2 col-form-label">
                      From<sup style={{ color: "red" }}>*</sup>
                    </label>
                    <div className="col-sm-4">
                      <input
                        ref={fromDateRef}
                        type="date"
                        className="form-control form-control-sm"
                        name="fromDate"
                        min={
                          new Date(
                            new Date().setDate(new Date().getDate() - 15)
                          )
                            .toISOString()
                            .split("T")[0]
                        }
                        value={formData.fromDate}
                        onChange={handleDateChange}
                      />
                    </div>
                    <label className="col-sm-2 col-form-label text-sm-center text-start">
                      To<sup style={{ color: "red" }}>*</sup>
                    </label>

                    <div className="col-sm-4">
                      <input
                        ref={toDateRef}
                        type="date"
                        className="form-control form-control-sm"
                        name="toDate"
                        value={formData.toDate}
                        onChange={handleDateChange}
                        min={
                          formData.fromDate ||
                          formatDate(
                            new Date(
                              new Date().setDate(new Date().getDate() - 15)
                            )
                          )
                        }
                        disabled={disableToDate}
                      />
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-md-6">
                      <div className="mb-3 row">
                        <label className="col-sm-4 col-form-label">
                          From Session<sup style={{ color: "red" }}>*</sup>
                        </label>

                        <div className="col-sm-8">
                          <select
                            className="form-control form-control-sm col-sm-12"
                            name="fromSession"
                            value={formData.fromSession}
                            ref={fromSessionReference}
                            onChange={handleFromSessionChange}
                          >
                            <option value="">-- Select From Session --</option>
                            <option value="session1">session1</option>
                            <option value="session2">session2</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="col-md-6">
                      <div className="mb-3 row">
                        <label className="col-sm-4 col-form-label text-center">
                          To Session<sup style={{ color: "red" }}>*</sup>
                        </label>

                        <div className="col-sm-8">
                          {/* <select
                            className="form-control form-control-sm col-sm-12"
                            name="toSession"
                            value={((formData.fromDate == formData.toDate) && (formData.fromSession == "session2")) ? "session2" : formData.toSession}
                            ref={toSessionReference}
                            onChange={handleToSessionChange}
                          >
                            <option value="">-- Select To Session --</option>
                            <option value="session1">session1</option>
                            <option value="session2">session2</option>
                          </select> */}
                          <select
                            className="form-control form-control-sm col-sm-12"
                            name="toSession"
                            value={formData.toSession}
                            ref={toSessionReference}
                            onChange={handleToSessionChange}
                          >
                            <option value="">-- Select To Session --</option>
                            {formData.fromSession === "session2" ? (
                              <option value="session2">session2</option>
                            ) : (
                              <>
                                <option value="session1">session1</option>
                                <option value="session2">session2</option>
                              </>
                            )}
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-3 row">
                    <label className="col-sm-2 col-form-label">
                      Reason<sup style={{ color: "red" }}>*</sup>
                    </label>
                    <div className="col-sm-10">
                      <textarea
                        ref={reasonRef}
                        className="form-control form-control-sm"
                        rows="3"
                        name="reason"
                        value={formData.reason}
                        placeholder="Please enter reason"
                        onChange={(e) => {
                          setFormData({ ...formData, reason: e.target.value });
                          reasonRef.current.classList.remove("is-invalid");
                        }}
                      ></textarea>
                    </div>
                  </div>

                  <div className="mb-3 row">
                    <label className="col-sm-2 col-form-label">Apply To</label>
                    <div className="col-sm-3">
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        name="manager"
                        value={
                          managerName != ""
                            ? managerName || "No manager is assigned"
                            : null
                        }
                        disabled
                      />
                    </div>
                    <div className="col-sm-7">
                      <select
                        className="select2 w-100"
                        multiple="multiple"
                        data-placeholder="Select managers"
                        style={{ width: "100%" }}
                        ref={selectAppsReference}
                        value={appId}
                        onChange={(e) => setAppId(e.target.value)}
                      >
                        <option value="">--Select--</option>
                        {managers
                          .filter((app) => app.userID != manager)
                          .map((app) => {
                            return (
                              <option
                                key={"Mana_" + app.userID}
                                value={app.userID}
                              >
                                {app.userName}
                              </option>
                            );
                          })}
                      </select>
                    </div>
                  </div>

                  <div className="mb-3 row">
                    <label className="col-sm-2 col-form-label">
                      Attachments
                    </label>
                    <div className="col-sm-5">
                      <div className="row px-2">
                        <div className="custom-file col-md-10 position-relative">
                          <input
                            type="file"
                            ref={attachmentRef}
                            className="custom-file-input"
                            id="fileUpload"
                            onChange={handleFileChange}
                          />
                          <label
                            className="custom-file-label d-flex align-items-center justify-content-between"
                            htmlFor="fileUpload"
                          >
                            <span>
                              {attachment ? attachment.name : "Choose file"}
                            </span>
                          </label>
                          {attachment && (
                            <button
                              type="button"
                              className="btn btn-xs btn-danger position-absolute px-1"
                              style={{
                                top: "40%",
                                left: "75%",
                                transform: "translateY(-50%)",
                                fontSize: "18px",
                                cursor: "pointer",
                                zIndex: 2,
                              }}
                              onClick={handleRemoveFile}
                            >
                              <i className="fas fa-trash" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="d-flex justify-content-end">
                    <button
                      type="button"
                      className="btn btn-sm btn-secondary me-3 mr-3"
                      onClick={handleChange}
                    >
                      Cancel
                    </button>
                    {isLoaderActive ? (
                      <PleaseWaitButton className="btn-sm font-weight-medium auth-form-btn" />
                    ) : (
                      <button type="submit" className="btn btn-sm btn-primary">
                        Submit
                      </button>
                    )}
                  </div>
                </form>
              </div>
            </div>
          )}

          {!isApply && (
            <div className="card-body position-relative">
              <div className="d-flex justify-content-between mb-2">
                <div>
                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                  <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                </div>
                <input
                  type="text"
                  className="form-control form-control-sm w-25"
                  placeholder="Search by Leave Type..."
                  onChange={(e) => {
                    setSearchText(e.target.value);
                    setCurrentPage(1);
                  }}
                />
              </div>

              <table
                className="table table-bordered table-striped table-sm"
              >
                {/* {isLoaderActive && (
                  <div className="overlay dark">
                    <i className="fas fa-3x fa-sync-alt"></i>
                  </div>
                )} */}

                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <thead>
                  <tr>
                    <th>Sr.No.</th>
                    <th>Leave Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Attachments</th>
                    <th>HR Remarks</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {currentRows.length > 0
                    ? currentRows.filter((entry) => entry.leaveStatus !== "Deleted")
                      .map((entry, index) => (
                        <tr
                          key={entry.id}
                        >
                          <td>{index + 1}</td>
                          <td>
                            {leavesTypeName[entry.leaveType] || "Unknown Type"}
                          </td>
                          <td>
                            {(entry.fromDate)
                              .split("T")[0]}
                          </td>
                          <td>
                            {(entry.toDate)
                              .split("T")[0]}
                          </td>

                          <td
                            style={{
                              wordWrap: "break-word",
                              overflowWrap: "break-word",
                              whiteSpace: "normal",
                              maxWidth: "200px",
                            }}
                          >
                            {entry.leaveReason}
                          </td>
                          <td>
                            <span
                              className={
                                entry.leaveStatus === "Pending"
                                  ? "badge rounded-pill bg-warning text-light"
                                  : entry.leaveStatus === "Approved"
                                    ? "badge rounded-pill bg-success text-light"
                                    : entry.leaveStatus === "Rejected"
                                      ? "badge rounded-pill bg-danger"
                                      : "badge rounded-pill bg-succes"
                              }
                            >
                              {entry.leaveStatus == "Deleted"
                                ? "Canceled"
                                : entry.leaveStatus}
                            </span>
                          </td>
                          <td
                            style={{
                              fontWeight: "400",
                              fontSize: "smaller",
                            }}
                            className="text-center"
                          >
                            {entry.attachmentFileServerpath ? (
                              <div className="">
                                <a
                                  href={entry.attachmentFileServerpath}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                >
                                  <i
                                    className="fa fa-eye mr-2"
                                    aria-hidden="true"
                                  ></i>
                                  <strong>View</strong>
                                </a>
                              </div>
                            ) : (
                              "No attachment"
                            )}
                          </td>
                          <td
                            style={{
                              wordWrap: "break-word",
                              overflowWrap: "break-word",
                              whiteSpace: "normal",
                              maxWidth: "200px",
                            }}
                          >
                            {entry.hrRemarks || null}
                          </td>

                          <td className="d-flex justify-content-center">
                            {entry.leaveStatus === "Pending" ? (
                              <button
                                className={`btn btn-outline-danger btn-sm cursor-pointer`}
                                onClick={
                                  entry.leaveStatus !== "Deleted"
                                    ? () => handleDelete(entry)
                                    : () => {
                                      toast.error("Leave already deleted");
                                    }
                                }
                              >
                                <i className="fas fa-trash-alt"></i>
                              </button>
                            ): null}
                          </td>
                        </tr>
                      )) : (
                      <tr>
                        <td colSpan="9" className="text-center">No leave records found.</td>
                      </tr>
                    )}
                </tbody>
              </table>
              <div className="d-flex justify-content-between mt-2">
                <div>
                  Showing {startEntry} to {endEntry} of {filteredEntries.length} entries
                </div>
                <div>
                  <button
                    className="btn btn-xs btn-outline-primary"
                    onClick={() => handlePageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                  >
                    <i className="fas fa-angle-double-left"></i>
                  </button>
                  <span className="mx-2">Page {currentPage} of {totalPages}</span>
                  <button
                    className="btn btn-xs btn-outline-primary"
                    onClick={() => handlePageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                  >
                    <i className="fas fa-angle-double-right"></i>
                  </button>
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}
