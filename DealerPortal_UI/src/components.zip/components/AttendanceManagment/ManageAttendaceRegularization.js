import React, { useEffect, useState, useRef } from "react";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import axios from "axios";
import config from "../../config/config.json";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate, Link } from "react-router-dom";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


import "./ManageAttendaceRegularization.css";

function ManageAttendaceRegularization() {
  const [allUsersList, setAllUsersList] = useState([]);
  const [leaveType, setLeaveType] = useState([]);
  const [employees, setEmployees] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedRegularizeId, setSelectedRegularizeId] = useState(null);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const navigate = useNavigate();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;

  const rejectTextFieldRef = useRef(null);


  useEffect(() => {
    GetAllEmployees();
    fetchAllLeavesData();
    window.initDataTable();
    GetRoles();
  }, []);

  const GetAllEmployees = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}AuthMaster/GetAllEmpInfo`
      );

      const appsArray = response.data.data;
      const filteredAppsArray = appsArray.filter((app) => !app.isDelete);
      // console.log("all employee-->", appsArray);
      setEmployees(filteredAppsArray);
      setTimeout(() => {
        window.initDataTable();
      }, 500);
    } catch(error) {
      console.error("Error fetching employees:", error);
      toast.error("Error fetching employees");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const fetchAllLeavesData = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}EmployeeAttendenceCheck/GetAllAttendanceRegularization`
      );

      if(response.data.success == "True") {
        // console.log("response --- >", response.data.data);
        setAllUsersList(response.data.data.result || []);
        setTimeout(() => {
          window.initDataTable();
        }, 500);
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      console.error("Error fetching leave data", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetRoles = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveType/GetAllLeaveTypes`
      );
      const appsArray = response.data.data || [];
      setLeaveType(appsArray);
    } catch(error) {
      console.error("Error fetching LeaveTypes:", error);
      toast.error("Error fetching LeaveTypes");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const leaveTypes = selectedUser
    ? leaveType.find((type) => type.id == selectedUser.leaveType)
    : null;
  const leaveTypeName = leaveTypes ? leaveTypes.leaveTypeName : "Unknown";

  const handleViewUserDetails = (userObj) => {
    // console.log("userObj--->", userObj);
    window.initDestroyDataTableFuncation();
    setTimeout(() => {
      setSelectedRegularizeId(userObj.id);
      setSelectedUser(userObj);
      setIsModalVisible(true);
    }, 500);
    setTimeout(() => {
      window.initAgainDestroyDataTableFuncation();
    }, 500);
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
    setSelectedUser(null);
    fetchAllLeavesData();
  };

  const handleOpenRejectModal = () => {
    setIsRejectModalVisible(true);
  };

  const handleCloseRejectModal = () => {
    setRejectReason("");
    setIsRejectModalVisible(false);
  };

  const handleAcceptLeave = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeAttendenceCheck/AcceptAttendanceRegularization`,
        {
          attendanceId: String(selectedUser.id),
          empId: selectedUser.empId,
          attendanceDate: selectedUser.attendanceDate,
          inTime: selectedUser.inTime,
          outTime: selectedUser.outTime,
          workLocation: selectedUser.workLocation,
          remark: selectedUser.remark,
          modifiedBy: personalInfo.userID,
        }
      );

      if(response.data.success === "True") {
        toast.success("Regularization Approved!");
        fetchAllLeavesData();
        handleCloseModal();
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch(error) {
      console.error("Error approving regularization:", error);
      toast.error("Failed to approve regularization!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handlRejectLeave = async (remark) => {
    if(!remark) {
      toast.error("Please provide a reason for rejection.");
      return;
    }

    setIsLoaderActive(true);

    try {
      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeAttendenceCheck/RejectAttendanceRegularization`,
        {
          attendanceId: String(selectedUser.id),
          empId: selectedUser.empId,
          attendanceDate: selectedUser.attendanceDate,
          inTime: selectedUser.inTime,
          outTime: selectedUser.outTime,
          workLocation: selectedUser.workLocation,
          remark: remark,
          modifiedBy: personalInfo.userID,
        }
      );

      if(response.data.success === "True") {
        toast.success("Regularization Rejected!");
        setIsRejectModalVisible(false);
        fetchAllLeavesData();
        setRejectReason("");
        handleCloseModal();
        return true;
      } else {
        toast.error(response.data.message);
        return false;
      }
    } catch(error) {
      console.error("Error rejecting regularization:", error);
      toast.error("Failed to reject regularization!");
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };


  const filteredUsers = allUsersList.filter((entry) =>
    (entry.remark || "").toLowerCase().includes(searchText.toLowerCase()) ||
    (entry.workLocation || "").toLowerCase().includes(searchText.toLowerCase()) ||
    (entry.attendanceDate || "").toLowerCase().includes(searchText.toLowerCase())
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredUsers.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredUsers.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, filteredUsers.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const exportToCSV = () => {
    let csvContent = "Employee Name,Date of Regularization,In Time,Out Time,Work Location,Remark,Status\n";
    filteredUsers.forEach((entry) => {
      const emp = employees.find((e) => e.empId === entry.empId);
      const empName = emp ? `${emp.firstName} ${emp.lastName}` : "N/A";
      csvContent += `"${empName}","${entry.attendanceDate}","${entry.inTime}","${entry.outTime}","${entry.workLocation}","${entry.remark}","${entry.regularizationStatus}"\n`;
    });
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "ManageAttendanceRegularization.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredUsers.map((entry) => {
        const emp = employees.find((e) => e.empId === entry.empId);
        const empName = emp ? `${emp.firstName} ${emp.lastName}` : "N/A";
        return {
          "Employee Name": empName,
          "Date of Regularization": entry.attendanceDate,
          "In Time": entry.inTime,
          "Out Time": entry.outTime,
          "Work Location": entry.workLocation,
          "Remark": entry.remark,
          "Status": entry.regularizationStatus,
        };
      })
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Attendance");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "ManageAttendanceRegularization.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Attendance Regularization", 14, 10);
    autoTable(doc, {
      head: [["Employee Name", "Date of Regularization", "In Time", "Out Time", "Work Location", "Remark", "Status"]],
      body: filteredUsers.map((entry) => {
        const emp = employees.find((e) => e.empId === entry.empId);
        const empName = emp ? `${emp.firstName} ${emp.lastName}` : "N/A";
        return [
          empName,
          entry.attendanceDate,
          entry.inTime,
          entry.outTime,
          entry.workLocation,
          entry.remark,
          entry.regularizationStatus,
        ];
      }),
    });
    doc.save("ManageAttendanceRegularization.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Attendance</title></head><body>");
    printWindow.document.write("<h3>Attendance Regularization List</h3>");
    printWindow.document.write("<table border='1' cellspacing='0' cellpadding='5'><thead><tr><th>Employee Name</th><th>Date of Regularization</th><th>In Time</th><th>Out Time</th><th>Work Location</th><th>Remark</th><th>Status</th></tr></thead><tbody>");
    filteredUsers.forEach((entry) => {
      const emp = employees.find((e) => e.empId === entry.empId);
      const empName = emp ? `${emp.firstName} ${emp.lastName}` : "N/A";
      printWindow.document.write(`<tr><td>${empName}</td><td>${entry.attendanceDate}</td><td>${entry.inTime}</td><td>${entry.outTime}</td><td>${entry.workLocation}</td><td>${entry.remark}</td><td>${entry.regularizationStatus}</td></tr>`);
    });
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };


  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              {!selectedUser && (
                <h5 className="m-0">
                  Manage Employee Attendace Regularization
                </h5>
              )}
              {selectedUser && (
                <h5 className="m-0">
                  Manage Attendace Regularization{" "}
                  <span
                    hover-tooltip="Here you can view the leave statistics such as total assigned leaves, available leaves, and taken leaves of the employee. Along with the leave request details below."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h5>
              )}
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Manage Attendace Regularization{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>



      <div className="container-fluid px-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card card-primary card-outline">
              <div className="card-header">
                {!selectedUser && (
                  <h3 className="card-title text-sm">
                    Attendace Regularization{" "}
                    <span
                      hover-tooltip="In this page you can see the request for attendace regularization"
                      tooltip-position="bottom"
                    >
                      <i
                        class="fas fa-info-circle"
                        style={{
                          marginLeft: "5px",
                          cursor: "pointer",
                          color: "rgb(0 0 0 / 51%)",
                        }}
                      ></i>
                    </span>
                  </h3>
                )}
                {selectedUser && (
                  <h3 className="card-title text-sm">
                    Regularization Details{" "}
                    <span
                      hover-tooltip="In this page you can see the details request for regularization and you can accept or reject the request."
                      tooltip-position="bottom"
                    >
                      <i
                        class="fas fa-info-circle"
                        style={{
                          marginLeft: "5px",
                          cursor: "pointer",
                          color: "rgb(0 0 0 / 51%)",
                        }}
                      ></i>
                    </span>
                  </h3>
                )}
                <div className="card-tools">
                  <button
                    type="button"
                    className="btn btn-tool"
                    data-card-widget="maximize"
                  >
                    <i className="fas fa-expand"></i>
                  </button>
                </div>
              </div>
              <div className="card-body mainBody position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                {!selectedUser ? (
                  <>
                    <div className="d-flex justify-content-between mb-2">
                      <div>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                      </div>
                      <input
                        type="text"
                        className="form-control form-control-sm w-25"
                        placeholder="Search..."
                        onChange={(e) => {
                          setSearchText(e.target.value);
                          setCurrentPage(1);
                        }}
                      />
                    </div>

                    <table
                      className="table table-bordered table-sm table-striped tableBody"
                    >
                      <thead>
                        <tr>
                          <th
                            style={{ fontWeight: "500", fontSize: "smaller" }}
                            className="text-center"
                          >
                            Sr. No.
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Employee Name
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Date to regularize
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            In Time
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Out Time
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Work Location
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Remark
                          </th>

                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Regularization Status
                          </th>
                          <th
                            style={{
                              fontWeight: "500",
                              fontSize: "smaller",
                              width: "7%",
                            }}
                          >
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentRows.length > 0
                          ? currentRows.map((userObj, index) => {
                            return (
                              <tr>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                  className="text-center text-sm"
                                >
                                  {index + 1}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.empId
                                    ? employees.find(
                                      (e) => e.empId === userObj.empId
                                    )
                                      ? `${employees.find(
                                        (e) => e.empId === userObj.empId
                                      ).firstName
                                      } ${employees.find(
                                        (e) => e.empId === userObj.empId
                                      ).lastName
                                      }`
                                      : null
                                    : null}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.attendanceDate || "N/A"}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.inTime || "N/A"}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.outTime || "N/A"}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.workLocation || "N/A"}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                >
                                  {userObj.remark || "N/A"}
                                </td>
                                <td>
                                  <span
                                    className={
                                      userObj.regularizationStatus === "Pending"
                                        ? "badge rounded-pill bg-warning text-light"
                                        : userObj.regularizationStatus ===
                                          "Approved"
                                          ? "badge rounded-pill bg-success text-light"
                                          : userObj.regularizationStatus ===
                                            "Deleted"
                                            ? "badge rounded-pill bg-danger"
                                            : "badge rounded-pill bg-succes"
                                    }
                                  >
                                    {userObj.regularizationStatus == "Deleted"
                                      ? "Canceled"
                                      : userObj.regularizationStatus}
                                  </span>
                                </td>

                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                  }}
                                  className="text-center text-sm"
                                >
                                  {
                                    <button
                                      type="button"
                                      className="btn btn-primary btn-xs"
                                      onClick={() =>
                                        handleViewUserDetails(userObj)
                                      }
                                      style={{
                                        padding: "5px",
                                        fontSize: ".75rem",
                                        lineHeight: "0",
                                        borderRadius: ".15rem",
                                      }}
                                    >
                                      <i
                                        className="fas fa-eye"
                                        style={{ fontSize: "smaller" }}
                                      ></i>
                                    </button>
                                  }
                                </td>
                              </tr>
                            );
                          })
                          : ""}
                      </tbody>
                    </table>
                    <div className="d-flex justify-content-between mt-2">
                      <div>
                        Showing {startEntry} to {endEntry} of {filteredUsers.length} entries
                      </div>
                      <div>
                        <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                          <i className="fas fa-angle-double-left"></i>
                        </button>
                        <span className="mx-2">Page {currentPage} of {totalPages}</span>
                        <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                          <i className="fas fa-angle-double-right"></i>
                        </button>
                      </div>
                    </div>

                  </>
                ) : (
                  <div className="modal-content">
                    <div className="mb-3">
                      {selectedUser && (
                        <div>
                          <div className="row">
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">
                                  Date to regularize
                                </label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.attendanceDate}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">In Time</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.inTime}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">Out Time</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.outTime}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4 reasonText">
                              <div className="form-group">
                                <label className="pr-2">Work Location</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.workLocation}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4 reasonText">
                              <div className="form-group">
                                <label className="pr-2">Remark</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.remark}
                                  readOnly
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={handleCloseModal}
                      >
                        Close
                      </button>
                      {selectedUser.leaveStatus !== "Approved" &&
                        selectedUser.leaveStatus !== "Rejected" ? (
                        <>
                          {!isLoaderActive && (
                            <button
                              className="btn btn-warning float-right btn-sm"
                              onClick={handleOpenRejectModal}
                            >
                              Reject
                            </button>
                          )}

                          {isLoaderActive ? (
                            <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                          ) : (
                            <button
                              className="btn btn-primary float-right btn-sm mr-2"
                              onClick={handleAcceptLeave}
                            >
                              Accept
                            </button>
                          )}
                        </>
                      ) : null}
                    </div>
                  </div>
                )}
                {isRejectModalVisible && (
                  <div className="modal-overlay rejectModal">
                    <div className="modal-dialog ">
                      <div className="modal-content ">
                        <div className="modal-header ">
                          <h5 className="modal-title ">Reject Leave <sup style={{ color: "red" }}>*</sup> </h5>
                          <button
                            type="button"
                            className="close"
                            onClick={handleCloseRejectModal}
                          >
                            &times;
                          </button>
                        </div>
                        <div className="modal-body ">
                          <p>
                            Are you sure you want to reject the leave request
                            for <strong>{selectedUser?.userName}</strong>?
                          </p>
                          <textarea
                            placeholder="Give your reason"
                            className="w-100 form-control"
                            ref={rejectTextFieldRef}
                            value={rejectReason} // Bind the state
                            onChange={(e) => setRejectReason(e.target.value)} // Update state on change
                          ></textarea>
                        </div>
                        <div className="modal-footer">
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={handleCloseRejectModal}
                          >
                            Cancel
                          </button>
                          {isLoaderActive ? (
                            <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                          ) : (
                            <button
                              className="btn btn-danger btn-sm "
                              onClick={() => {
                                handlRejectLeave(rejectReason);
                              }}
                            >
                              Reject
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}

export default ManageAttendaceRegularization;
