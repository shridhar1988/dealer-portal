import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";

function UserAttendance() {
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());

  useEffect(() => {
    window.onCalendarDateChange = (newMonth, newYear) => {
      const adjustedMonth = (newMonth % 12) + 1;
      setCurrentMonth(adjustedMonth);
      const adjustedYear = newMonth == 12 ? newYear + 1 : newYear;
      setCurrentYear(adjustedYear);
    };
    window.initAttendanceCalender();
    GetAttendance(currentMonth, currentYear);
  }, []);

  useEffect(() => {
    GetAttendance(currentMonth, currentYear);
  }, [currentMonth, currentYear]);

  const formatDateForSelector = (date) => {
    const [day, month, year] = date.split("-");
    return `${year}-${month}-${day}`;
  };
  const handleAttendaceRegularize = () => {
    <Link to="/attendace-regularization"></Link>;
  };

  const GetAttendance = async (month, year) => {
    
    const loggedUserId = localStorage.getItem("loggedUserId");
    const formattedMonth = month.toString().padStart(2, "0");
    const adjustedYear = month === 12 ? year + 1 : year;
    // console.log("Month:", formattedMonth, "Year:", adjustedYear);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/EmployeeAttendenceCheck/GetAllandanceStatusByUserIdAndDate?UserId=${loggedUserId}&month=${formattedMonth}&year=${adjustedYear}`
      );
      const appsArray = response.data.data || [];
      // console.log("appsArray ===> ", appsArray);

      appsArray.forEach((attendance) => {
        const formattedDate = formatDateForSelector(attendance.date);
        // console.log("Formatted Date ===> ", formattedDate);

        const dayElement = document.querySelector(
          `[data-date="${formattedDate}"]`
        );
        // console.log("dayElement ===> ", dayElement);

        if (dayElement) {
          switch (attendance.attendaceStatus) {
            case "Present":
              dayElement.style.backgroundColor = "rgb(10 255 74 / 21%)";
              break;
            case "Absent":
              dayElement.style.backgroundColor = "rgb(255 16 0 / 20%)";
              break;
            case "Half Day":
              dayElement.style.backgroundColor = "rgb(255 154 0 / 26%)";
              break;
            default:
              dayElement.style.backgroundColor = "";
          }
        }
      });
    } catch (error) {
      console.error("Error fetching attendance status:", error);
      toast.error("Error fetching attendance status");
    }
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-6">
              <h1 className="m-0">Attendance</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/employee-dashboard">Home</Link>
                </li>
                <li className="breadcrumb-item">
                  <Link to="/employee-dashboard">Employee Dashboard</Link>
                </li>
                <li className="breadcrumb-item active">Attendance</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid px-3">
        <div className="card card-primary card-outline">
          <div className="card-header px-2">
            <button
              className="btn btn-xs mr-2"
              style={{
                backgroundColor: "rgb(10 255 74 / 21%)",
                border: "1px solid rgb(10 255 74 / 80%)",
              }}
            >
              <strong>Present</strong>
            </button>
            <button
              className="btn btn-xs mr-2"
              style={{
                backgroundColor: "rgb(255 16 0 / 20%)",
                border: "1px solid rgb(255 16 0 / 80%)",
              }}
            >
              <strong>Leave</strong>
            </button>
            <button
              className="btn btn-xs mr-2"
              style={{
                backgroundColor: "rgb(255 154 0 / 26%)",
                border: "1px solid rgb(255 154 0 / 80%)",
              }}
            >
              <strong>Half Day</strong>
            </button>
            <button
              className="btn btn-xs mr-2"
              style={{
                backgroundColor: "rgb(255, 220, 40 , 0.15)",
                border: "1px solid rgb(255, 220, 40 , 0.80)",
              }}
            >
              <strong>Current Day</strong>
            </button>

            <Link
              className="ml-auto float-right"
              to="/attendace-regularization"
            >
              Regularize Attendance
            </Link>
          </div>
          <div className="card-body p-0">
            <div id="calendar"></div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}
export default UserAttendance;
