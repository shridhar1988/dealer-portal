import React, { useEffect, useState, useRef } from "react";
import { useSelector } from "react-redux";
import axios from "axios";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import "./AttendanceManagment.css";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import $ from "jquery";
import PleaseWaitButton from "../../shared/PleaseWaitButton";

const AttendanceManagment = () => {
  const [attendanceData, setAttendanceData] = useState([]);
  const [file, setFile] = useState(null);
  const [fileName, setFileName] = useState("");
  const [selectedDate, setSelectedDate] = useState("");

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const [departments, setDepartments] = useState([]);
  const [departmentsAttandanceArray, setDepartmentsAttandanceArray] = useState([]);
  const [showModal_second, setShowModal_second] = useState(false);
  const [department, setDepartment] = useState("");
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [attandanceDate, setAttandanceDate] = useState("");
  const [selectedMonth, setSelectedMonth] = useState(currentMonth);
  const [hideOrdisplaySection, setHideOrdisplaySection] = useState(false);

  useEffect(() => {
    window.initDatePickerAttandanceFuncation();
    window
      .$("#attandanceDateV")
      .on("change.datetimepicker", ({ date, oldDate }) => {
        GetDepartmentsAttandanceWise();
      });
    window.initDatePickerBulkUploadAttendanceFuncation = () => {
      $("#attandanceBulkUploadDate").datetimepicker({
        format: "L",
      });
    };
    GetDepartmentsAttandanceWise();
  }, []);

  const fileInputRef = useRef(null);

  const handleButtonClick = () => {
    fileInputRef.current.click();
  };

  const handleDateChange = (event) => {
    setSelectedDate(event.target.value);
  };

  const handleFileChange = (event) => {
    const selectedFile = event.target.files[0];
  
    if (selectedFile) {
      const isXlsx = selectedFile.name.endsWith('.xlsx') &&
                     selectedFile.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  
      if (!isXlsx) {
        toast.error("Only .xlsx files are allowed.");
        event.target.value = null; // reset the input
        return;
      }
  
      setFile(selectedFile);
      setFileName(selectedFile.name);
    }
  };
  

  const GetDepartmentsAttandanceWise = async () => {
    setIsLoaderActive(true);

    try {
      let getAttandanceDate =
        attandanceDate != ""
          ? attandanceDate
          : window.$("#attandanceDateV").val();
      setAttandanceDate(getAttandanceDate);
      const response = await axios.post(
        config.apiEndPoint +
        "/EmployeeAttendenceCheck/GetAllDepartmentsWithAttandanceStatus",
        {
          date: getAttandanceDate,
        }
      );
      const appsArray = response.data.data || [];
      
      setDepartmentsAttandanceArray(appsArray);
      GetDepartments();
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetDepartments = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}Department/GetAllDepartments`
      );
      const appsArray = response.data.data || [];
      setDepartments(appsArray);
      
    } catch (error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const parseTimeTo24Hour = (time) => {
    const [timePart, modifier] = time.split(" "); // Split into time and AM/PM
    let [hours, minutes] = timePart.split(":").map((num) => parseInt(num));

    if (modifier === "PM" && hours !== 12) {
      hours += 12; // Convert PM times to 24-hour format (except for 12 PM)
    } else if (modifier === "AM" && hours === 12) {
      hours = 0; // Convert 12 AM to 00:xx
    }

    return new Date(1970, 0, 1, hours, minutes); // Use a fixed date
  };

  const calculateWorkingHours = (startTime, endTime) => {
    const startDate = parseTimeTo24Hour(startTime);
    const endDate = parseTimeTo24Hour(endTime);

    // Get the difference in milliseconds
    const difference = endDate - startDate;

    // Convert milliseconds to hours
    const workingHours = difference / (1000 * 60 * 60);

    return workingHours;
  };

  const departmentChangeHandler = async (getDepartmentId) => {
    setIsLoaderActive(true);

    setDepartment(getDepartmentId);
    window.initDestroyDataTableFuncation();
    let getAttandanceDate = window.$("#attandanceDateV").val();
    setAttandanceDate(getAttandanceDate);
    const response = await axios.post(
      config.apiEndPoint +
      "/EmployeeAttendenceCheck/GetEmployeebyDateAndDepartmentId",
      {
        department: getDepartmentId,
        date: getAttandanceDate,
      }
    );
    
    if (response.data.success === "True") {
      
      setAttendanceData(response.data.data);
      setHideOrdisplaySection(true);
      setTimeout(() => {
        window.initAgainDestroyDataTableFuncation();
      }, 1000);
      //return response.data.data.jsonData;
    } else {
      setAttendanceData([]);
      setTimeout(() => {
        window.initAgainDestroyDataTableFuncation();
      }, 1000);
      setIsLoaderActive(false);
      toast.error("No data found");
      return false;
    }
    setIsLoaderActive(false);
  };

  const handleDepartmentSelection = (departmentId) => {
    setSelectedDepartment(departmentId); // Update selected department
    
  };

  const departmentChangeHandlerForExcel = async () => {
    setIsLoaderActive(true);
    try {
      const getAttendenceDate = window.$("#attandanceDateV").val();
      const getDepartmentId = selectedDepartment;

      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeAttendenceCheck/GetEmployeebyDateAndDepartmentId`,
        {
          department: getDepartmentId,
          date: getAttendenceDate,
        }
      );

      if (response.data.success !== "True") {
        console.warn("API call was not successful:", response.data.message);
        setIsLoaderActive(false);

        return;
      }

      const responseData = response.data?.data || [];

      if (Array.isArray(responseData) && responseData.length > 0) {
        // Fetch department name from API or use a mapping
        const departmentNameResponse = await axios.get(
          `${config.apiEndPoint}/Department/GetDepartmentOfId/${getDepartmentId}`
        );

        const departmentName =
          departmentNameResponse.data?.data?.departmentName ||
          "Unknown Department";

        // Create a new workbook and worksheet
        const workbook = new ExcelJS.Workbook();
        const sheet = workbook.addWorksheet("AttendanceData");

        // Add headers and data
        const headers = Object.keys(responseData[0]);
        sheet.addRow(headers);

        // Replace department ID with department name in the response data
        responseData.forEach((data, index) => {
          data.departmentName = departmentName; // Add department name to data
          sheet.addRow(Object.values(data));
          sheet.getCell(`G${index + 2}`).value = departmentName; // Add department name in column G (starting from row 2)
        });

        // Apply data validation
        for (
          let rowIndex = 2;
          rowIndex <= 2 + responseData.length - 1;
          rowIndex++
        ) {
          sheet.getCell(`C${rowIndex}`).dataValidation = {
            type: "list",
            allowBlank: true,
            formulae: [
              `"9:00 AM,9:30 AM,10:00 AM,10:30 AM,11:00 AM,11:30 AM,12:00 PM,12:30 PM,1:00 PM,1:30 PM,2:00 PM,2:30 PM,3:00 PM,3:30 PM,4:00 PM,4:30 PM,5:00 PM,5:30 PM,6:00 PM"`,
            ],
            showInputMessage: true,
            promptTitle: "Valid In-Time",
            prompt:
              "Please select a valid In-Time (between 9:00 AM and 6:00 PM).",
          };

          sheet.getCell(`D${rowIndex}`).dataValidation = {
            type: "list",
            allowBlank: true,
            formulae: [
              `"9:00 AM,9:30 AM,10:00 AM,10:30 AM,11:00 AM,11:30 AM,12:00 PM,12:30 PM,1:00 PM,1:30 PM,2:00 PM,2:30 PM,3:00 PM,3:30 PM,4:00 PM,4:30 PM,5:00 PM,5:30 PM,6:00 PM"`,
            ],
            showInputMessage: true,
            promptTitle: "Valid Out-Time",
            prompt:
              "Please select a valid Out-Time (between 9:00 AM and 6:00 PM).",
          };

          sheet.getCell(`E${rowIndex}`).dataValidation = {
            type: "list",
            allowBlank: true,
            formulae: [`"Present,Absent,Half Day"`],
            showInputMessage: true,
            promptTitle: "Valid Attendance Status",
            prompt: "Please select a valid attendance status.",
          };
        }

        // Remove columns C, H, and I
        sheet.spliceColumns(3, 1); // Remove column C (3rd column)
        sheet.spliceColumns(7, 1); // Remove column H (now the 7th column after column C removal)
        sheet.spliceColumns(7, 1); // Remove column I (still the 7th column after previous removals)

        // Clear data in columns G and H (starting from row 2)
        for (
          let rowIndex = 2;
          rowIndex <= 2 + responseData.length - 1;
          rowIndex++
        ) {
          sheet.getCell(`G${rowIndex}`).value = null; // Clear column G data
          sheet.getCell(`H${rowIndex}`).value = null;
          sheet.getCell(`I${rowIndex}`).value = null; // Clear column H data
        }

        sheet.getCell("G1").value = null; // Clear column G data in row 1
        sheet.getCell("H1").value = null; // Clear column H data in row 1
        sheet.getCell("I1").value = null;

        // Save the file
        const fileName = `Attendance_${getAttendenceDate}_${getDepartmentId}.xlsx`;
        const buffer = await workbook.xlsx.writeBuffer();

        const blob = new Blob([buffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        saveAs(blob, fileName);
      } else {
        console.warn("No valid data received from API or data is empty.");
      }
    } catch (error) {
      console.error("Error generating Excel file:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const formatDateToDDMMYYYY = (date) => {
    const day = String(date.getDate()).padStart(2, '0'); // Ensure 2 digits for day
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed, so we add 1
    const year = date.getFullYear();

    return `${day}-${month}-${year}`;
  };

  const formattedDate = formatDateToDDMMYYYY(new Date(selectedDate));


  const attendencebulkupload = async () => {
    

    if (!file || !selectedDate) {
      toast.error("Please select a file and a date before submitting.");

      setIsLoaderActive(false);

      return;
    }

    const formatDateToDDMMYYYY = (date) => {
      const day = String(date.getDate()).padStart(2, '0'); // Ensure 2 digits for day
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed, so we add 1
      const year = date.getFullYear();

      return `${day}-${month}-${year}`;
    };

    const formattedDate = formatDateToDDMMYYYY(new Date(selectedDate));
    setIsLoaderActive(true);
    try {
      // Prepare FormData to send both file and date
      const data = new FormData();
      data.append("file", file); // Append file as a binary blob
      // data.append("date", formattedDate); // Ensure the date is appended as a string

      // Log the data to see if everything is correct before sending
      // console.log("FormData content:", formattedDate);

      // Send the request as multipart/form-data
      const response = await axios.post(
        `${config.apiEndPoint}/Attendance/upload-file?date=${formattedDate}`,
        data,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            ...config.header3,
          },
        }

      );

      // alert("File uploaded successfully!");
      // console.log(response.data);
      toast.success("Attendance uploaded successfully!");
      setShowModal_second(false);
    } catch (error) {
      // console.error("Error uploading file:", error);
      toast.error("Error Uploading Data")
      // alert("Failed to upload file. Please try again.");
    }finally{
      setIsLoaderActive(false);
    }
  };

  const generateTimeOptions = () => {
    const options = [];
    const startTime = new Date();
    startTime.setHours(9, 0, 0, 0); // Start at 9:00 AM
    const endTime = new Date();
    endTime.setHours(21, 0, 0, 0); // End at 9:00 PM

    while (startTime <= endTime) {
      let hours = startTime.getHours();
      let minutes = startTime.getMinutes();
      let ampm = hours >= 12 ? "PM" : "AM";

      if (hours > 12) hours -= 12; // Convert to 12-hour format
      if (hours === 0) hours = 12; // Handle 12:00 AM case

      const timeString = `${hours}:${minutes === 0 ? "00" : minutes} ${ampm}`;
      options.push(timeString);

      // Increase time by 15 minutes
      startTime.setMinutes(startTime.getMinutes() + 15);
    }

    return options;
  };

  const cancleAttandanceClickHandler = () => {
    setDepartment("");
    setTimeout(() => {
      setAttendanceData([]);
    }, 200);
    window.initDestroyDataTableFuncation();
    setHideOrdisplaySection(false);
    setTimeout(() => {
      window.initAgainDestroyDataTableFuncation();
      window.initDatePickerAttandanceFuncation();
    }, 1000);
  };

  const   inAndOutTimeChangeHandler = (
    getSelectedValue,
    drodwName,
    empId,
    getIndex
  ) => {
    // console.log("out value-->",getSelectedValue);
    let getExistingDataArray = attendanceData;
    if (drodwName == "intime") {
      getExistingDataArray.find((obj) => obj.empId == empId).inTime =
        getSelectedValue;
    } else {
      getExistingDataArray.find((obj) => obj.empId == empId).outTime =
        getSelectedValue;
    }
    let getSingleObject = getExistingDataArray.find(
      (obj) => obj.empId == empId
    );
    let calculatedWorkingHrs = calculateWorkingHours(
      getSingleObject.inTime,
      getSingleObject.outTime
    );
    setTimeout(() => {
      setAttendanceData(getExistingDataArray);
    }, 500);
    window
      .$("#tableTr" + getIndex)
      .find("td:eq(5)")
      .text(calculatedWorkingHrs + " Hours");
  };

  const attendanceStatusChangeHandler = (
    getSelectedValue,
    getEmpId,
    getIndex
  ) => {
    let getExistingDataArray = attendanceData;
    getExistingDataArray.find((obj) => obj.empId == getEmpId).attendanceStatus =
      getSelectedValue;
    if (getSelectedValue == "Present") {
      window
        .$("#tableTr" + getIndex)
        .find("td:eq(4)")
        .css("background", "#a5f4a5");
    } else if (getSelectedValue == "Absent") {
      window
        .$("#tableTr" + getIndex)
        .find("td:eq(4)")
        .css("background", "#f49999");

        inAndOutTimeChangeHandler(
          "9:30 AM",
          "outtime",
          getEmpId,
          getIndex
        )
        $("#tableTr" + getIndex)
        .find("td:eq(3) select")
        .val("9:30 AM");
      
    } else {
      window
        .$("#tableTr" + getIndex)
        .find("td:eq(4)")
        .css("background", "#f4cf8c");
    }
  };

  const saveOrUpdateAttandance = async () => {
    setIsLoaderActive(true);

    const response = await axios.post(
      config.apiEndPoint + "/EmployeeAttendenceCheck/AddEmployeesToAttendance",
      attendanceData
    );
    const returnData = response.data.data || [];
    if (response.data.success == "True") {
      // setHideOrdisplaySection(false);
      toast.success(response.data.message);
      setTimeout(() => {
        GetDepartmentsAttandanceWise();
        cancleAttandanceClickHandler();
        // window.initDatePickerAttandanceFuncation();
      }, 800);
      // setTimeout(() => {
      //   GetDepartmentsAttandanceWise();
      // }, 2500);
    }
    setIsLoaderActive(false);
   
  };

  const handleClose = (e) => {
    setShowModal_second(false);
  };

  return (
    <>
      <div className="container-fluid px-3 bg-body">
        <div className="content-header px-0">
          <div className="container-fluid px-0">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h5 className="m-0">
                  Manage Attendance{" "}
                  <span
                    hover-tooltip="This Attendance Management screen is used to track and 
                        manage employee attendance based on their department and the selected date. 
                        To use this feature, first, select the date and department. 
                        The system will then display all employees in the chosen department. 
                        You will need to enter the InTime and OutTime for each employee, along 
                        with their attendance status. The total working hours will be automatically 
                        calculated based on the in and out times. Once completed, save the attendance data. 
                        This process can be repeated for other departments as well."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle ml-2"
                      style={{ color: "rgb(0 0 0 / 51%)" }}
                    ></i>
                  </span>{" "}
                </h5>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/manage-employee">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">Manage Attendance </li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container-fluid px-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card card-outline card-primary">
              <div
                className="card-header"
                style={{ backgroundColor: "rgba(153, 198, 241, 0.39)" }}
              >
                <div className="row">
                  <div className="col-md-12">
                    <div className="row">
                      <div
                        className="button-container d-flex pl-2"
                        style={{ marginTop: "2px" }}
                      >
                        {departments.map((dept, index) => (
                          <button
                            key={index}
                            style={{ fontSize: ".775rem !important" }}
                            className={`btn  btn-xs mr-1 d-flex justify-content-center align-items-center ${selectedMonth == `${dept.departmentName}`
                              ? "selected"
                              : ""
                              } ${departmentsAttandanceArray.includes(
                                dept.departmentID
                              )
                                ? "activeDept"
                                : "activeDefaultDept"
                              }`}
                          // onClick={() => setSelectedMonth(`${month.departmentID}`)}
                          >
                            {dept.departmentName}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                className="card-header"
                style={{ backgroundColor: "rgb(233 233 233 / 39%)" }}
              >
                <div className="col-md-12">
                  <div className="row">
                    <div className="col-md-3">
                      <h3 className="card-title text-sm">
                        Attendance List ( {attendanceData.length} )
                      </h3>
                    </div>
                    {hideOrdisplaySection == true ? (
                      <div className="col-md-9">
                        <div className="row">
                          <div
                            className="float-left col-md-7 text-center"
                            style={{ fontSize: "x-small" }}
                          >
                            Department Name:{" "}
                            <b>
                              {department
                                ? departments.find(
                                  (e) => e.departmentID == department
                                ).departmentName
                                : department}
                            </b>
                            <br />
                            Attendance Date: <b>{attandanceDate}</b>
                          </div>
                          <div className="float-right col-md-5">
                            <div className="card-tools float-right ">
                              <button
                                type="button"
                                className="btn btn-tool"
                                data-card-widget="maximize"
                              >
                                <i className="fas fa-expand"></i>
                              </button>
                            </div>
                            <button
                              className="btn btn-sm float-right btn-default mr-1"
                              onClick={() => {
                                cancleAttandanceClickHandler();
                              }}
                              type="button"
                            >
                              Cancel
                            </button>
                            {isLoaderActive ? (
                              <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                            ) : (
                              <button
                                className="btn btn-sm float-right btn-primary mr-1"
                                onClick={() => {
                                  saveOrUpdateAttandance();
                                }}
                                type="button"
                              >
                                Save Attendance
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="col-md-9">
                        <div className="row float-right">
                          <div className="col-md-3">
                            <button
                              className="btn btn-sm btn-warning float-right mr-1"
                              onClick={() => setShowModal_second(true)}
                            >
                              Bulk Upload
                            </button>
                          </div>
                          <div className="col-md-3">
                            <div
                              className="input-group"
                              id="attandanceDate"
                              data-target-input="nearest"
                            >
                              <input
                                type="text"
                                className="form-control form-control-sm"
                                id="attandanceDateV"
                                placeholder="Select Date"
                                data-target="#attandanceDate"
                              />
                              <div
                                className="input-group-append"
                                custDatePicker
                                data-target="#attandanceDateV"
                                data-toggle="datetimepicker"
                              >
                                <div className="input-group-text">
                                  <i className="fa fa-calendar"></i>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="col-md-5">
                            <select
                              className="form-control form-control-sm"
                              id="userRoleNameInput"
                              defaultValue={department}
                              onChange={(e) =>
                                departmentChangeHandler(e.target.value)
                              }
                            >
                              <option value="" disabled>
                                Select Department
                              </option>
                              {departments.map((role) => (
                                <option
                                  key={role.departmentID}
                                  value={role.departmentID}
                                >
                                  {role.departmentName}
                                </option>
                              ))}
                            </select>
                          </div>
                          
                          <div className="card-tools">
                            <button
                              type="button"
                              className="btn btn-tool ml-3 pt-2"
                              data-card-widget="maximize"
                            >
                              <i className="fas fa-expand"></i>
                            </button>
                          </div>
                        </div>
                      </div>
                    )}
                    {showModal_second ? (
                      <>
                        <div
                          className="modal fade show"
                          id="modal-default"
                          style={{
                            display: "block",
                            paddingRight: "17px",
                            boxShadow: "#5d5858b",
                            backgroundColor: "#5d5858b8",
                          }}
                          aria-modal="true"
                          role="dialog"
                        >
                          <div className="modal-dialog" style={{ marginTop: '120px' }}>
                            <div className="modal-content">
                              {/* Modal Header */}
                              <div className="modal-header">
                                <h4 className="modal-title text-md">
                                  Attendance Bulk Upload{" "}
                                </h4>
                                <button
                                  type="button"
                                  className="close btn-secondary"
                                  data-dismiss="modal"
                                  aria-label="Close"
                                  onClick={() => {
                                    setShowModal_second(false);
                                    setSelectedDepartment("");
                                  }}
                                >
                                  <span aria-hidden="true">×</span>
                                </button>
                              </div>

                              {/* Modal Body */}
                              <div className="modal-body">
                                <h5>Step 1.<span
                                  hover-tooltip="In this select the department to dowload the sample excel sheet."
                                  tooltip-position="bottom"
                                >
                                  <i
                                    className="fas fa-info-circle ml-2"
                                    style={{ color: "rgb(0 0 0 / 51%)" }}
                                  ></i>
                                </span></h5>
                                <h6>Select department to download excel</h6>
                                <div className="row mt-3">
                                  <div className="col-md-6">
                                    <select
                                      className="form-control form-control-sm mb-2"
                                      id="userRoleNameInput"
                                      defaultValue=""
                                      onChange={(e) =>
                                        handleDepartmentSelection(e.target.value)
                                      }
                                    >
                                      <option value="" disabled>
                                        Select Department
                                      </option>
                                      {departments.map((role) => (
                                        <option
                                          key={role.departmentID}
                                          value={role.departmentID}
                                        >
                                          {role.departmentName}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                  <div className="col-md-6 float-right">
                                    {/* Conditionally Render the Button */}
                                    {selectedDepartment && (
                                      <>
                                        {isLoaderActive ? (
                                          <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                                        ) : (
                                          <a
                                            className="text-primary text-sm float-right pt-2"
                                            onClick={departmentChangeHandlerForExcel}
                                            style={{ cursor: "pointer" }}
                                          >
                                            Download Sample File
                                          </a>
                                        )}
                                      </>
                                    )}
                                  </div>
                                </div>

                                <hr />

                                <h5>Step 2.<span
                                  hover-tooltip="In this upload the changed attendence excel sheet with the date selected."
                                  tooltip-position="bottom"
                                >
                                  <i
                                    className="fas fa-info-circle ml-2"
                                    style={{ color: "rgb(0 0 0 / 51%)" }}
                                  ></i>
                                </span></h5>
                                <h6>Upload bulk attendence excel</h6>
                                <div className="row mt-3">
                                  <div className="col-md-6">
                                    <button
                                      className="btn-info btn-sm px-2"
                                      onClick={handleButtonClick}
                                      style={{ border: 'none' }}
                                    >
                                      <i className="fas fa-plus mr-2" />Upload File
                                    </button>
                                    {/* Hidden file input */}
                                    <input
                                      type="file"
                                      ref={fileInputRef}
                                      style={{ display: "none" }}
                                      accept=".xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                      onChange={handleFileChange}
                                    />
                                    {/* Display file name */}
                                    {fileName && (
                                      <p className="mt-2 text-primary text-xs mb-0">
                                        {fileName}
                                      </p>
                                    )}
                                  </div>
                                  <div className="col-md-6">
                                    {/* Date selector */}
                                    <div className="row">
                                      <div className="col-md-5 d-flex align-items-center">
                                        <label htmlFor="date">Select Date:</label>
                                      </div>
                                      <div className="col-md-7">
                                        <input
                                          type="date"
                                          id="date"
                                          className="form-control form-control-sm"
                                          value={selectedDate}
                                          onChange={handleDateChange}
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              {/* Modal Footer */}
                              <div className="modal-footer justify-content-between">
                                <button
                                  type="button"
                                  className="btn btn-secondary closebtn btn-sm"
                                  data-dismiss="modal"
                                  onClick={() => {
                                    handleClose();
                                    setSelectedDepartment("");
                                    setFileName("");
                                  }}
                                >
                                  Close
                                </button>
                                {isLoaderActive ? (
                                  <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                                ) : (
                                  <button
                                    className="btn btn-sm btn-primary float-right"
                                    onClick={attendencebulkupload}
                                  >
                                    Submit File
                                  </button>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </>
                    ) : null}
                  </div>
                </div>
              </div>

              <div className="card-body position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div id="listOfEmployees">
                  <table
                    id="example1"
                    className="table table-bordered table-sm"
                  >
                    <thead>
                      <tr>
                        <th width="7%" className="text-center">
                          Sr No
                        </th>
                        <th width="30%">Employee Name</th>
                        <th width="13%">In Time</th>
                        <th width="13%">Out Time</th>
                        <th width="15%">Attendance Status</th>
                        <th>Work Duration</th>
                      </tr>
                    </thead>
                    <tbody>
                      {attendanceData.map((data, index) => (
                        <tr
                          id={"tableTr" + index}
                          key={data.empId}
                          style={{
                            backgroundColor:
                              index % 2 === 0 ? "#f9f9f9" : "#e9ecef",
                          }}
                        >
                          <td className="text-center">{index + 1}</td>
                          <td>{data.empName.split(/(?=[A-Z])/).join(" ")}</td>
                          <td id={"inTime_" + index + 1}>
                            <select
                              className="form-control form-control-sm"
                              id={"inTimeDropdown_" + index + 1}
                              onChange={(e) =>
                                inAndOutTimeChangeHandler(
                                  e.target.value,
                                  "intime",
                                  data.empId,
                                  index
                                )
                              }
                            >
                              {generateTimeOptions().map((time, index) =>
                                data.inTime.toString() == time.toString() ? (
                                  <option key={index} value={time} selected>
                                    {time}
                                  </option>
                                ) : (
                                  <option key={index} value={time}>
                                    {time}
                                  </option>
                                )
                              )}
                            </select>
                          </td>
                          <td id={"outTime_" + index + 1}>
                            <select
                              className="form-control form-control-sm"
                              id={"outTimeDropdown_" + index + 1}
                              onChange={(e) =>
                                inAndOutTimeChangeHandler(
                                  e.target.value,
                                  "outtime",
                                  data.empId,
                                  index
                                )
                              }
                            >
                              {generateTimeOptions().map((time, index) =>
                                data.outTime.toString() == time.toString() ? (
                                  <option key={index} value={time} selected>
                                    {time}
                                  </option>
                                ) : (
                                  <option key={index} value={time}>
                                    {time}
                                  </option>
                                )
                              )}
                            </select>
                          </td>
                          <td
                            style={{
                              background:
                                data.attendanceStatus === "Present"
                                  ? "#a5f4a5"
                                  : data.attendanceStatus === "Absent"
                                    ? "#f49999"
                                    : data.attendanceStatus === "Half Day"
                                      ? "#f4cf8c"
                                      : "",
                            }}
                          >
                            <select
                              className="form-control form-control-sm"
                              id="userRoleNameInput"
                              defaultValue={data.attendanceStatus}
                              onChange={(e) =>
                                attendanceStatusChangeHandler(
                                  e.target.value,
                                  data.empId,
                                  index
                                )
                              }
                            >
                              <option value="" disabled>
                                Select Attendance Status
                              </option>
                              <option value="Present">Present</option>
                              <option value="Absent">Absent</option>
                              <option value="Half Day">Half Day</option>
                            </select>
                          </td>
                          <td>
                            {calculateWorkingHours(data.inTime, data.outTime)}{" "}
                            Hours
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-center" />
    </>
  );
};

export default AttendanceManagment;
