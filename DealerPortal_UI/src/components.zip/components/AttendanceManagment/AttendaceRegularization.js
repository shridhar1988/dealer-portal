import React, { useRef, useEffect, useState, useLayoutEffect } from "react";
import { useSelector } from "react-redux";
import { removeExtraSpaces } from "../../common/textOperations";
import { isValidEmail, isValidContact } from "../../common/validations";
import { ToastContainer, toast } from "react-toastify";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import { Link } from "react-router-dom";
import axios from "axios";
import $ from "jquery";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";


const config = require("../../config/config.json");

const AttendaceRegularization = () => {
  const inputFirstNameReference = useRef(null);
  const inputLastNameReference = useRef(null);
  const inputAddressReference = useRef(null);
  const inputregularizeDateReference = useRef(null);
  const inputRemarkInput = useRef(null);
  const inputEmailReference = useRef(null);
  const inputWorkLocationReference = useRef(null);
  const inputPasswordReference = useRef(null);
  const inputContactNumberReference = useRef(null);
  const inputAccountGroupReference = useRef(null);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;


  const personalInfo = useSelector((state) => state.personalInformationReducer);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [department, setDepartment] = useState([]);
  const [address, setAddress] = useState("");
  const [regularizeDate, setRegularizeDate] = useState("");
  const [remark, setRemark] = useState("");
  const [userEmail, setUserEmail] = useState("");
  const [workLocation, setWorkLocation] = useState("work from office");
  const [password, setPassword] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [accountGroup, setAccountGroup] = useState("");
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [allRolesList, setAllRolesList] = useState([]);
  const [allUsersList, setAllUsersList] = useState([]);
  const [updateOrDeleteId, setUpdateOrDeleteId] = useState("");
  const [isActiveUser, setIsActiveUser] = useState(true);
  const [attendanceData, setAttendanceData] = useState([]);
  const [inTime, setInTime] = useState("9:00 AM");
  const [outTime, setOutTime] = useState("9:00 AM");

  useEffect(() => {
    getAllRolesList();
    getAllAttendanceRegularizationByEmployee();
    getAllDepartments();
  }, []);

  const firstUpdate = useRef(true);
  useLayoutEffect(() => {
    if(firstUpdate.current) {
      window.initDatePickerFuncation();
      return;
    }
  });

  const handleCancelClick = () => {
    clearAllFields();
    addProjectCardHeaderButtonClick();
  };

  const getAllAttendanceRegularizationByEmployee = () => {
    setIsLoaderActive(true);

    window.initDestroyDataTableFuncation();
    axios
      .get(
        config.API_URL +
        "EmployeeAttendenceCheck/GetAllAttendanceRegularizationByEmployee?EmpId=" +
        personalInfo.userID
      )
      .then((response) => {
        if(response.status == 200) {


          if(response.data.success == "True") {
            if(response.data.data.length > 0) {



              setAllUsersList(response.data.data);
              setTimeout(() => {
                window.initDataTableFuncation();
              }, 1000);
            }
          } else {
            // toast.error(response.data.message);
            setTimeout(() => {
              window.initDataTableFuncation();
            }, 1000);
          }
        } else if(response.data.status.status == 500) {
          toast.error("Invalid username or password");
        }
      })
      .catch((error) => {
        toast.error("Please try again later.");
      })
      .finally(() => {
        setIsLoaderActive(false);
      });
  };

  const getAllRolesList = () => {
    setIsLoaderActive(true);

    axios
      .get(
        config.API_URL + "AuthMaster/GetAllRoles?ClientId=" + config.ClientId,
        {
          headers: config.headers2,
        }
      )
      .then((response) => {
        if(response.status == 200) {
          if(response.data.success == "success") {
            if(response.data.data.length > 0) {
              setAllRolesList(response.data.data);
            }
          } else {
            toast.error(response.data.message);
          }
        } else if(response.data.status.status == 500) {
          toast.error("Invalid username or password");
        }
      })
      .catch((error) => {
        toast.error("Please try again later.");
      }).finally(() => {
        setIsLoaderActive(false);
      });
  };

  const getAllDepartments = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}Department/GetAllDepartments`
      );
      const appsArray = response.data.data || [];
      setDepartment(appsArray);
    } catch(error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const addProjectCardHeaderButtonClick = () => {
    clearAllFields();
    $("#listOfProjectsHeaderExpandButtion").click();
  };

  const listOfProjectsHeaderExpandButtionClick = () => {
    clearAllFields();
    $("#AddNewHeaderButton").click();
  };

  // const formatDateForDisplay = (isoDateString) => {
  //   if(!isoDateString) return "";
  //   const date = new Date(isoDateString);
  //   const day = String(date.getDate()).padStart(2, "0");
  //   const month = String(date.getMonth() + 1).padStart(2, "0");
  //   const year = date.getFullYear();
  //   return `${day}/${month}/${year}`;
  // };


  const handleEditTaskDetails = (userObj) => {
    setIsLoaderActive(true);

    // console.log("Editing Data date-->:", userObj.attendanceDate);

    
    setUserEmail(userObj.email || "");
    setPassword(userObj.password || "");
    setContactNumber(userObj.contactNumber || "");
    setAccountGroup(userObj.accountGroup || "");
    setUpdateOrDeleteId(userObj.userID || "");
    setFirstName(userObj.firstName || "");
    setLastName(userObj.lastName || "");
    setAddress(userObj.address || "");
    
    
    const formatDateForDisplay = (dateInput) => {
      const date = new Date(dateInput);
      if (isNaN(date)) return ""; // guard against invalid date
      const yyyy = date.getFullYear();
      const mm = String(date.getMonth() + 1).padStart(2, '0');
      const dd = String(date.getDate()).padStart(2, '0');
      return `${yyyy}-${mm}-${dd}`;
    };
    
    setIsActiveUser(userObj.isActive || true);
    setTimeout(() => {
      
      setInTime(userObj.inTime || "9:00 AM");
      setOutTime(userObj.outTime || "9:00 AM");
      setRegularizeDate(formatDateForDisplay(userObj.attendanceDate));
      setRemark(userObj.remark || "");
      setWorkLocation(userObj.workLocation || "work from office");

     
    }, 1500);
    
    // Expand the form section without clearing fields
    $("#listOfProjectsHeaderExpandButtion").click();
    window.scrollTo({ top: 0, behavior: "smooth" });
    setIsLoaderActive(false);
  };

  const handleRemoveUser = (userObj) => {
    setUpdateOrDeleteId(userObj.userID);
    window.confirmModalShow();
  };

  const yesConfirmSubmitRequest = () => {
    setIsLoaderActive(true);
    let APIMethodName =
      "AuthMaster/DeleteUser?ClientId=" +
      config.ClientId +
      "&UserID=" +
      updateOrDeleteId;
    axios
      .post(config.API_URL + APIMethodName, {
        headers: config.headers2,
      })
      .then((response) => {

        if(response.data.success == "success") {
          toast.success("User deleted successfully...");
          window.confirmModalHide();
          clearAllFields();
          getAllAttendanceRegularizationByEmployee();
          setIsLoaderActive(false);
        } else {
          setIsLoaderActive(false);
          toast.error(response.data.message);
        }
      })
      .catch((error) => {
        if(!error.response.data.success) {
          toast.error(error.response.data.message);
        } else {
          toast.error("Please try again later.");
        }
        setIsLoaderActive(false);
      });
  };

  const clearAllFields = () => {
    setWorkLocation("work from office");
    setRemark("");
    setRegularizeDate("");
    setTimeout(() => {
      setInTime("9:00 AM");
      setOutTime("9:00 AM");
    }, 1000);

    inputregularizeDateReference.current.classList.remove("is-invalid");
    inputRemarkInput.current.classList.remove("is-invalid");
    inputWorkLocationReference.current.classList.remove("is-invalid");
  };

  const handleUserSubmit = async (e) => {
    // setIsLoaderActive(true);
    if(regularizeDate) {
      if(remark) {


        try {
          const response = await axios.post(
            `${config.apiEndPoint}/EmployeeAttendenceCheck/AddAttendanceRegularizationRequest`,
            {
              empId: personalInfo.userID,
              attendanceDate: regularizeDate,
              inTime: inTime,
              outTime: outTime,
              workLocation: workLocation,
              remark: remark,
              createdBy: personalInfo.userID,
              modifiedBy: personalInfo.userID,
            }
          );
          if(response.data.success == "True") {
            toast.success(response.data.message);
            getAllAttendanceRegularizationByEmployee();
            clearAllFields();
            addProjectCardHeaderButtonClick();
          } else {
            toast.error(response.data.message);
          }
        } catch(error) {
          console.error("Error applying for leave", error);
        } finally {
          setIsLoaderActive(false);
        }
      } else {
        toast.error("Please enter remark.");
        inputRemarkInput.current.focus();
        inputRemarkInput.current.classList.add("is-invalid");
      }
    } else {
      toast.error("Please select date of regularization.");
      inputregularizeDateReference.current.focus();
      inputregularizeDateReference.current.classList.add("is-invalid");
    }

    setIsLoaderActive(false);
  };

  const generateTimeOptions = () => {
    const options = [];
    const startTime = new Date();
    startTime.setHours(9, 0, 0, 0);
    const endTime = new Date();
    endTime.setHours(21, 0, 0, 0);

    while(startTime <= endTime) {
      let hours = startTime.getHours();
      let minutes = startTime.getMinutes();
      let ampm = hours >= 12 ? "PM" : "AM";

      if(hours > 12) hours -= 12; // Convert to 12-hour format
      if(hours === 0) hours = 12; // Handle 12:00 AM case

      const timeString = `${hours}:${minutes === 0 ? "00" : minutes} ${ampm}`;
      options.push(timeString);

      // Increase time by 15 minutes
      startTime.setMinutes(startTime.getMinutes() + 15);
    }

    return options;
  };

  const inAndOutTimeChangeHandler = (getSelectedValue, drodwName) => {
    if(drodwName == "intime") {
      setInTime(getSelectedValue);
    } else {
      setOutTime(getSelectedValue);
    }
  };


  const filteredEntries = allUsersList.filter((entry) =>
    entry.remark?.toLowerCase().includes(searchText.toLowerCase()) ||
    entry.workLocation?.toLowerCase().includes(searchText.toLowerCase()) ||
    entry.attendanceDate?.toLowerCase().includes(searchText.toLowerCase())
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredEntries.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredEntries.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, filteredEntries.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const exportToCSV = () => {
    let csvContent = "Date to regularize,In Time,Out Time,Work Location,Remark,Status\n";
    filteredEntries.forEach((entry) => {
      csvContent += `"${entry.attendanceDate}","${entry.inTime}","${entry.outTime}","${entry.workLocation}","${entry.remark}","${entry.regularizationStatus}"\n`;
    });
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "AttendanceRegularization.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredEntries.map((entry) => ({
        "Date to regularize": entry.attendanceDate,
        "In Time": entry.inTime,
        "Out Time": entry.outTime,
        "Work Location": entry.workLocation,
        "Remark": entry.remark,
        "Status": entry.regularizationStatus,
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Attendance");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "AttendanceRegularization.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Attendance Regularization", 14, 10);
    autoTable(doc, {
      head: [["Date to regularize", "In Time", "Out Time", "Work Location", "Remark", "Status"]],
      body: filteredEntries.map((entry) => [
        entry.attendanceDate,
        entry.inTime,
        entry.outTime,
        entry.workLocation,
        entry.remark,
        entry.regularizationStatus,
      ]),
    });
    doc.save("AttendanceRegularization.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print Attendance</title></head><body>");
    printWindow.document.write("<h3>Attendance Regularization List</h3>");
    printWindow.document.write("<table border='1' cellspacing='0' cellpadding='5'><thead><tr><th>Date to regularize</th><th>In Time</th><th>Out Time</th><th>Work Location</th><th>Remark</th><th>Status</th></tr></thead><tbody>");
    filteredEntries.forEach((entry) => {
      printWindow.document.write(`<tr><td>${entry.attendanceDate}</td><td>${entry.inTime}</td><td>${entry.outTime}</td><td>${entry.workLocation}</td><td>${entry.remark}</td><td>${entry.regularizationStatus}</td></tr>`);
    });
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };


  useEffect(() => {
    console.log("Populated Form Data:", {
      regularizeDate,
      inTime,
      outTime,
      workLocation,
      remark,
    });
  }, [regularizeDate, inTime, outTime, workLocation, remark]);



  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">
                Attendace Regularize
                <span
                  hover-tooltip="The Attendance Regularization page is designed to help you address any discrepancies in your previous attendance records. If you notice any mismatches, you can submit a request to regularize your attendance. Simply click on Add New Request to create a request, which will then be sent to HR for approval."
                  tooltip-position="bottom"
                >
                  <i
                    className="fas fa-info-circle ml-2"
                    style={{ color: "rgb(0 0 0 / 51%)" }}
                  ></i>
                </span>
              </h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/employee-dashboard">Home</Link>
                </li>
                <li className="breadcrumb-item active">Attendace Regularize</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <section className="content">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12">
              <div className="card card-outline card-primary position-relative collapsed-card">
              {isLoaderActive && (
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgb(233 236 239 / 81%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 10,
                      }}
                    >
                      <i
                        className="fas fa-sync-alt fa-spin"
                        style={{ fontSize: "2rem", color: "#333" }}
                      ></i>
                    </div>
                  )}
                <div className="card-header">
                  <h3 className="card-title text-sm">
                    Attendace Regularize Request
                    <span
                      hover-tooltip="
To submit a regularization request, start by selecting the date for which you want to update your attendance. Next, provide the updated in-time and out-time for the chosen date and specify the work location. After that, add a brief remark explaining the reason for the update. Please note that the date and remark fields are mandatory. The in-time and out-time you provide will directly update your attendance record. Once all the details are filled in, submit the request by clicking on Send Request."
                      tooltip-position="bottom"
                    >
                      <i
                        className="fas fa-info-circle ml-2"
                        style={{ color: "rgb(0 0 0 / 51%)" }}
                      ></i>
                    </span>
                  </h3>
                  <div className="card-tools">
                    <button
                      type="button"
                      className="btn btn-danger btn-xs"
                      id="AddNewHeaderButton"
                      onClick={(e) => {
                        addProjectCardHeaderButtonClick(e);
                      }}
                      data-card-widget="collapse"
                    >
                      <i className="fas fa-plus"></i> Add New Request
                    </button>
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
                <div className="card-body text-sm">
                  <div className="row">
                    <div className="form-group col-md-4">
                      <label style={{ color: "#000" }}>
                        Date to regularize<sup style={{ color: "red" }}>*</sup>
                      </label>
                      <input
                        type="date"
                        className="form-control form-control-sm"
                        ref={inputregularizeDateReference}
                        value={regularizeDate}
                        max={new Date().toISOString().split("T")[0]}
                        onChange={(e) => {
                          setRegularizeDate(e.target.value);
                          inputregularizeDateReference.current.classList.remove(
                            "is-invalid"
                          );
                        }}
                        placeholder="Date Of Regularization Date"
                      />
                    </div>
                    <div className="form-group col-md-2">

                      <label htmlFor="firstNameInput" style={{ color: "#000" }}>
                        In Time
                      </label>
                      <select
                        className="form-control form-control-sm"
                        id={"inTimeDropdown_" + 1}
                        value={inTime}
                        onChange={(e) =>
                          inAndOutTimeChangeHandler(e.target.value, "intime")
                        }
                      >
                        {generateTimeOptions().map((time, index) => (
                          <option key={index} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group col-md-2">
                      <label htmlFor="lastNameInput" style={{ color: "#000" }}>
                        Out Time
                      </label>
                      <select
                        className="form-control form-control-sm"
                        id={"outTimeDropdown_" + 1}
                        value={outTime}
                        onChange={(e) =>
                          inAndOutTimeChangeHandler(e.target.value, "outtime")
                        }
                      >
                        {generateTimeOptions().map((time, index) => (
                          <option key={index} value={time}>
                            {time}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="form-group col-md-4">
                      <label style={{ color: "#000" }}>Work Location</label>
                      <select
                        className="form-control form-control-sm"
                        ref={inputWorkLocationReference}
                        value={workLocation}
                        onChange={(e) => {
                          setWorkLocation(e.target.value);
                          inputWorkLocationReference.current.classList.remove(
                            "is-invalid"
                          );
                        }}
                      >
                        <option value="work from office">
                          Work from office
                        </option>
                        <option value="work from home">Work from home</option>
                        <option value="client location">Client location</option>
                      </select>
                    </div>
                    <div className="form-group col-md-12">
                      <label htmlFor="userRemarkInput" style={{ color: "#000" }}>
                        Remark<sup style={{ color: "red" }}>*</sup>
                      </label>
                      <textarea
                        type="text"
                        className="form-control form-control-sm"
                        id="userRemarkInput"
                        ref={inputRemarkInput}
                        value={remark}
                        onChange={(e) => {
                          setRemark(e.target.value);
                          inputRemarkInput.current.classList.remove(
                            "is-invalid"
                          );
                        }}
                        style={{ minHeight: "100px" }}
                        placeholder="Enter remark"
                      />
                    </div>


                  </div>
                </div>
                <div className="card-footer text-sm">
                  {isLoaderActive ? (
                    <PleaseWaitButton className="float-right btn-xs ml-2 font-weight-medium auth-form-btn" />
                  ) : (
                    <button
                      type="submit"
                      className="btn btn-success float-right btn-xs ml-2"
                      onClick={(e) => {
                        handleUserSubmit(e);
                      }}
                    >
                      Save & Submit
                    </button>
                  )}
                  <button
                    type="submit"
                    className="btn btn-default float-right btn-xs"
                    onClick={(e) => {
                      handleCancelClick(e);
                    }}
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="row">
            <div className="col-md-12">
              <div className="card card-outline card-primary ">
                <div className="card-header">
                  <h3 className="card-title text-sm">
                    All Request ( {allUsersList.length} )
                  </h3>
                  <div className="card-tools">
                    <button
                      type="button"
                      className="btn btn-tool"
                      id="listOfProjectsHeaderExpandButtion"
                      onClick={(e) => {
                        listOfProjectsHeaderExpandButtionClick(e);
                      }}
                      data-card-widget="collapse"
                    >
                      <i className="fas fa-minus"></i>
                    </button>
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
                <div className="card-body text-sm position-relative">
                  {isLoaderActive && (
                    <div
                      style={{
                        position: "absolute",
                        top: 0,
                        left: 0,
                        width: "100%",
                        height: "100%",
                        backgroundColor: "rgb(233 236 239 / 81%)",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        zIndex: 10,
                      }}
                    >
                      <i
                        className="fas fa-sync-alt fa-spin"
                        style={{ fontSize: "2rem", color: "#333" }}
                      ></i>
                    </div>
                  )}
                  <div className="d-flex justify-content-between mb-2">
                    <div>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                      <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                    </div>
                    <input
                      type="text"
                      className="form-control form-control-sm w-25"
                      placeholder="Search..."
                      onChange={(e) => {
                        setSearchText(e.target.value);
                        setCurrentPage(1);
                      }}
                    />
                  </div>

                  <table
                    className="table table-bordered table-sm table-striped"
                  >
                    <thead>
                      <tr>
                        <th
                          style={{ fontWeight: "500", fontSize: "smaller" }}
                          className="text-center"
                        >
                          Sr. No.
                        </th>
                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          Date to regularize
                        </th>
                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          In Time
                        </th>
                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          Out Time
                        </th>
                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          Work Location
                        </th>
                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          Remark
                        </th>

                        <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                          Regularization Status
                        </th>
                        <th
                          style={{
                            fontWeight: "500",
                            fontSize: "smaller",
                            width: "7%",
                          }}
                        >
                          Action
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {currentRows.length > 0 ? (
                        currentRows.map((userObj, index) => (
                          <tr key={index}>
                            <td className="text-center text-sm">{indexOfFirstRow + index + 1}</td>
                            <td>{userObj.attendanceDate || "N/A"}</td>
                            <td>{userObj.inTime || "N/A"}</td>
                            <td>{userObj.outTime || "N/A"}</td>
                            <td>{userObj.workLocation || "N/A"}</td>
                            <td>{userObj.remark || "N/A"}</td>
                            <td>
                              <span className={
                                userObj.regularizationStatus === "Pending" ? "badge bg-warning text-light" :
                                  userObj.regularizationStatus === "Accepted" ? "badge bg-success text-light" :
                                    userObj.regularizationStatus === "Rejected" ? "badge bg-danger" :
                                      "badge bg-secondary"
                              }>
                                {userObj.regularizationStatus === "Deleted" ? "Canceled" : userObj.regularizationStatus}
                              </span>
                            </td>
                            <td className="text-center text-sm">
                              {userObj.regularizationStatus === "Pending" && (
                                <button className="btn btn-outline-warning btn-xs" onClick={() => handleEditTaskDetails(userObj)}>
                                  <i className="fas fa-edit"></i>
                                </button>
                              )}
                              {userObj.isActive && (
                                <button className="btn btn-outline-danger btn-xs ml-2" onClick={() => handleRemoveUser(userObj)}>
                                  <i className="fas fa-trash"></i>
                                </button>
                              )}
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr><td colSpan="8" className="text-center">No records found</td></tr>
                      )}
                    </tbody>

                  </table>
                  <div className="d-flex justify-content-between mt-2">
                    <div>
                      Showing {startEntry} to {endEntry} of {filteredEntries.length} entries
                    </div>
                    <div>
                      <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                        <i className="fas fa-angle-double-left"></i>
                      </button>
                      <span className="mx-2">Page {currentPage} of {totalPages}</span>
                      <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                        <i className="fas fa-angle-double-right"></i>
                      </button>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div
        id="confirmCommonModal"
        className="modal fade confirmCommonModal"
        data-backdrop="static"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-confirm">
          <div className="modal-content">
            <div className="modal-header text-center">
              <div className="icon-box">
                <i className="fas fa-info mt-2"></i>
              </div>
              <h5 className="modal-title w-100">Are you sure ?</h5>
            </div>
            <div className="modal-body">
              <p className="text-center">
                By clicking on Yes delete all the user details. Once you deleted
                it can not be recovered.
              </p>
            </div>
            <div className="modal-footer col-md-12">
              <button className="btn btn-default btn-sm" data-dismiss="modal">
                Cancel
              </button>
              {isLoaderActive ? (
                <PleaseWaitButton className="btn-sm pl-3 pr-3 ml-2 font-weight-medium auth-form-btn" />
              ) : (
                <button
                  className="btn btn-warning btn-sm pl-3 pr-3 ml-2"
                  onClick={(e) => {
                    yesConfirmSubmitRequest(e);
                  }}
                >
                  Yes
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-center" />
    </>
  );
};

export default AttendaceRegularization;
