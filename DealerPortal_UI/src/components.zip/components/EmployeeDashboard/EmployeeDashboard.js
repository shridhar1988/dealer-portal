import React, { useRef, useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useSelector } from "react-redux";
import "./EmployeeDashboard.css";
import config from "../../config/config.json";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import laudi from "../../assets/images/employeeDashleadySpeaker.png";
import $ from "jquery";
function EmployeeDashboard() {
  const [status, setStatus] = useState([]);
  const [leaveEntries, setLeaveEntries] = useState([]);
  const [leaves, setLeaves] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [allYearAttendace, setAllYearAttendace] = useState([]);
  let navigate = useNavigate();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const empId = personalInfo.userID;
  const [loggedUser, setLoggedUser] = useState("");
  const [holidays, setHolidays] = useState([]);
  const [showInput, setShowInput] = useState('');
  const [streamUrl, setStreamUrl] = useState("");
  const [showModal, setShowModal] = useState(false);


  useEffect(() => {
    window.initScroller();
    GetAttendanceStatusByUserIdAndYear();
    window.calendarEmp();
    GetAttandance();
    fetchLeaveData();
    GetNotifications();
    fetchHolidays(new Date().getFullYear());
  }, []);

  useEffect(() => {
    setLoggedUser(personalInfo.userRole);
  }, [personalInfo]);

  const fetchHolidays = async (year) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Holiday/GetAllHolidayByYear?year=${year}`
      );
      const componentsArray = response.data.data || [];
      // console.log("Holidays fetched ===> ", componentsArray);
      setHolidays(componentsArray);
    } catch (error) {
      console.error("Error fetching holidays:", error);
      setHolidays([]);
      toast.error("Error fetching holidays");
    }
  };

  const GetAttandance = async () => {
    const loggedUserId = localStorage.getItem("loggedUserId");
    const date = new Date();
    const month = date.toLocaleString("en-US", { month: "2-digit" });
    const year = date.getFullYear();

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/EmployeeAttendenceCheck/GetAllandanceStatusByUserIdAndDate?UserId=${loggedUserId}&month=${month}&year=${year}`
      );
      const appsArray = response.data.data || [];

      if (appsArray) {
        const currentDate = new Date()
          .toLocaleDateString("en-GB")
          .split("/")
          .join("-");
        const isCurrentDayPresent = appsArray.find(
          (app) => app.date == currentDate
        );
        if (isCurrentDayPresent) {
          setStatus(isCurrentDayPresent);
        } else {
          setStatus({});
        }
      } else {
        setStatus({});
      }
    } catch (error) {
      console.error("Error fetching attendance status:", error);
    }
  };

  const fetchLeaveData = async () => {
    try {
      window.initDestroyDataTableFuncation();
      const response = await axios.get(
        `${config.API_URL}LeaveManagement/GetAllAppledLeavesByUserId?EmpId=${empId}`
      );
      if (response.data.success) {
        const processedEntries = response.data.data;
        // console.log("processedEntries--->", processedEntries);
        processedEntries.map((entry) => {
          const fileName = entry.attachmentPath?.split("\\").pop() || "";
          const isImage =
            fileName.endsWith(".png") ||
            fileName.endsWith(".jpg") ||
            fileName.endsWith(".jpeg");
          const isPDF = fileName.endsWith(".pdf");

          return {
            ...entry,
            fileName,
            isImage,
            isPDF,
          };
        });
        setLeaveEntries(processedEntries);
        GetAllLeaves();
        setTimeout(() => {
          window.initDataTable();
        }, 1000);
      } else {
        console.error(response.data.message);
      }
    } catch (error) {
      console.error("Error fetching leave data", error);
    }
  };

  const GetAllLeaves = async () => {
    try {
      const response = await axios.get(
        `${config.API_URL}LeaveType/GetAllLeaveTypes`
      );
      const appsArray = response.data.data || [];
      if (appsArray) {
        setLeaves(appsArray);
        // console.log("leaves--->", appsArray);

      } else {
        setLeaves([]);
      }
    } catch (error) {
      console.error("Error fetching LeaveTpes:", error);
      // toast.error("Error fetching LeaveTpes");
    }
  };

  const GetAttendanceStatusByUserIdAndYear = async () => {
    const loggedUserId = localStorage.getItem("loggedUserId");
    const currentYear = new Date().getFullYear();
 
    const monthNameToIndex = {
      January: 0, February: 1, March: 2, April: 3,
      May: 4, June: 5, July: 6, August: 7,
      September: 8, October: 9, November: 10, December: 11,
    };
 
    try {
      const response = await axios.get(
        `${config.API_URL}EmployeeAttendenceCheck/GetAttendanceStatusByUserIdAndDate?userId=${loggedUserId}&year=${currentYear}`
      );
 
      const appsArray = response.data || [];
 
      // Store the raw data if needed
      setAllYearAttendace(appsArray);
 
      // Prepare data for all 12 months, even if some are missing
      const chartData = Array.from({ length: 12 }, (_, i) => {
        const monthName = Object.keys(monthNameToIndex).find(
          key => monthNameToIndex[key] === i
        );
        const match = appsArray.find(item => item.month === monthName);
        return {
          month: i, // numeric month index
          totalWorkHours: match ? Number(match.totalWorkHours) : 0,
        };
      });
 
      console.log("chartData --->", chartData);
 
      // Call the chart rendering function
      window.getBarChart(chartData);
 
    } catch(error) {
      $('#bar-chart').html('<p>No work hours found</p>');
      console.error("Error fetching attendance data:", error);
      setAllYearAttendace([]);
      window.getBarChart([]); // Show empty chart
    }
  };

  const GetNotifications = async () => {
    try {
      const response = await axios.get(
        `${config.API_URL}NotificationBrodcast/GetAllNotification`
      );
      if (response.data.success == "True") {
        const appsArray = response.data.data || [];
        setNotifications(appsArray || []);
      } else {
        toast.error("Notification not fetched!");
        setNotifications([]);
      }
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, "0");
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
  };

  const startLiveStream = async () => {
    try {
      const response = await axios.get(
        `${config.API_URL}Auth/getLiveStreamUrl`
      );
      if (response.data) {
        // console.log("Live Stream URL:", response.data.data.result);
        setStreamUrl(response.data.data.result + "/");
        //toast.success("Live Stream URL fetched successfully!");
        setShowModal(true);
        //window.open(response.data.data.result+"/", "_blank", "noopener,noreferrer");    
      } else {
        // console.log("Error in Live Stream ")
      }
    } catch (error) {
      console.error("Error fetching notifications:", error);
    }
  }
  const getRelativeTime = (dateString) => {
    const notificationDate = new Date(dateString);
    const currentDate = new Date();
    const differenceInMillis = currentDate - notificationDate;

    const minutes = Math.floor(differenceInMillis / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes} mins ago`;
    if (hours < 24) return `${hours} hours ago`;
    if (days == 1) return "Yesterday";
    return `${days} days ago`;
  };

  const hideModal = () => {
    setShowModal(false);
  };

  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row">
            <div className="col-sm-6">
              <h1 className="m-0">Dashboard</h1>
            </div>
            <div className="col-sm-6">


              <ol className="breadcrumb float-sm-right">
                <>
                  {loggedUser === "HR" && (
                    <>
                      {/* <button
                        type="button"
                        className="btn-sm btn-primary text-sm mr-2"
                        style={{
                          border: "none",
                          color: "rgb(85, 7, 74)",
                          background: "rgb(228, 186, 108)",
                        }}
                        onClick={startLiveStream}
                        data-bs-toggle="modal"
                        data-bs-target="#liveStreamModal"
                      >
                        <i class="fas fa-video"></i> Watch Live Stream
                      </button> */}

                    </>
                  )}
                </>

                <li className="breadcrumb-item">
                  <Link to="/employee-dashboard">Home</Link>
                </li>
                <li className="breadcrumb-item active">Dashboard</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <section class="content">
        <div class="container-fluid">
          <div class="row">
            {loggedUser == "HR" ? (
              <>
                <div className="col-lg-7 col-md-6 col-sm-12">
                  <div
                    className="card leady"
                    style={{ background: "#D8E4FD", borderRadius: "5px" }}
                  >
                    <h4
                      className="card-header pb-0"
                      style={{ borderBottom: "none" }}
                    >
                      Announcements
                    </h4>
                    <div className="card-body py-2">
                      <div className="row">
                        <div className="col-md-9">
                          <h6 className="mb-2">Hello There!</h6>
                          <p className="mb-2">
                            Welcome to our Announcement Center! Here, you can easily
                            create and send out announcements to keep everyone
                            informed and engaged.
                          </p>
                        </div>
                        <div className="col-md-3">
                          <img
                            src={laudi}
                            alt=""
                            className="laudi img-fluid w-100"
                          ></img>
                        </div>
                        <div className="col-md-12">
                          <button
                            type="button"
                            className="btn-sm btn-primary text-sm mb-2"
                            style={{ border: "none" }}
                            onClick={() => navigate("/broadcast-notification")}
                          >
                            <i className="fas fa-plus mr-2"></i>Create
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div class="col-md-7 px-3">
                  <div className="row mb-3" style={{ background: "#D8E4FD", height: "10.8rem", borderRadius: '5px' }}>
                    <div className="card col-md-9" style={{ background: "#D8E4FD", boxShadow: 'none' }}>
                      <h5 class="card-header">Notice Board</h5>
                      <div className="card-body notification p-2">
                        <style>
                          {`
                        .notification::-webkit-scrollbar {
                          display: none;
                        }
                        .notification {
                          overflow: hidden;
                          height: 5.8rem;
                          position: relative;
                        }
                        .notification-content {
                          position: absolute;
                          cursor: s-resize;
                          animation: scrollNotification 20s linear infinite;
                          animation-play-state: running;
                        }
                        .notification-content:hover {
                        animation-play-state: paused;
                        }
                        @keyframes scrollNotification {
                          0% {
                            top: 100%;
                          }
                          100% {
                            top: -200%;
                          }
                        }
                          .heading:hover {
                              background:f4f6f9;
                            }
                        .small-txt {
                          font-size: 10px !important;
                        }
                      `}
                        </style>
                        <div className="col-md-12 notification-content">
                          {notifications
                            .sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn))
                            .map((notif, index) => {
                              const [dateString, time] = notif.createdOn.split(" ");
                              const formattedDate = formatDate(dateString);
                              const relativeTime = getRelativeTime(notif.createdOn);
                              return (
                                <div key={index} id="accordion">
                                  <div className="card mb-2">
                                    <div className="card-header text-xs p-2 heading">
                                      <p className="d-flex w-100 collapsed mb-0 text-bold" data-toggle="collapse" href={`#collapse${index}`} aria-expanded="false">
                                        {index + 1}. {notif.notificationHeading}
                                        <span className="small-txt ml-auto mt-1"><i class="far fa-clock mx-1" />{relativeTime}</span>
                                      </p>
                                    </div>
                                    <div id={`collapse${index}`} className="collapse" data-parent="#accordion">
                                      <div className="card-body p-1 px-2">
                                        <div
                                          dangerouslySetInnerHTML={{ __html: notif.notificationDescription }}
                                        ></div>
                                        <span className="small-txt mt-1 float-right">{formattedDate}</span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                        </div>
                      </div>
                      <div className="card-footer p-1" style={{ background: '#D8E4FD' }}>
                        <a href="#" className="text-sm float-right text-bold" onClick={() => navigate("/broadcast-notification")}>View All</a>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <img
                        src={laudi}
                        alt=""
                        class="img-fluid w-100"
                      ></img>
                    </div>
                  </div>
                </div>
              </>
            )}
            <div class="col-lg-5 col-md-6 col-sm-12">
              <div
                className="card card-primary card-outline"
                style={{ height: "10.7rem" }}>
                <div className="card-body d-flex flex-column">
                  <div className="row">
                    <h3 className="card-title text-bold mb-2 pl-2">
                      Share your Idea to Improve HR Software
                    </h3>
                    <div className="col-md-12">
                      <h6>Have any ideas to improving your dashboard?</h6>
                    </div>
                  </div>
                  {showInput && (
                    <div className="my-2">
                      <input type="text" className="form-control form-control-sm" placeholder="Enter your idea..." />
                    </div>
                  )}
                  <div className="mt-auto pl-0">
                    {!showInput ? (
                      <button type="submit" className="btn btn-primary btn-xs" onClick={() => setShowInput(true)}>
                        Share Idea
                      </button>
                    ) : (
                      <button type="submit" className="btn btn-primary btn-xs" onClick={() => setShowInput(false)}>
                        Submit
                      </button>
                    )}
                  </div>
                </div>
              </div>

            </div>
          </div>

          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-primary card-outline">
                <div className="card-header">
                  <div className="row ">
                    <div className="col-md-10 ">
                      <h5 class="header mb-0">My Status</h5>
                    </div>
                    <div className="col-md-2">
                      <span
                        className={
                          status.attendaceStatus === "Half Day"
                            ? "badge rounded-pill bg-warning text-light text-sm p-2"
                            : status.attendaceStatus === "Present"
                              ? "badge rounded-pill bg-success text-light text-sm p-2"
                              : status.attendaceStatus === "Absent"
                                ? "badge rounded-pill bg-danger text-sm p-2"
                                : "badge rounded-pill bg-danger text-sm p-2"
                        }
                      >
                        {status.attendaceStatus || "Absent"}
                      </span>
                    </div>
                  </div>

                </div>

                <div class="card-body ">
                  <div class="row" style={{ margin: "5px" }}>
                    <div class="col-4">
                      <div class="row">
                        <h6>{status.inTime || "-- : --"}</h6>
                      </div>
                      <div class="row">
                        <label>Today's In Time</label>
                      </div>
                    </div>
                    <div
                      class="col-2 text-center"
                      style={{
                        borderRight: "1px solid grey",
                        fontSize: "xx-large",
                      }}
                    >
                      <i class="fas fa-clock" style={{ color: "#28a745" }}></i>
                    </div>
                    <div class="col-4">
                      <div class="row ml-2">
                        <h6>{status.outTime || "-- : --"}</h6>
                      </div>
                      <div class="row ml-2">
                        <label>Today's Out Time</label>
                      </div>
                    </div>
                    <div
                      class="col-2 text-center"
                      style={{ fontSize: "xx-large" }}
                    >
                      <i class="fas fa-clock" style={{ color: "#ffc107" }}></i>
                    </div>
                  </div>
                  <hr />
                  <div class="row ml-1">
                    <Link to={"/user-attendance"}>
                      <span> View My Attendance</span>
                      <i class="fas fa-arrow-right ml-2"></i>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-primary card-outline">
                <h5 class="card-header">Work Hours</h5>
                <div class="card-body text-center">
                  <div id="bar-chart" style={{ height: "120px" }}></div>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-7 col-md-6 col-sm-12">
              <div class="card card-primary card-outline">
                <h5 class="card-header">My Leaves Data</h5>
                <div
                  class="card-body table-responsive p-0"
                  style={{
                    overflowY: "auto",
                    whiteSpace: "nowrap",
                    paddingBottom: "5px",
                    paddingTop: "5px",
                    scrollbarWidth: "none",
                    msOverflowStyle: "none",
                    height: "230px",
                  }}
                >
                  <style>
                    {`.button-container::-webkit-scrollbar {display: none; }`}
                  </style>
                  <table class="table table-hover text-nowrap table-striped">
                    <thead>
                      <tr>
                        <th>Sr.No.</th>
                        <th>Leave Type</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Reason</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {leaveEntries.length > 0 ? (
                        leaveEntries.map((entry, index) => {
                          const leave = leaves.find(
                            (l) => l.id == entry.leaveType
                          );
                          return (
                            <tr key={entry.id}>
                              <td>{index + 1}</td>
                              <td>{leave?.leaveTypeName || "N/A"}</td>
                              <td>
                                {new Date(entry.fromDate)
                                  .toISOString()
                                  .split("T")[0]
                                  .split("-")
                                  .reverse()
                                  .join("-")}
                              </td>
                              <td>
                                {new Date(entry.toDate)
                                  .toISOString()
                                  .split("T")[0]
                                  .split("-")
                                  .reverse()
                                  .join("-")}
                              </td>

                              <td>{entry.leaveReason}</td>
                              <td>
                                <span
                                  className={
                                    entry.leaveStatus === "Pending"
                                      ? "badge rounded-pill bg-warning text-light"
                                      : entry.leaveStatus === "Approved"
                                        ? "badge rounded-pill bg-success text-light"
                                        : entry.leaveStatus === "Rejected"
                                          ? "badge rounded-pill bg-danger"
                                          : entry.leaveStatus === "Deleted"
                                            ? "badge rounded-pill bg-danger"
                                            : "badge rounded-pill bg-secondary"
                                  }
                                >
                                  {entry.leaveStatus}
                                </span>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan="6" style={{ textAlign: "center" }}>
                            No leaves applied
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="col-lg-5 col-md-6 col-sm-12">
              <div class="card card-primary card-outline">
                <div>
                  <div id="calendar"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* Modal for Live Stream */}
      <div
        className={`modal fade ${showModal ? "show d-block" : ""}`}
        id="liveStreamModal"
        tabIndex="-1"
        aria-labelledby="liveStreamModalLabel"
        aria-hidden={!showModal}
      >
        <div className="modal-dialog modal-lg modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h6 className="modal-title w-100 text-center" id="liveStreamModalLabel">
                Pune Location Live Stream
              </h6>
              <button
                type="button"
                className="close"
                onClick={hideModal}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>

            <div className="modal-body justify-content-center">
              {streamUrl ? (
                <iframe
                  id="liveStreamIframe"
                  src={streamUrl}
                  width="100%"
                  height="500px"
                  style={{ border: "none" }}
                  allowFullScreen
                ></iframe>
              ) : (
                <h6 className="text-center text-danger">Loading stream...</h6>
              )}
            </div>

            <div className="modal-footer justify-content-center">
              <button
                type="button"
                className="btn btn-secondary"
                onClick={hideModal}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Modal for Live Stream */}
      <ToastContainer position="top-center" />
    </>
  );
}

export default EmployeeDashboard;
