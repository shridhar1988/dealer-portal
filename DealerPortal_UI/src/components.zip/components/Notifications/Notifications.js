// import React, { useRef, useEffect, useState } from "react";
// import { Link } from "react-router-dom";
// import { useSelector } from "react-redux";
// import config from "../../config/config.json";
// import axios from "axios";
// import { ToastContainer, toast } from "react-toastify";

// function Notifications() {
//     const personalInfo = useSelector((state) => state.personalInformationReducer);
//     const [notifications, setNotifications] = useState([]);

//     useEffect(() => {
//         window.initDataTable();
//         GetNotifications();
//     }, []);

//     const GetNotifications = async () => {
//         try {
//             const response = await axios.get(
//                 `${config.apiEndPoint}/TextFile/NotifiactionText`
//             );

//             if (response.data.data.length > 0) {
//                 const latestNotifications = response.data.data;
//                 setNotifications(latestNotifications || []);
//                 // console.log("all notifications--->", response.data.data);
//             } else {
//                 console.error("Error fetching notifications:");
//             }
//         } catch (error) {
//             console.error("Error fetching notifications:");
//         }
//     };


//     const formatDate = (dateString) => {
//         const date = new Date(dateString);
//         const day = String(date.getDate()).padStart(2, "0");
//         const month = String(date.getMonth() + 1).padStart(2, "0");
//         const year = date.getFullYear();
//         return `${day}/${month}/${year}`;
//     };

//     const getRelativeTime = (dateString) => {
//         const notificationDate = new Date(dateString);
//         const currentDate = new Date();
//         const differenceInMillis = currentDate - notificationDate;

//         const minutes = Math.floor(differenceInMillis / (1000 * 60));
//         const hours = Math.floor(minutes / 60);
//         const days = Math.floor(hours / 24);

//         if (minutes < 1) return "Just now";
//         if (minutes < 60) return `${minutes} mins ago`;
//         if (hours < 24) return `${hours} hours ago`;
//         if (days == 1) return "Yesterday";
//         return `${days} days ago`;
//     };

//     const extractDetails = (notification) => {
//         const match = notification.match(
//             /Date\s*:\s*([^~]+).*?Message\s*:\s*([^,]+),/
//         );
//         if (match) {
//             return {
//                 date: match[1].trim(),
//                 message: match[2].trim(),
//             };
//         }
//         return null;
//     };

//     const parsedNotifications = notifications.map(extractDetails).filter(Boolean);


//     return (
//         <>
//             <div className="content-header">
//                 <div className="container-fluid">
//                     <div className="row mb-2">
//                         <div className="col-sm-6">
//                             <h1 className="m-0">Notifications</h1>
//                         </div>
//                         <div className="col-sm-6">
//                             <ol className="breadcrumb float-sm-right">
//                                 <li className="breadcrumb-item">
//                                     <Link to="/dashboard">Home</Link>
//                                 </li>
//                                 <li className="breadcrumb-item active">Notifications</li>
//                             </ol>
//                         </div>
//                     </div>
//                 </div>
//             </div>


//             <div className="container-fluid">
//                 <div className="card">
//                     <div className="card-header">
//                         <h3 className="card-title text-sm">
//                             Notifications
//                         </h3>
//                     </div>
//                     <div className="card-body">
//                         <table id="example1" className="table table-sm table-striped table-bordered">
//                             <thead>
//                                 <tr>
//                                     <th className='text-center'>Sr. No.</th>
//                                     <th>Notification</th>
//                                     <th>Date</th>
//                                 </tr>
//                             </thead>
//                             <tbody>
//                                 {parsedNotifications
//                                     .sort((a, b) => new Date(b.date) - new Date(a.date))
//                                     .map((notif, index) => {
//                                         const cleanedMessage = notif.message
//                                             .replace(/}/, ".")
//                                             .trim();
//                                         const [dateString, time] = notif.date.split(" ");
//                                         const formattedDate = formatDate(dateString);
//                                         const relativeTime = getRelativeTime(notif.date);
//                                         return (
//                                             <tr key={index}>
//                                                 <td>{index + 1}</td>
//                                                 <td>{cleanedMessage}</td>
//                                                 <td>{formattedDate}</td>
//                                             </tr>
//                                         );
//                                     })}
//                             </tbody>
//                         </table>
//                     </div>
//                 </div>
//             </div>
//             <ToastContainer position="top-center" />
//         </>
//     )
// }

// export default Notifications



import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import axios from "axios";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";

function Notifications() {
    const [notifications, setNotifications] = useState([]);
    const [searchText, setSearchText] = useState("");
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;

    useEffect(() => {
        GetNotifications();
    }, []);

    const GetNotifications = async () => {
        try {
            const response = await axios.get(`${config.apiEndPoint}/TextFile/NotifiactionText`);
            if(response.data.data.length > 0) {
                const latestNotifications = response.data.data;
                setNotifications(latestNotifications || []);
            }
        } catch(error) {
            toast.error("Error fetching notifications");
            console.error("Error fetching notifications:", error);
        }
    };

    const extractDetails = (notification) => {
        const match = notification.match(/Date\s*:\s*([^~]+).*?Message\s*:\s*([^,]+),/);
        if(match) {
            return {
                date: match[1].trim(),
                message: match[2].trim(),
            };
        }
        return null;
    };

    const formatDate = (dateString) => {
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    };

    const parsedNotifications = notifications
        .map(extractDetails)
        .filter(Boolean)
        .sort((a, b) => new Date(b.date) - new Date(a.date));

    // Filtered and paginated
    const filtered = parsedNotifications.filter((n) =>
        n.message.toLowerCase().includes(searchText.toLowerCase())
    );

    const indexOfLastRow = currentPage * rowsPerPage;
    const indexOfFirstRow = indexOfLastRow - rowsPerPage;
    const currentRows = filtered.slice(indexOfFirstRow, indexOfLastRow);
    const totalPages = Math.ceil(filtered.length / rowsPerPage);

    const handlePageChange = (newPage) => {
        if(newPage >= 1 && newPage <= totalPages) {
            setCurrentPage(newPage);
        }
    };

    const exportToCSV = () => {
        let csv = "Notification,Date\n";
        parsedNotifications.forEach((n) => {
            csv += `"${n.message}","${formatDate(n.date)}"\n`;
        });
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        saveAs(blob, "Notifications.csv");
    };

    const exportToExcel = () => {
        const data = parsedNotifications.map((n) => ({
            Notification: n.message,
            Date: formatDate(n.date),
        }));
        const worksheet = XLSX.utils.json_to_sheet(data);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Notifications");
        const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
        const blob = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        saveAs(blob, "Notifications.xlsx");
    };

    const exportToPDF = () => {
        const doc = new jsPDF();
        doc.text("Notifications", 14, 10);
        autoTable(doc, {
            head: [["Notification", "Date"]],
            body: parsedNotifications.map((n) => [n.message, formatDate(n.date)]),
        });
        doc.save("Notifications.pdf");
    };

    const printTable = () => {
        const printWindow = window.open("", "", "width=800,height=600");
        printWindow.document.write("<html><head><title>Notifications</title></head><body>");
        printWindow.document.write("<table border='1'><tr><th>Notification</th><th>Date</th></tr>");
        parsedNotifications.forEach((n) => {
            printWindow.document.write(`<tr><td>${n.message}</td><td>${formatDate(n.date)}</td></tr>`);
        });
        printWindow.document.write("</table></body></html>");
        printWindow.document.close();
        printWindow.print();
    };

    return (
        <>
            <div className="content-header">
                <div className="container-fluid">
                    <div className="row mb-2">
                        <div className="col-sm-6">
                            <h1 className="m-0">Notifications</h1>
                        </div>
                        <div className="col-sm-6">
                            <ol className="breadcrumb float-sm-right">
                                <li className="breadcrumb-item">
                                    <Link to="/dashboard">Home</Link>
                                </li>
                                <li className="breadcrumb-item active">Notifications</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <div className="container-fluid">
                <div className="card">
                    <div className="card-header">
                        <h3 className="card-title text-sm">Notifications
                        <span
                    hover-tooltip="Here you can view all the notification."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>

                        </h3>
                        <div className="card-tools">
                            <button type="button" className="btn btn-tool" data-card-widget="maximize">
                                <i className="fas fa-expand"></i>
                            </button>
                        </div>
                    </div>
                    <div className="card-body">
                        <div className="d-flex justify-content-between mb-2">
                            <div>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                                <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                            </div>
                            <input
                                type="text"
                                className="form-control form-control-sm w-25"
                                placeholder="Search..."
                                onChange={(e) => {
                                    setSearchText(e.target.value);
                                    setCurrentPage(1);
                                }}
                            />
                        </div>

                        <table className="table table-sm table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th className="text-center">Sr. No.</th>
                                    <th>Notification</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {currentRows.length > 0 ? (
                                    currentRows.map((notif, index) => (
                                        <tr key={index}>
                                            <td className="text-center">{indexOfFirstRow + index + 1}</td>
                                            <td>{notif.message.replace(/}/, ".")}</td>
                                            <td>{formatDate(notif.date)}</td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="3" className="text-center">No notifications</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>

                        <div className="d-flex justify-content-between mt-3">
                            <div>
                                Showing {indexOfFirstRow + 1} to {Math.min(indexOfLastRow, filtered.length)} of {filtered.length} entries
                            </div>
                            <div>
                                <button
                                    className="btn btn-xs btn-outline-primary"
                                    onClick={() => handlePageChange(currentPage - 1)}
                                    disabled={currentPage === 1}
                                >
                                    <i className="fas fa-angle-double-left"></i>
                                </button>
                                <span className="mx-2">
                                    Page {currentPage} of {totalPages}
                                </span>
                                <button
                                    className="btn btn-xs btn-outline-primary"
                                    onClick={() => handlePageChange(currentPage + 1)}
                                    disabled={currentPage === totalPages}
                                >
                                    <i className="fas fa-angle-double-right"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <ToastContainer position="top-center" />
        </>
    );
}

export default Notifications;
