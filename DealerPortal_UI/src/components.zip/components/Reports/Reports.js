import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import ExcelJS from "exceljs";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { saveAs } from "file-saver";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import $ from "jquery";
import "./reports.css";

function Reports() {
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [locations, setLocations] = useState([]);
  const [allEmpSalaryData, setAllEmpSalaryData] = useState([]);
  const [showDownloadBtn, setShowDownloadBtn] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(false);

  const [location, setLocation] = useState("");
  const [version, setVersion] = useState("");
  const [selectedVersion, setSelectedVersion] = useState("");

  const [show, setShow] = useState(true);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState("");


  const [allCounts, setAllCounts] = useState("");
  const [wageAmount, setWageAmount] = useState("");
  const [salaryPayout, setSalaryPayout] = useState("");
  const [tax, setTax] = useState("");
  const [pf, setPf] = useState("");
  const [esic, setEsic] = useState("");

  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [statementshow, setStatementShow] = useState(false);
  const personalInfo = useSelector((state) => state.personalInformationReducer);

  // Define the array with the property names
  const headers = [
    { heading: "Employee Id", formula: "" },
    { heading: "Employee Name", formula: "" },
    { heading: "Employee Email", formula: "" },
    { heading: "Date of joining", formula: "" },
    { heading: "Gender", formula: "" },
    { heading: "Department Name", formula: "" },
    { heading: "Designation", formula: "" },
    { heading: "Location", formula: "" },
    { heading: "Pan Card", formula: "" },
    { heading: "Buiseness Unit", formula: "" },
    { heading: "Payment Mode", formula: "" },
    { heading: "Bank Name", formula: "" },
    { heading: "Account Number", formula: "" },
    { heading: "IFSC Code", formula: "" },
    { heading: "Branch Name", formula: "" },
    { heading: "working Days", formula: "Total working days in month" },
    {
      heading: "Effective Working Days",
      formula: "Employee present working days",
    },
    { heading: "Total Days", formula: "Total days in month" },
    {
      heading: "ESI",
      formula:
        "If employee fixed gross salary is less than 21000 then it calculated as 75% (It will vary accordig to slab) of fixed gross salary",
    },
    {
      heading: "Empoyeer Esi",
      formula: "Employeer ESI is calculate as ((75% of Esi) * 3.25)",
    },
    { heading: "ER-PF", formula: "ER-PF is equals to PF" },
    {
      heading: "Total Tax",
      formula:
        "Total tax is calculated using Employee selected slab and if slab is not selected then default new slab will be applied",
    },
    { heading: "Generated Date", formula: "" },
    { heading: "Payslip Generated Date", formula: "" },
    {
      heading: "Monthly CTC",
      formula:
        "Monthly CTC is calculated using the formula = (Annucal CTC - Employee IT Declaration Amount) / 12",
    },
    {
      heading: "Special Allowance",
      formula:
        "Special Allowance = A fixed percentage on total gross salary which was defined in assigned payroll template",
    },
    { heading: "Total Gross", formula: "Total Gross = CTC - PF" },
    { heading: "Basic Salary", formula: "Basic Salary = Total Gross / 2" },
    {
      heading: "HRA",
      formula:
        "HRA = A fixed percentage on total gross salary which was defined in assigned payroll template",
    },
    {
      heading: "Fixed Gross",
      formula: "Fixed Gross = Total Gross (Without cutting any tax)",
    },
    {
      heading: "PF",
      formula:
        "For Experience : PF = Min(1800 * (12% of (Special Allowance + Basic Salary)) and For Freshers : PF = Min(1800 * (12% of (Basic Salary))",
    },
    {
      heading: "PT",
      formula:
        "If monthly CTC is Greater than 25000 then PT is applicable and the amount is mentioned assigned payroll template",
    },
    { heading: "Total Deduction", formula: "Total Deduction = PF + PT + ESI" },
    {
      heading: "Net Salary",
      formula: "Net Salary = Total Gross - Total Deduction",
    },
    {
      heading: "Previous Month Salary",
      formula: "Shows previous month employee salary",
    },
    { heading: "LOP", formula: "" },
    { heading: "Total Days In Month", formula: "" },
    { heading: "Total Working Days", formula: "" },
    { heading: "Extra Deduction", formula: "" },
    { heading: "Bonus", formula: "" },
    { heading: "Difference between Prev & Current month Salary", formula: "" },
    { heading: "HR Remark", formula: "" },
  ];
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  useEffect(() => {
    GetLocations();
    GetAllCounts();
    window.initDatePickerFuncation();
    window.$("#dateV").datetimepicker({
      format: "MM-YYYY",
      minDate: new Date(2016, 0),
      viewMode: "months",
      maxDate: new Date(),
    });
    window.$("#dateV").on("change.datetimepicker", () => {});
  }, []);

  const GetLocations = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}LocationMaster/GetAllLocations`
      );
      const appsArray = response.data.data || [];
      setLocations(appsArray);
      // console.log("all location-->", appsArray);
    } catch (error) {
      console.error("Error fetching locations:", error);
      toast.error("Error fetching locations");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllCounts = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}Payroll/GetGeneratedPayrollTotalCounts`
      );
      // console.log("data", response.data.data);
      const appsArray = response.data.data || [];
      setAllCounts(appsArray);
    } catch (error) {
      toast.error("Error fetching data");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const pdfRef = useRef(null);
  const generatePDF = () => {
    const input = pdfRef.current;
    if (!input) {
      console.error("pdfRef is null");
      return;
    }

    html2canvas(input).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF("p", "mm", "a4");
      const imgWidth = 190;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      pdf.addImage(imgData, "PNG", 10, 10, imgWidth, imgHeight);
      pdf.save("payroll_overview.pdf");
    });
  };

  const downloadExcel = async () => {
    setIsLoaderActive(true);
    var temp = allEmpSalaryData;
    // console.log("allEmpSalaryData-->", allEmpSalaryData);

    temp = temp.map((emp) => ({
      ...emp, // Spread the existing attributes
      empId: emp.empId.toString(),
      year: selectedYear,
      month: selectedMonth, // Add the new attribute with its value
      createdBy: personalInfo.userID,
    }));

    // console.log("temp-->", temp);

    try {
      const response = await axios.post(
        `${config.apiEndPoint}/Payroll/AddEmployeesToPaymentProcessNew`,
        temp,
        {
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
        }
      );

      // console.log("API Response:", response.data);

      // ✅ Fix: Change the condition to match API response
      if (response.data?.success == "True") {
        const workbook = new ExcelJS.Workbook();
        const sheet = workbook.addWorksheet("Salary Structure");

        // ✅ Fix: Define headers correctly before using them
        const headers = [
          "empId",
          "year",
          "month",
          "generatedDate",
          "payslipGeneratedDate",
          "buisenessUnit",
          "paymentMode",
          "bankName",
          "accNumber",
          "ifscCode",
          "branchName",
          "workingDays",
          "effectiveWorkingDays",
          "lop",
          "totalDaysInMonth",
          "totalWorkingDays",
          "totalDays",
          "totalTax",
          "monthlyCtc",
          "special_allowance",
          "total_Gross",
          "basic_salary",
          "hra",
          "fixed_Gross",
          "pf",
          "pt",
          "esi",
          "empoyeerEsi",
          "erpf",
          "total_deduction",
          "net_sal",
          "createdBy",
          "bonus",
          "extraDeduction",
          "diffBetweenCurAndPrevMonthSalary",
          "previous_Month_Salary",
          "hrRemark",
        ];

        // ✅ Fix: Add the headers to the Excel sheet
        const headerRow = sheet.addRow(headers);
        headerRow.eachCell((cell) => {
          cell.fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FFFF00" }, // Yellow background
          };
          cell.font = {
            color: { argb: "FF0000" }, // Red text
            bold: true,
          };
        });

        // ✅ Fix: Ensure correct data is added to rows
        temp.forEach((emp) => {
          const row = headers.map((header) => {
            // console.log(`emp[${header}] --->`, emp[header]);
            return emp[header] || "";
          });
          sheet.addRow(row);
        });

        // Create the Excel file
        const buffer = await workbook.xlsx.writeBuffer();

        // Trigger download in the browser
        const blob = new Blob([buffer], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });

        const link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = "EmployeeSalaryData.xlsx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link); // Cleanup
        // handleDownloadClick();
        setIsLoaderActive(false);
      } else {
        console.error("Payroll processing failed:", response.data);
        toast.error("Payroll processing failed.");
        setIsLoaderActive(false);
      }
    } catch (error) {
      console.error("API call failed:", error.response?.data || error);
      toast.error("Failed to create employee data.");
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleDownloadClick = async (locationId) => {
    const date = window.$("#dateV").val();
    const [month, year] = date.split("-");
    setSelectedMonth(month);
    setSelectedYear(year);
    // console.log("location--->", location);
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Pdf/generateSalaryStructure?locationId=${locationId}&month=${month}&year=${year}`
      );
      // console.log("reponse---->", response);

      if (response.data.status == "True") {
        if (response.data.data) {
          const salaryData = response.data.data;
          console.log("salary data--->",salaryData);
          setAllEmpSalaryData(response.data.data);
          setVersion(response.data.version); // this is total version count
          setSelectedVersion(response.data.version);
          setIsLoaderActive(false);
          setShowDownloadBtn(true);
          let totalPF = 0;
          let totalNetSal = 0;
          let totalESI = 0;
          let tax = 0;
          let esic = 0;


          salaryData.forEach(element => {
            totalPF += element.pf;
            totalNetSal += element.net_sal;
            totalESI += element.esi;
            tax += element.totalTax;
            esic += element.esi;
          });

          setAllCounts(salaryData.length);
          setPf(totalPF || 0);
          setWageAmount(totalNetSal+tax+totalPF+esic || 0);
          setSalaryPayout(totalNetSal || 0);
          setEsic(esic || 0);
          setTax(tax || 0);

          return true;
        } else {
          setAllEmpSalaryData([]);
          toast.success("No data found");
          return false;
        }
      } else {
        toast.error("data not found");
        setIsLoaderActive(false);
        return false;
      }
    } catch (error) {
      // alert(error.response.data);
      toast.error(error.response.data);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };
  const handlelocationClick = async (e) => {
    const selectedlocation = e.target.value;
    const check = await handleDownloadClick(e.target.value);
    if (check) {
      // alert(check);

      setLocation(selectedlocation);
    }
  };
  const handleEditClick = (employeeData, index) => {
    setSelectedIndex(index);
    setSelectedEmployee(employeeData);
    // console.log("editempdata-->", employeeData);
    setShowModal(true);
    setTimeout(() => {
      $('input[name="previous_Month_Salary"]').prop("disabled", true);
      $('input[name="diffBetweenCurAndPrevMonthSalary"]').prop(
        "disabled",
        true
      );

      // When net_sal changes
      $(document).on("keyup", "input[name='net_sal']", function () {
        const netSal = parseFloat($(this).val()) || 0;
        const prevSal =
          parseFloat($('input[name="previous_Month_Salary"]').val()) || 0;
        const diff = Math.abs(prevSal - netSal);

        $('input[name="diffBetweenCurAndPrevMonthSalary"]').val(
          diff.toFixed(2)
        );
      });
    }, 1000);
  };
  const handleModalClose = () => {
    setShowModal(false);
    setSelectedEmployee(null);
  };
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelectedEmployee({ ...selectedEmployee, [name]: value });
  };
  const handleUpdate = async () => {
    allEmpSalaryData[selectedIndex] = selectedEmployee;
    setShowModal(false);
  };
  const handleVersionClick = async (e) => {
    const selectedVersion = e.target.value;
    try {
      const date = window.$("#dateV").val();
      const [month, year] = date.split("-");
      setSelectedMonth(month);
      setSelectedYear(year);
      // console.log("location--->", location);
      setIsLoaderActive(true);

      const response = await axios.get(
        `${config.apiEndPoint}/Pdf/getEmployeeSalaryDataByVersion?locationId=${location}&month=${month}&year=${year}&version=${selectedVersion}`
      );
      // console.log("reponse---->", response);

      if (response.data.status == "True") {
        if (response.data.data) {
          setAllEmpSalaryData(response.data.data);
          let salaryData = response.data.data;

          let totalPF = 0;
          let totalNetSal = 0;
          let totalESI = 0;
          let tax = 0;
          let esic = 0;


          salaryData.forEach(element => {
            totalPF += element.pf;
            totalNetSal += element.net_sal;
            totalESI += element.esi;
            tax += element.totalTax;
            esic += element.esi;
          });

          setAllCounts(salaryData.length);
          setPf(totalPF || 0);
          setWageAmount(totalNetSal+tax+totalPF+esic || 0);
          setSalaryPayout(totalNetSal || 0);
          setEsic(esic || 0);
          setTax(tax || 0);

          if (selectedVersion == version) {
           
            setShowDownloadBtn(true);
          } else {
           
            setShowDownloadBtn(false);
          }
          setIsLoaderActive(false);
        } else {
          setAllEmpSalaryData([]);
          toast.success("No data found");
          setIsLoaderActive(false);
        }
      } else {
        toast.error("data not found");
        setIsLoaderActive(false);
      }
    } catch {
      toast.error("error while fetching data");
    } finally {
      setIsLoaderActive(false);
    }
    setSelectedVersion(selectedVersion);
  };
  const handledeleteClick = async (index) => {
    setAllEmpSalaryData((prevData) => prevData.filter((_, i) => i !== index));
  };

  return (
    <>
      <main id="main" className="addAssignee">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">
                  Reports
                  <span
                    hover-tooltip="In this you can view and download the salary structure by selecting the required deptartment and clicking on required month."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/employee-dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">Reports</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        {/* <div className="container-fluid px-3">
          <div class="row">
            <div class="col-12 col-sm-6 col-md-4">
              <div
                class="info-box reportcard"
                onClick={() => {
                  setShow(true);
                  setStatementShow(false);
                }}
                style={{ cursor: "pointer" }}
              >
                <span class="info-box-icon bg-primary elevation-1">
                  <div
                    className=""
                    style={{
                      position: "relative",
                      display: "inline-block",
                    }}
                  >
                    <i className="fas fa-money-check-alt" />
                    <i
                      className="fas fa-rupee-sign"
                      style={{
                        position: "absolute",
                        color: "#007bff",
                        backgroundColor: "white",
                        top: "50%",
                        left: "26%",
                        transform: "translate(-50%, -50%)",
                        fontSize: "15px",
                      }}
                    />
                  </div>
                </span>
                <div class="info-box-content">
                  <span class="text-bold text-md">
                    Generate Salary Structure
                  </span>
                </div>
              </div>
            </div>
            <div
              class="col-12 col-sm-6 col-md-4"
              style={{ pointer: "cursor" }}
              onClick={() => {
                setStatementShow(true);
                setShow(false);
              }}
            >
              <div
                class="info-box reportcard"
                style={{ cursor: "not-allowed" }}
              >
                <span class="info-box-icon bg-danger elevation-1">
                  <i class="fas fa-file-invoice"></i>
                </span>
                <div class="info-box-content">
                  <span class="text-bold text-md">Statement</span>
                </div>
              </div>
            </div>
          </div>
        </div> */}

        {show && (
          <>
            <div className="container-fluid px-3">
              <div className="row">
                <div className="col-md-12">
                  <div className="card card-outline card-primary">
                    <div className="card-header">
                      <div className="row">
                        <div className="col-md-6">
                          {showDownloadBtn == true ? (
                            <>
                              {isLoaderActive ? (
                                <PleaseWaitButton className="btn-xs font-weight-medium auth-form-btn" />
                              ) : (
                                <button
                                  className="btn btn-primary btn-xs"
                                  onClick={downloadExcel}
                                >
                                  <i className="fas fa-download mr-1"></i>{" "}
                                  Process & Download Salary Structure For
                                  Academic Year {selectedYear}{" "}
                                  {" " + monthNames[selectedMonth - 1]}
                                </button>
                              )}
                            </>
                          ) : (
                            <h3 className="card-title mt-1">Reports</h3>
                          )}
                        </div>

                        <div className="col-md-6 row d-flex align-items-center">
                          {/* Date Picker */}
                          <div
                            className="input-group col-md-3"
                            id="year"
                            data-target-input="nearest"
                          >
                            <input
                              type="text"
                              className="form-control form-control-sm"
                              id="dateV"
                              defaultValue={`${String(
                                new Date().getMonth() + 1
                              ).padStart(2, "0")}-${new Date().getFullYear()}`}
                              placeholder="Select Month"
                              data-target="#dateV"
                            />
                            <div
                              className="input-group-append"
                              custDatePicker
                              data-target="#dateV"
                              data-toggle="datetimepicker"
                            >
                              <div className="input-group-text">
                                <i className="fa fa-calendar"></i>
                              </div>
                            </div>
                          </div>
                          {/* Version Selector */}
                          <div className="col-md-4">
                            <select
                              className="form-control form-control-sm"
                              id="userRoleNameInput"
                              value={selectedVersion}
                              onChange={(e) => handleVersionClick(e)}
                              aria-label="Filter by location"
                            >
                              <option value="" disabled>
                                --Select Version--
                              </option>
                              {Array.from({ length: version }, (_, index) => (
                                <option key={index + 1} value={index + 1}>
                                  Version {index + 1}
                                </option>
                              ))}
                            </select>
                          </div>
                          {/* location Selector */}
                          <div className="col-md-4">
                            <select
                              className="form-control form-control-sm"
                              id="userRoleNameInput"
                              value={location}
                              onChange={handlelocationClick}
                              aria-label="Filter by location"
                            >
                              <option value="" disabled>
                                --Select Locations--
                              </option>
                              {locations.map((role) => (
                                <option
                                  key={role.locationID}
                                  value={role.locationID}
                                >
                                  {role.locationName}
                                </option>
                              ))}
                            </select>
                          </div>

                          {/* Maximize Button */}
                          <button
                            type="button"
                            className="btn btn-tool"
                            data-card-widget="maximize"
                            aria-label="Maximize card"
                          >
                            <i className="fas fa-expand" aria-hidden="true"></i>
                          </button>
                        </div>
                      </div>
                    </div>

                    <div
                      className="card-body position-relative"
                      style={{ position: "relative" }}
                    >
                      {isLoaderActive && (
                        <div
                          style={{
                            position: "absolute",
                            top: 0,
                            left: 0,
                            width: "100%",
                            height: "100%",
                            backgroundColor: "rgb(233 236 239 / 81%)",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            zIndex: 10,
                          }}
                        >
                          <i
                            className="fas fa-sync-alt fa-spin"
                            style={{ fontSize: "2rem", color: "#333" }}
                          ></i>
                        </div>
                      )}
                      {location && (
                        <>
                          <div className="row px-2">
                          {version ? (
                              <>
                                <div className="col-md-12">
                                  <div className="card-header p-0">
                                    <h3 className="card-title mb-2">
                                      Payroll Data Overview
                                    </h3>
                                  </div>
                                  {statementshow && (
                                    <div className="card-tools row d-flex align-items-center">
                                      <button
                                        type="button"
                                        className="btn btn-sm btn-secondary mr-2"
                                        onClick={GetAllCounts} // Refresh Data
                                      >
                                        <i className="fas fa-sync-alt"></i>
                                      </button>
                                      <button
                                        type="button"
                                        className="btn btn-sm btn-secondary"
                                        onClick={generatePDF} // Generate PDF
                                      >
                                        <i className="fas fa-print"></i>
                                      </button>
                                    </div>
                                  )}
                                </div>
                                <div
                                  className="col-md-12"
                                  ref={pdfRef}
                                  style={{ border: "1px solid #ccc" }}
                                >
                                  <p className="mt-2">
                                    You are viewing the payroll overview of the
                                    previous salary cycle.
                                  </p>
                                  <div className="row flex-nowrap overflow-auto">
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-user-friends  m-2" />
                                          <strong>
                                            {allCounts}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          Employee Count
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-money-bill-wave  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(
                                              // allCounts.totalSalary +
                                              //   allCounts.totaltax +
                                              //   allCounts.totalPf +
                                              //   allCounts.totalEsic +
                                              //   allCounts.totalpt

                                              wageAmount
                                            )}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          Wage Amount
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-credit-card  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(salaryPayout)}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          Salary Payout
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-university  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(tax)}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          Tax Payment
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-landmark  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(pf)}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          PF Employee
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-hospital  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(esic)}
                                          </strong>
                                        </span>
                                        <span className="text-muted">
                                          ESIC Employee
                                        </span>
                                      </p>
                                    </div>
                                    <div className="col-md-2 text-center card border border-300 pb-0">
                                      <p className="d-flex flex-column align-items-center pt-2">
                                        <span>
                                          <i className="fas fa-file-invoice-dollar  m-2" />
                                          <strong>
                                            {new Intl.NumberFormat("en-IN", {
                                              style: "currency",
                                              currency: "INR",
                                            }).format(allCounts.totalpt)}
                                          </strong>
                                        </span>
                                        <span className="text-muted">PT</span>
                                      </p>
                                    </div>
                                  </div>
                                </div>{" "}
                              </>
                           ) : null}

                            <table className="table table-bordered table-responsive  mt-4">
                              <thead className="thead text-nowrap">
                                <tr>
                                  <th className="sticky-column left-0">
                                    Action
                                  </th>
                                  {headers.map((header, index) => (
                                    <th
                                      key={index}
                                      className={
                                        index === 0
                                          ? "sticky-column left-1"
                                          : index === 1
                                          ? "sticky-column left-2"
                                          : index === 2
                                          ? " left-3"
                                          : ""
                                      }
                                    >
                                      {" "}
                                      {header.heading.replace(
                                        /([a-z])([A-Z])/g,
                                        "$1 $2"
                                      )}
                                      {header.formula != "" ? (
                                        <span
                                          hover-tooltip={header.formula}
                                          tooltip-position="bottom"
                                        >
                                          <i
                                            className="fas fa-info-circle"
                                            style={{
                                              marginLeft: "5px",
                                              cursor: "pointer",
                                              zIndex: 1234,
                                              color: "rgb(0 0 0 / 51%)",
                                            }}
                                          ></i>
                                        </span>
                                      ) : null}
                                    </th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody className="text-nowrap">
                                {allEmpSalaryData.map((data, index) => (
                                  <tr key={index}>
                                    <td className="sticky-column left-0">
                                      <button
                                        type="button"
                                        className="btn bg-gradient-warning btn-xs"
                                        onClick={() =>
                                          handleEditClick(data, index)
                                        }
                                      >
                                        <i className="fas fa-pen"></i>
                                      </button>

                                      <button
                                        type="button"
                                        className="btn bg-gradient-danger btn-xs ml-2"
                                        onClick={() => handledeleteClick(index)}
                                      >
                                        <i className="fas fa-trash"></i>
                                      </button>
                                    </td>
                                    {Object.values(data).map((value, idx) => (
                                      <td
                                        key={idx}
                                        className={
                                          idx === 0
                                            ? "sticky-column left-1"
                                            : idx === 1
                                            ? "sticky-column left-2"
                                            : idx === 2
                                            ? " left-3"
                                            : ""
                                        }
                                      >
                                        {value}
                                      </td>
                                    ))}
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {showModal && selectedEmployee && (
          <div
            className="modal fade show"
            style={{
              display: "block",
              boxShadow: "#5d5858b8",
              backgroundColor: "#5d5858b8",
            }}
            tabIndex="-1"
          >
            <div className="modal-dialog modal-xl modal-dialog-centered">
              <div className="modal-content">
                <div className="modal-header p-3">
                  <h5 className="mb-0">Edit Employee Salary Data</h5>
                  <button
                    type="button"
                    onClick={handleModalClose}
                    className="close"
                  >
                    <span>&times;</span>
                  </button>
                </div>
                <div
                  className="modal-body"
                  style={{ overflowY: "auto", height: "500px" }}
                >
                  <form>
                    <div className="row">
                      {Object.keys(selectedEmployee).map((key, index) => {
                        let value = selectedEmployee[key];

                        if (
                          (key == "payslipGeneratedDate" ||
                            key == "generatedDate") &&
                          value
                        ) {
                          const date = new Date(value);
                          value = selectedEmployee[key] || "";
                        }
                        const label = key
                          .replace(/([a-z])([A-Z])/g, "$1 $2")
                          .replace(/_/g, " ");
                        const capitalizedLabel =
                          label.charAt(0).toUpperCase() + label.slice(1);

                        return (
                          <div key={index} className="form-group col-md-4">
                            <label>{capitalizedLabel}</label>
                            <input
                              type="text"
                              name={key}
                              value={value}
                              onChange={handleInputChange}
                              className="form-control"
                            />
                          </div>
                        );
                      })}
                    </div>
                  </form>
                </div>
                <div className="modal-footer d-flex justify-content-between px-3 py-2">
                  <button
                    type="button"
                    className="btn btn-default btn-xs"
                    onClick={handleModalClose}
                  >
                    Close
                  </button>
                  {isLoaderActive ? (
                    <PleaseWaitButton className="float-right btn-xs font-weight-medium auth-form-btn" />
                  ) : (
                    <button
                      type="button"
                      className="btn btn-primary btn-xs"
                      onClick={handleUpdate}
                    >
                      Update
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        <ToastContainer position="top-center" />
      </main>
    </>
  );
}

export default Reports;
