import React, { useEffect, useState } from "react";
import $ from "jquery";
import "orgchart/dist/js/jquery.orgchart.js";
import "orgchart/dist/css/jquery.orgchart.css";
import axios from "axios";
import "./OrganizationChart.css";
import PleaseWaitButton from '../../shared/PleaseWaitButton';
import { useSelector } from 'react-redux';
import { ToastContainer, toast } from 'react-toastify';
import config from '../../config/config.json';

const OrganizationChart = () => {
  const [employeeHierarchy, setEmployeeHierarchy] = useState({
    id: "0",
    name: "",
    title: "",
    email: "",
    department: "",
    children: [],
  });
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [employees, setEmployees] = useState([]);
  const [filteredEmployee, setFilteredEmployee] = useState([]);
  const [ocInstance, setOcInstance] = useState(null);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [selectedDepartment, setSelectedDepartment] = useState("");
  const [departments, setDepartments] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchEmployees();
    fetchDepartments();
  }, []);

  const fetchEmployees = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/EmployeeData/GetAllEmployees`
      );
      if (response.data.success === "True") {
        if (response.data.data) {
          setEmployees(response.data.data || []);
          setFilteredEmployee(response.data.data || []);
        }
      } else {
        setEmployees([]);
        setFilteredEmployee([]);
      }
    } catch (error) {
      console.error("Error fetching employee data:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const fetchDepartments = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/Department/GetAllDepartments`
      );
      if (response.data.success === "True") {
        setDepartments(response.data.data || []);

      } else {
        console.error("Failed to fetch departments:", response.data.message);
      }
    } catch (error) {
      console.error("Failed to fetch department data:", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  useEffect(() => {
    if (!selectedDepartment) {
      $("#chart-container").empty(); // Clear chart if no department is selected
      return;
    }

    // Clear the chart container to avoid duplicate rendering
    $("#chart-container").empty();

    // Create a new orgchart instance with the updated hierarchy
    const newOc = $("#chart-container").orgchart({
      data: employeeHierarchy,
      nodeContent: "title",
      draggable: true,
      createNode: ($node, data) => {
        // console.log(data, "Dataa");

        const deptName = data ? departments.find((t) => t.departmentID == data.department) : null;
        const department = deptName ? deptName.departmentName : "N/A";

        const contentHtml = `
          <div class="title text-wrap">
            <p class="nodeName text-wrap mb-0"> ${data.name || "N/A"}</p>
            <p class="nodeTitle mb-0">(${data.title || "No Title"})</p>            
            <p class="nodeId text-wrap mb-0">Emp ID: ${data.id || "N/A"}</p>
          </div>
          <div class="content text-wrap">
            <p class="nodeMail text-nowrap mb-0 px-2" title=${data.email}>Email: ${data.email || "N/A"}</p>
            <p class="nodeDepartment mb-0">Dept: ${department || "N/A"}</p>
          </div>
          `;
        $node.html(contentHtml);
        $node.attr("data-id", data.id);
      },
      dropCriteria: function ($draggedNode, $dragZone, $dropZone) {
        return true; // Allow all drops
      },
    });

    // Add the nodedrop event listener
    newOc.$chart.on("nodedrop.orgchart", (event, extraParams) => {
      const draggedNodeId = extraParams.draggedNode.data("id");
      const dropZoneId = extraParams.dropZone.data("id");

      const updatedHierarchy = updateHierarchyOnDrop(
        { ...employeeHierarchy }, // Clone to avoid mutation
        draggedNodeId,
        dropZoneId
      );
      setEmployeeHierarchy(updatedHierarchy); // Update state with the new hierarchy
    });

    setOcInstance(newOc); // Update the instance reference

    // Cleanup function to clear the chart on unmount or reinitialization
    return () => {
      $("#chart-container").empty();
    };
  }, [employeeHierarchy, selectedDepartment]); // Dependencies: employeeHierarchy and selectedDepartment

  //Fetched previously stored chart is any
  useEffect(() => {
    if (selectedDepartment) {
      fetchHierarchyForDepartment(selectedDepartment);
    } else {
      setEmployeeHierarchy({
        id: "N/A",
        name: "",
        title: "",
        email: "",
        department: "",
        children: []
      });
    }
  }, [selectedDepartment]);


  // for search
  useEffect(() => {
    const filtered = employees.filter(
      (emp) =>
        emp.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        emp.empInfoId.toString().includes(searchTerm)
    );
    setFilteredEmployee(filtered);
  }, [searchTerm]);

  const fetchHierarchyForDepartment = async (deptId) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AdminFormFormat/GetOrganizationChartJsonData?deptId=${deptId}`
      );
      //console.log("respinse------>",response);
      if (
        response.data.success === "True" &&
        response.data.data?.orgChartjsonData
      ) {
        // console.log("Raw saved data -->>", response.data.data.orgChartjsonData)
        const hierarchyData = JSON.parse(response.data.data.orgChartjsonData);
        // console.log("org chart:-", hierarchyData);
        setEmployeeHierarchy(hierarchyData);
      } else {
        setEmployeeHierarchy({
          id: "0",
          name: "",
          title: "",
          email: "",
          department: "",
          children: [],
        });
      }
    } catch (error) {
      console.error("Failed to fetch department hierarchy:", error);
      setEmployeeHierarchy({
        id: "0",
        name: "",
        title: "",
        email: "",
        department: "",
        children: [],
      });
    }
  };

  const handleSaveHierarchy = async () => {

    if (!selectedDepartment) {
      toast.error("Please select a department to save the hierarchy.");
      return;
    }
    setIsLoaderActive(true);

    try {
      if (employeeHierarchy.length === 0) {
        toast.error("Hierarchy is empty. Please assign employees.");
        return;
      }

      // console.log("DepartmentID: ", selectedDepartment);
      const payload = {
        DepartmentId: parseInt(selectedDepartment, 10),
        jsonData: JSON.stringify(employeeHierarchy),
        createdBy: personalInfo.userID,
      };

      // console.log(
      //   "Payload being sent to PostOrganizationChartJsonData:",
      //   payload
      // );
      const sol = [employeeHierarchy];
      // console.log("savinggg  --- ", sol);
      await axios.post(
        `${config.apiEndPoint}/AdminFormFormat/PostOrganizationChartJsonData`,
        payload
      );
      // await axios.post('https://localhost:7243/api/EmployeeData/postEmployeeToEmployeeMapping', sol);

      setEmployees(filteredEmployee);
      // alert("Hierarchy saved successfully!");
      toast.success("Hierarchy saved successfully!");
      setEmployeeHierarchy([]);
      setSelectedDepartment('');
    } catch (error) {
      console.error("Failed to save hierarchy:", error);
      // alert("Failed to save hierarchy.");
      toast.error("Failed to save hierarchy.");
    } finally {
      setIsLoaderActive(false);
    }
  };

  // Recursive function to update hierarchy after a drop (dragging within hierarchy)
  const updateHierarchyOnDrop = (node, draggedNodeId, dropZoneId) => {
    if (!node) return null;

    // Find and remove the dragged node from its current location
    if (node.id === draggedNodeId) {
      return null;
    }

    // If the current node is the drop zone, add the dragged node as its child
    if (node.id === dropZoneId) {
      const draggedNode = findNodeById(employeeHierarchy, draggedNodeId);
      if (draggedNode) {
        node.children = node.children || [];
        // Add only if it doesn't already exist
        if (!node.children.some((child) => child.id === draggedNode.id)) {
          node.children.push({ ...draggedNode, children: [] }); // Reset children of the dragged node
        }
      }
      return node;
    }

    // Recursively update children
    if (node.children) {
      node.children = node.children
        .map((child) => updateHierarchyOnDrop(child, draggedNodeId, dropZoneId))
        .filter((child) => child !== null); // Remove the dragged node if found
    }

    return node;
  };

  // Helper function to find a node by ID
  const findNodeById = (node, id) => {
    if (node.id === id) return node;
    if (node.children) {
      for (let child of node.children) {
        const foundNode = findNodeById(child, id);
        if (foundNode) return foundNode;
      }
    }
    return null;
  };

  // Handle adding new employees from the list
  // const handleDrop = (event) => {
  //   if (!selectedDepartment) {
  //     toast.error("Please select a department first to assign manager.");
  //     return;
  //   }
  //   const draggedId = event.dataTransfer.getData("text");
  //   const draggedEmployee = employees.find(
  //     (emp) => emp.empId.toString() === draggedId
  //   );

  //   if (draggedEmployee) {
  //     // Add the new employee as a child under the root node initially
  //     setEmployeeHierarchy((prevHierarchy) => ({
  //       ...prevHierarchy,
  //       children: [
  //         ...prevHierarchy.children,
  //         {
  //           id: draggedEmployee.empInfoId,
  //           name: draggedEmployee.firstName,
  //           title: draggedEmployee.designation,
  //           email: draggedEmployee.email,
  //           department: draggedEmployee.department,
  //           children: [],
  //         },
  //       ],
  //     }));

  //     // Remove the employee from the empList
  //     //setEmployees(employees.filter(emp => emp.empId.toString() !== draggedId));
  //     setFilteredEmployee((prevList) =>
  //       prevList.filter((emp) => emp.empId.toString() !== draggedId)
  //     );
  //   }
  // };
  const handleDrop = (event) => {
    if (!selectedDepartment) {
      toast.error("Please select a department first to assign manager.");
      return;
    }
 
    const draggedId = event.dataTransfer.getData("text");
    const draggedEmployee = employees.find(
      (emp) => emp.empId.toString() === draggedId
    );
 
    if (draggedEmployee) {
      setEmployeeHierarchy((prevHierarchy) => {
        // If hierarchy is empty, make the dragged employee the root node
        if (!prevHierarchy || prevHierarchy.id === "0") {
          return {
            id: draggedEmployee.empInfoId,
            name: draggedEmployee.firstName,
            title: draggedEmployee.designation,
            email: draggedEmployee.email,
            department: draggedEmployee.department,
            children: [],
          };
        }
 
        // Otherwise, add the employee as a child to the root node
        return {
          ...prevHierarchy,
          children: [
            ...prevHierarchy.children,
            {
              id: draggedEmployee.empInfoId,
              name: draggedEmployee.firstName,
              title: draggedEmployee.designation,
              email: draggedEmployee.email,
              department: draggedEmployee.department,
              children: [],
            },
          ],
        };
      });
 
      // Remove the employee from the unassigned list
      setFilteredEmployee((prevList) =>
        prevList.filter((emp) => emp.empId.toString() !== draggedId)
      );
    }
  };
 

  return (
    <>
      <div className="container-fluid p-3">
        <div className="chartMainContainer card card-outline card-primary">
          <div className="smdMainContainer">
            <div className="chartBox">
              <div className="card-header p-2">
                <h4 className="card-title text-md mt-1">Organization Chart</h4>
                <div className="row float-right d-flex" style={{ justifyContent: 'space-between' }}>
                  <div className="col-md-7 ml-4">
                    <select
                      className="form-control form-control-sm"
                      value={selectedDepartment}
                      onChange={(e) => setSelectedDepartment(e.target.value)}
                    >
                      <option value="">Select Department</option>
                      {departments.map((dept) => (
                        <option key={dept.departmentID} value={dept.departmentID}>
                          {dept.departmentName}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="card-tool">
                    {isLoaderActive ? <PleaseWaitButton className='btn-sm font-weight-medium auth-form-btn' /> :
                      <button className="btn btn-primary btn-sm" onClick={handleSaveHierarchy}>
                        Save Chart
                      </button>
                    }
                    <button type="button" className="btn btn-tool" data-card-widget="maximize">
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>

              </div>
              <div
                className="chart mb-2"
                id="chart-container"
                onDragOver={(e) => e.preventDefault()} // Allow drop
                onDrop={handleDrop} // Handle drop from employee list
              />
            </div>
            <div className="empListContainer">
              <div className="card-header px-2 py-2" style={{ borderBottom: 'none' }}>
                <h2 className="card-title text-md mb-1">
                  Unassigned Employees
                </h2>
                <br />
                <h5 className="card-title text-sm text-nowrap">Assign manager using drag and drop</h5>
              </div>
              <div className="card-body px-0 pt-0">
                <div className='searchContainer mx-2 p-1 mb-2 '>
                  <input
                    type="search"
                    placeholder="Search employees..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="search-bar"
                  />
                  <i className="fas fa-search"></i>
                </div>
                <div className="empList">
                  <ol className="sortable">
                    {isLoaderActive && (
                      <div className="overlay dark">
                        <i className="fas fa-3x fa-sync-alt"></i>
                      </div>
                    )}
                    {filteredEmployee.map((item) => (
                      <li
                        className="employeeCard m-2"
                        key={item.empId}
                        data-id={item.empId}
                        draggable="true"
                        onDragStart={(e) =>
                          e.dataTransfer.setData("text", item.empId)
                        }
                      >
                        <div className="avtrImgContainer">
                          <img
                            src={personalInfo.profilePic}
                            alt="employeeAvatar"
                            className="employeeAvatar img-fluid"
                          />
                        </div>
                        <div className="emp-card">
                          <p className="mb-0">{item.firstName}</p>
                          <span className="emp-id">Emp Id: {item.empInfoId}</span>
                        </div>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
};

export default OrganizationChart;