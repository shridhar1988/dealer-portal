import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import PleaseWaitButton from '../../shared/PleaseWaitButton';
import { useSelector } from "react-redux";

const config = require("../../config/config.json");

const CompanyPolicy = () => {

    const [file, setFile] = useState(null);
    const [fileURL, setFileURL] = useState(null);
    const fileInputRef = useRef(null);
    const [isLoaderActive, setIsLoaderActive] = useState(false);
    const [getPolicy, setGetPolicy] = useState([]);
    const [policyFileURL, setPolicyFileURL] = useState(null);
    const personalInfo = useSelector((state) => state.personalInformationReducer);
    // console.log('====================================');
    // console.log(personalInfo, "personalInfo");
    // console.log('====================================');

    useEffect(() => {
        GetRoles();
    }, []);

    const GetRoles = async () => {
        setIsLoaderActive(true);

        try {
            const response = await axios.get(`${config.API_URL}PrivacyPolicy/FetchPolicy`);
            // console.log(response, "response");
            if (response.data.success == "True") {
                const appsArray = response.data.data || [];
                setGetPolicy(appsArray);

                if (appsArray.length > 0) {
                    const filePath = appsArray;
                    const fileName = filePath.split('\\').pop().split('/').pop(); // Extract file name
                    setPolicyFileURL(fileName);
                }
            }
        } catch (error) {
            console.error('Error fetching file:', error);
            toast.error('Error fetching file');
        } finally {
            setIsLoaderActive(false);
        }
    };

    const handleViewPolicy = () => {
        if(policyFileURL) {
            // console.log(policyFileURL, "policyFileURL");
            const fullURL = `${config.Attachment_URL}${policyFileURL}`;
            // console.log(fullURL, "fullURL");
            window.open(fullURL, '_blank');
        } else {
            toast.error('No policy file available to view.');
        }
    };

    // const handleFileChange = (event) => {
    //     const selectedFile = event.target.files[0];
    //     if (selectedFile) {
    //         const fileName = selectedFile.name.toLowerCase();
    //         const allowedExtensions = /\.(jpg|jpeg|png|pdf)$/i;
     
    //         if (!allowedExtensions.test(fileName)) {
    //             alert("Invalid file type. Only JPG, JPEG, PNG, and PDF files are allowed.");
    //             event.target.value = ''; // Clear the input
    //             return;
    //         }
     
    //         setFile(selectedFile);
    //         setFileURL(URL.createObjectURL(selectedFile));
    //     }
    // };

    const handleFileChange = (event) => {
        const selectedFile = event.target.files[0];
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
     
        if (selectedFile && allowedTypes.includes(selectedFile.type)) {
          setFile(selectedFile);
          setFileURL(URL.createObjectURL(selectedFile));
        } else {
          toast.error('Only JPEG, JPG, PNG, and PDF files are allowed.');
          event.target.value = null; // Clear the file input
          setFileURL(null);
        }
    };

    const handleSubmit = async () => {
        fileInputRef.current.classList.remove('is-invalid');

        if(file == '' || file == null) {
            fileInputRef.current.focus();
            toast.error('Please upload the file.');
            return;
        }

        setIsLoaderActive(true);

        try {
            const formData = new FormData();
            formData.append("file", file);

            const response = await axios.post(
                `${config.API_URL}PrivacyPolicy/UploadPolicy`,
                formData,
                {
                    headers: {
                        "Content-Type": "multipart/form-data"
                    }
                }
            );
            if(response.data.success == "True") {
                toast.success(response.data.message);
                handleCancle();
            } else {
                toast.error(response.data.message);
            }
        }
        catch(error) {
            console.error("Error:", error);
            toast.error("Failed to upload file.");
        }
        finally {
            setIsLoaderActive(false);
            handleCancle();
        }
    };

    const handleCancle = () => {
        setFile(null);
        setFileURL(null);
        fileInputRef.current.classList.remove('is-invalid');
        fileInputRef.current.value = '';
    }


    return (
        <>
            <main id='main' className='addAssignee'>
                <div className="content-header">
                    <div className="container-fluid">
                        <div className="row mb-2">
                            <div className="col-sm-6">
                            {personalInfo.userRole == 'HR' ? (
                                <h1 className="m-0">Manage Privacy Policy<span
                                    hover-tooltip='In this you can manage the companies privacy policy.'
                                    tooltip-position="bottom"
                                >
                                    <i
                                        className="fas fa-info-circle my-1 ml-2"
                                        style={{ color: "rgb(0 0 0 / 51%)" }}
                                    ></i>
                                </span></h1>
                            ):(
                                <h1 className="m-0">Privacy Policy<span
                                    hover-tooltip='In this you can view the companies privacy policy.'
                                    tooltip-position="bottom"
                                >
                                    <i
                                        className="fas fa-info-circle my-1 ml-2"
                                        style={{ color: "rgb(0 0 0 / 51%)" }}
                                    ></i>
                                </span></h1>

                            )} 
                             <ol className="breadcrumb float-sm-left mt-1">
                                    <li className="breadcrumb-item"><Link to="/form-builder">Home</Link></li>
                                    <li className="breadcrumb-item active">Privacy Policy</li>
                                </ol>
                            </div>
                            <div className="col-sm-6">
                                {/* <ol className="breadcrumb float-sm-right">
                                    <li className="breadcrumb-item"><Link to="/form-builder">Home</Link></li>
                                    <li className="breadcrumb-item active">Privacy Policy</li>
                                </ol> */}
                            </div>
                        </div>
                    </div>
                </div>

                {personalInfo.userRole == 'HR' && (
                    <div className="container-fluid">
                        <div className='row'>
                            <div className="col-md-12">
                                <div className="card card-outline position-relative card-primary">
                                    {isLoaderActive && (
                                        <div
                                            style={{
                                                position: "absolute",
                                                top: 0,
                                                left: 0,
                                                width: "100%",
                                                height: "100%",
                                                backgroundColor: "rgb(233 236 239 / 81%)",
                                                display: "flex",
                                                alignItems: "center",
                                                justifyContent: "center",
                                                zIndex: 10,
                                            }}
                                        >
                                            <i
                                                className="fas fa-sync-alt fa-spin"
                                                style={{ fontSize: "2rem", color: "#333" }}
                                            ></i>
                                        </div>
                                    )}
                                    <div className="card-header">
                                        <h3 className="card-title text-sm">Upload Privacy Policy<span
                                            hover-tooltip='In this you can upload the companies privacy policy file.'
                                            tooltip-position="bottom"
                                        >
                                            <i
                                                className="fas fa-info-circle ml-2"
                                                style={{ color: "rgb(0 0 0 / 51%)" }}
                                            ></i>
                                        </span></h3>
                                        <div className="card-tools">
                                            <button type="button" className="btn btn-danger btn-xs" id='AddNewHeaderButton'
                                                data-card-widget="collapse">
                                                <i className="fas fa-plus"></i> Add New Policy
                                            </button>
                                            <button type="button" className="btn btn-tool" data-card-widget="maximize">
                                                <i className="fas fa-expand"></i>
                                            </button>
                                        </div>
                                    </div>

                                    <div className='card-body text-sm'>
                                        <div className='row'>
                                            <div className='col-md-4'>
                                                <input
                                                    type="file"
                                                    
                                                    onChange={handleFileChange}
                                                    ref={fileInputRef}
                                                />
                                            </div>
                                        </div>
                                        {file && (
                                            <div className="card-body d-flex">
                                                <iframe
                                                    src={fileURL}
                                                    style={{ width: "100%", height: "550px" }}
                                                    title="PDF Preview"
                                                ></iframe>
                                            </div>
                                        )}
                                    </div>
                                    <div className="card-footer text-sm">
                                        {isLoaderActive ? <PleaseWaitButton className='float-right btn-xs ml-2 font-weight-medium auth-form-btn' /> :
                                            <button type="submit" className="btn btn-primary float-right btn-xs ml-2" onClick={handleSubmit}>Submit</button>
                                        }
                                        <button type='button' className='btn btn-secondary btn-xs float-right' onClick={handleCancle}>Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}


                <div className="container-fluid">
                    <div className='row'>
                        <div className="col-md-12">
                            <div className="card card-outline card-primary ">
                                <div className="card-header">
                                    <h3 className="card-title text-sm">View Policy</h3>
                                    <div className="card-tools">
                                        <button type="button" className="btn btn-tool" id='listOfProjectsHeaderExpandButtion'
                                            data-card-widget="collapse">
                                            <i className="fas fa-minus"></i>
                                        </button>
                                        <button type="button" className="btn btn-tool" data-card-widget="maximize">
                                            <i className="fas fa-expand"></i>
                                        </button>
                                    </div>
                                </div>
                                <div className="card-body text-sm position-relative">
                                    <button type='button' className='btn btn-primary btn-sm' onClick={handleViewPolicy}>View Policy</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </main >
            <ToastContainer position="top-center" />

        </>
    );
};

export default CompanyPolicy;