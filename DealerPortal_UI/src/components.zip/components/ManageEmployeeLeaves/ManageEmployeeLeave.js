import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import axios from "axios";
import config from "../../config/config.json";
import { ToastContainer, toast } from "react-toastify";
import { useNavigate, Link } from "react-router-dom";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import "./ManageEmployeeLeave.css";
import { type } from "jquery";

function ManageEmployeeLeave() {
  const [allUsersList, setAllUsersList] = useState([]);
  const [leaveType, setLeaveType] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [selectedLeaveId, setSelectedLeaveId] = useState(null);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isRejectModalVisible, setIsRejectModalVisible] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const navigate = useNavigate();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;


  useEffect(() => {
    fetchAllLeavesData();
    window.initDataTable();
    GetRoles();
  }, []);

  const fetchAllLeavesData = async () => {
    // window.initDestroyDataTableFuncation();
    setIsLoaderActive(true);

    try {
      let apiEndpoint = `${config.API_URL}LeaveManagement/GetAllAppliedLeaveForHR`;

      if(personalInfo.userRole === "Manager") {
        apiEndpoint = `${config.API_URL}LeaveManagement/GetAllAppliedLeaveForManager?ManagerLoginId=${personalInfo.userID}`;
      }

      const response = await axios.get(apiEndpoint);

      if(response.data.success) {

        if(personalInfo.userRole == "HR") {
          if(response.data.data) {
            setAllUsersList(response.data.data);
            setTimeout(() => {
              window.initDataTable();
            }, 500);
          } else {
            setAllUsersList([]);
          }
        } else if(personalInfo.userRole == "Manager") {
          const filteredUsers = response.data.data.filter(
            (user) => user.managerName == personalInfo.userID
          );
          setAllUsersList(filteredUsers);
          setTimeout(() => {
            window.initDataTable();
          }, 500);
        }
      } else {
        toast.error(response.data.message);
      }
    } catch(error) {
      console.error("Error fetching leave data", error);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetRoles = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}LeaveType/GetAllLeaveTypes`
      );
      const appsArray = response.data.data || [];
      setLeaveType(appsArray);
    } catch(error) {
      console.error("Error fetching LeaveTypes:", error);
      toast.error("Error fetching LeaveTypes");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const leaveTypes = selectedUser
    ? leaveType.find((type) => type.id == selectedUser.leaveType)
    : null;
  const leaveTypeName = leaveTypes ? leaveTypes.leaveTypeName : "Unknown";

  const handleViewUserDetails = (userObj) => {
    // console.log("userObj--->", userObj);
    window.initDestroyDataTableFuncation();
    setTimeout(() => {
      setSelectedLeaveId(userObj.leaveId);
      setSelectedUser(userObj);
      setIsModalVisible(true);
    }, 500);
    setTimeout(() => {
      window.initAgainDestroyDataTableFuncation();
    }, 500);
  };

  const handleCloseModal = () => {
    setIsModalVisible(false);
    setSelectedUser(null);
    fetchAllLeavesData();
  };

  const handleOpenRejectModal = () => {
    setIsRejectModalVisible(true);
  };

  const handleCloseRejectModal = () => {
    setRejectReason("");
    setIsRejectModalVisible(false);
  };

  const handleAcceptLeave = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/LeaveManagement/ApproveLeave`,
        {
          empId: selectedUser.empId,
          leaveId: selectedLeaveId,
          leaveType: selectedUser.leaveType,
          createdBy: personalInfo.userID,
          leaveCount: selectedUser.leaveDays,
        }
      );

      if(response.data.success === "True") {
        toast.success("Leave Approved!");
        fetchAllLeavesData();
        handleCloseModal();
        setTimeout(() => {
          navigate("/manage-leave");
        }, 500);
        setIsLoaderActive(false);
        return true;
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
        return false;
      }
    } catch(error) {
      console.error("Error approving leave:", error);
      toast.error("Failed to approve leave!");
      setIsLoaderActive(false);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handlRejectLeave = async (remark) => {
    // debugger
    if (rejectReason.trim() === "") {
      toast.error("Please enter reason");
      return;
    }
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/LeaveManagement/RejectLeave`,
        {
          empId: selectedUser.empId,
          id: selectedLeaveId,
          leaveType: selectedUser.leaveType,
          createdBy: personalInfo.userID,
          leaveCount: selectedUser.leaveDays,
          remark: remark,
        }
      );

      if(response.data.success === "True") {
        toast.success("Leave Rejected!");
        setIsRejectModalVisible(false);
        fetchAllLeavesData();
        handleCloseModal();
        setIsLoaderActive(false);
        setTimeout(() => {
          navigate("/manage-leave");
        }, 500);
        return true;
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
        return false;
      }
    } catch(error) {
      console.error("Error rejecting leave:", error);
      toast.error("Failed to reject leave!");
      setIsLoaderActive(false);
      return false;
    } finally {
      setIsLoaderActive(false);
    }
  };



  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };


  const filteredUsers = allUsersList.filter((row) =>
    Object.values(row).some(
      (val) =>
        val &&
        val.toString().toLowerCase().includes(searchText.toLowerCase())
    )
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredUsers.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredUsers.length / rowsPerPage);


  const exportToCSV = () => {
    let csv = "User Name,Leave Type,From Date,To Date,Reason,Status\n";
    allUsersList.forEach((row) => {
      const leave = leaveType.find((t) => t.id === row.leaveType);
      const leaveName = leave ? leave.leaveTypeName : "unknown";
      csv += `${row.employeeName},${leaveName},${row.fromDate},${row.toDate},${row.leaveReason},${row.leaveStatus}\n`;
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "EmployeeLeave.csv");
  };

  const exportToExcel = () => {
    const data = allUsersList.map((row) => {
      const leave = leaveType.find((t) => t.id === row.leaveType);
      return {
        "User Name": row.employeeName,
        "Leave Type": leave ? leave.leaveTypeName : "unknown",
        "From Date": row.fromDate,
        "To Date": row.toDate,
        "Reason": row.leaveReason,
        Status: row.leaveStatus,
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Leaves");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(blob, "EmployeeLeave.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Employee Leave", 14, 10);
    autoTable(doc, {
      head: [["User Name", "Leave Type", "From Date", "To Date", "Reason", "Status"]],
      body: allUsersList.map((row) => {
        const leave = leaveType.find((t) => t.id === row.leaveType);
        return [
          row.employeeName,
          leave ? leave.leaveTypeName : "unknown",
          row.fromDate,
          row.toDate,
          row.leaveReason,
          row.leaveStatus,
        ];
      }),
    });
    doc.save("EmployeeLeave.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print Leave</title></head><body>");
    printWindow.document.write("<table border='1'><tr><th>User Name</th><th>Leave Type</th><th>From</th><th>To</th><th>Reason</th><th>Status</th></tr>");
    allUsersList.forEach((row) => {
      const leave = leaveType.find((t) => t.id === row.leaveType);
      printWindow.document.write(`<tr><td>${row.employeeName}</td><td>${leave ? leave.leaveTypeName : "unknown"}</td><td>${row.fromDate}</td><td>${row.toDate}</td><td>${row.leaveReason}</td><td>${row.leaveStatus}</td></tr>`);
    });
    printWindow.document.write("</table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };




  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              {!selectedUser && (
                <h5 className="m-0">Manage Employee Leave</h5>
              )}
              {selectedUser && (
                <h5 className="m-0">Manage Employee Leave <span hover-tooltip="Here you can view the leave statistics such as total assigned leaves, available leaves, and taken leaves of the employee. Along with the leave request details below." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></h5>
              )}
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Manage Employee Leave{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      {selectedUser && (
        <div className="container-fluid px-4">
          <div className="row mb-3 px-1">
            <div className="col-md-12 d-flex" style={{ marginLeft: "-15px" }}>
              <div class="col-md-4 left2 m-1">
                <div class="small-box2">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0">Total Assigned Leaves</h6>
                    </div>
                    <div
                      className="col-md-3 mb-0 count d-flex align-items-center justify-content-center" style={{ height: "100px", borderTopRightRadius: "10px", borderBottomRightRadius: "10px", borderLeft: "2px solid #FFFFFF" }}
                    >
                      <span className="">{selectedUser.totalLeaves ? selectedUser.totalLeaves : 0}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4 left3 m-1">
                <div class="small-box3">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0">Total Available Leaves</h6>
                    </div>
                    <div
                      className="col-md-3 count mb-0 d-flex align-items-center justify-content-center" style={{ height: "100px", borderTopRightRadius: "10px", borderBottomRightRadius: "10px", borderLeft: "2px solid #FFFFFF" }}
                    >
                      <span className="ml-2">{selectedUser.totalLeaves - selectedUser.takenLeaves || 0}</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-4 left4 m-1">
                <div class="small-box4">
                  <div class="row d-flex align-items-center">
                    <div className="col-md-9 px-4">
                      <h6 className="mb-0 no-wrap">Total Leaves Taken</h6>
                    </div>
                    <div
                      className="col-md-3 count mb-0 d-flex align-items-center justify-content-center" style={{ height: "100px", borderTopRightRadius: "10px", borderBottomRightRadius: "10px", borderLeft: "2px solid #FFFFFF" }}
                    >
                      <span className="ml-2">{selectedUser.takenLeaves ? selectedUser.takenLeaves : 0}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="container-fluid px-3">
        <div className="row">
          <div className="col-md-12">
            <div className="card card-primary card-outline">
              <div className="card-header">
                {!selectedUser && (
                  <h3 className="card-title text-sm">Employee Leave <span hover-tooltip="In this employee leave you can view and manage employee leave requests in the table with details like employee name, leave type, dates requested, reason, status, and use the 'View' button to access attached files. Use the eye button under Action to review request details." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></h3>
                )}
                {selectedUser && (
                  <h3 className="card-title text-sm">Leave Details <span hover-tooltip="In this you can see the detailed information about the leave request, including type, reason, dates, and attachments.Actions include options to Close(redirect to employee leaves table page), Reject, or Accept the request." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></h3>
                )}
                <div className="card-tools">
                  <button
                    type="button"
                    className="btn btn-tool"
                    data-card-widget="maximize"
                  >
                    <i className="fas fa-expand"></i>
                  </button>
                </div>
              </div>
              <div className="card-body mainBody position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                {!selectedUser ? (
                  <>
                    <div className="d-flex justify-content-between mb-2">
                      <div>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                      </div>
                      <input
                        type="text"
                        className="form-control form-control-sm w-25"
                        placeholder="Search..."
                        onChange={(e) => setSearchText(e.target.value)}
                      />
                    </div>

                    <table
                      className="table table-bordered table-sm table-striped tableBody"
                    >
                      <thead>
                        <tr>
                          <th
                            style={{ fontWeight: "500", fontSize: "smaller" }}
                            className="text-center"
                          >
                            Sr. No.
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            User Name
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Leave Type
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            From Date
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            To Date
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Reason
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Status
                          </th>
                          <th style={{ fontWeight: "500", fontSize: "smaller" }}>
                            Attachments
                          </th>
                          <th
                            style={{
                              fontWeight: "500",
                              fontSize: "smaller",
                              width: "7%",
                            }}
                          >
                            Action
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentRows.length > 0 ? (
                          currentRows.map((userObj, index) => {
                            const leavesName = userObj
                              ? leaveType.find((t) => t.id == userObj.leaveType)
                              : null;
                            const leaveName = leavesName ? leavesName.leaveTypeName : "unknown";

                            return (
                              <tr key={index}>
                                <td className="text-center text-sm" style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {index + 1}
                                </td>
                                <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {userObj.employeeName}
                                </td>
                                <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {leaveName}
                                </td>
                                <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {new Date(userObj.fromDate).toLocaleDateString()}
                                </td>
                                <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {new Date(userObj.toDate).toLocaleDateString()}
                                </td>
                                <td style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {userObj.leaveReason}
                                </td>
                                <td
                                  style={{
                                    fontWeight: "400",
                                    fontSize: "smaller",
                                    color:
                                      userObj.leaveStatus === "Pending"
                                        ? "#f0ad4e"
                                        : userObj.leaveStatus === "Approved"
                                          ? "#28a745"
                                          : userObj.leaveStatus === "Rejected"
                                            ? "#dc3545"
                                            : "#6c757d",
                                  }}
                                >
                                  {userObj.leaveStatus === "Deleted" ? "Canceled" : userObj.leaveStatus}
                                </td>
                                <td className="text-center" style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {userObj.attachmentFileServerpath ? (
                                    <a
                                      href={userObj.attachmentFileServerpath}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                    >
                                      <i className="fa fa-eye mr-2" aria-hidden="true"></i>
                                      <strong>View</strong>
                                    </a>
                                  ) : (
                                    "No attachment"
                                  )}
                                </td>
                                <td className="text-center text-sm" style={{ fontWeight: "400", fontSize: "smaller" }}>
                                  {userObj.leaveStatus !== "Deleted" && (
                                    <button
                                      type="button"
                                      className="btn btn-primary btn-xs"
                                      onClick={() => handleViewUserDetails(userObj)}
                                      style={{
                                        padding: "5px",
                                        fontSize: ".75rem",
                                        lineHeight: "0",
                                        borderRadius: ".15rem",
                                      }}
                                    >
                                      <i className="fas fa-eye" style={{ fontSize: "smaller" }}></i>
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        ) : (
                          <tr>
                            <td colSpan="9" className="text-center">
                              No Records
                            </td>
                          </tr>
                        )}
                      </tbody>

                    </table>
                    <div className="d-flex justify-content-between mt-2">
                      <div>
                        Showing {indexOfFirstRow + 1} to {Math.min(indexOfLastRow, filteredUsers.length)} of {filteredUsers.length} entries
                      </div>
                      <div>
                        <button
                          className="btn btn-xs btn-outline-primary"
                          onClick={() => handlePageChange(currentPage - 1)}
                          disabled={currentPage === 1}
                        >
                          <i className="fas fa-angle-double-left"></i>
                        </button>
                        <span className="m-1">
                          Page {currentPage} of {totalPages}
                        </span>
                        <button
                          className="btn btn-xs btn-outline-primary"
                          onClick={() => handlePageChange(currentPage + 1)}
                          disabled={currentPage === totalPages}
                        >
                          <i className="fas fa-angle-double-right"></i>
                        </button>
                      </div>
                    </div>

                  </>
                ) : (
                  <div className="modal-content">
                    <div className="mb-3">
                      {selectedUser && (
                        <div>
                          <div className="row">
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">Leave Type</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={leaveTypeName}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">From Date</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={new Date(
                                    selectedUser.fromDate
                                  ).toLocaleDateString()}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">To Date</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={new Date(
                                    selectedUser.toDate
                                  ).toLocaleDateString()}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4 reasonText">
                              <div className="form-group">
                                <label className="pr-2">Reason</label>
                                <input
                                  type="text"
                                  className="form-control form-control-sm"
                                  value={selectedUser.leaveReason}
                                  readOnly
                                />
                              </div>
                            </div>
                            <div className="col-lg-4">
                              <div className="form-group">
                                <label className="pr-2">Attachments</label>
                                {selectedUser.attachmentFileServerpath ? (
                                  <a
                                    href={selectedUser.attachmentFileServerpath}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                  >
                                    <div className="d-flex align-items-center position-relative">
                                      <input
                                        type="text"
                                        className="form-control form-control-sm"
                                        value={decodeURIComponent(
                                          selectedUser.attachmentFileServerpath
                                            .split("/")
                                            .pop()
                                            .split("_")
                                            .slice(1)
                                            .join("_")
                                        )}
                                        readOnly
                                        style={{
                                          color: "#007bff",
                                          cursor: "pointer",
                                        }}
                                      />
                                      <button
                                        type="button"
                                        className="btn btn-xs btn-primary position-absolute px-2"
                                        style={{
                                          top: "49%",
                                          left: "91%",
                                          transform: "translateY(-50%)",
                                          fontSize: "18px",
                                          cursor: "pointer",
                                          zIndex: 2,
                                        }}
                                      >
                                        <i className="fas fa-file"></i>
                                      </button>
                                    </div>
                                  </a>
                                ) : (
                                  <input
                                    type="text"
                                    className="form-control form-control-sm"
                                    value="No Attachment"
                                    readOnly
                                  />
                                )}
                              </div>
                            </div>
                          </div>


                        </div>
                      )}
                    </div>
                    <div className="modal-footer">
                      <button
                        type="button"
                        className="btn btn-secondary btn-sm"
                        onClick={handleCloseModal}
                      >
                        Close
                      </button>
                      {selectedUser.leaveStatus !== "Approved" &&
                        selectedUser.leaveStatus !== "Rejected" ? (
                        <>
                          {!isLoaderActive && (
                            <button
                              className="btn btn-warning float-right btn-sm"
                              onClick={handleOpenRejectModal}
                            >
                              Reject
                            </button>
                          )}

                          {isLoaderActive ? (
                            <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                          ) : (
                            <button
                              className="btn btn-primary float-right btn-sm mr-2"
                              onClick={handleAcceptLeave}
                            >
                              Accept
                            </button>
                          )}
                        </>
                      ) : null}
                    </div>
                  </div>
                )}
                {isRejectModalVisible && (
                  <div className="modal-overlay rejectModal">
                    <div className="modal-dialog ">
                      <div className="modal-content ">
                        <div className="modal-header ">
                          <h5 className="modal-title ">Reject Leave
                          <span className="text-danger"> *</span>
                          </h5>
                          <button
                            type="button"
                            className="close"
                            onClick={handleCloseRejectModal}
                          >
                            &times;
                          </button>
                        </div>
                        <div className="modal-body ">
                          <p>
                            Are you sure you want to reject the leave request
                            for <strong>{selectedUser?.userName}</strong>?
                          </p>
                          <textarea
                            placeholder="Give your reason"
                            className="w-100"
                            value={rejectReason} // Bind the state
                            onChange={(e) => setRejectReason(e.target.value)} // Update state on change
                          ></textarea>
                        </div>
                        <div className="modal-footer">
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={handleCloseRejectModal}
                          >
                            Cancel
                          </button>
                          {isLoaderActive ? (
                            <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                          ) : (
                            <button
                              className="btn btn-danger btn-sm "
                              onClick={() => {
                                handlRejectLeave(rejectReason);
                              }}
                            >
                              Reject
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer position="top-center" />
    </>
  );
}

export default ManageEmployeeLeave;
