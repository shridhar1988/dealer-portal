import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import $ from "jquery";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import "../Reports/reports.css";

function ItDecelaration() {
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [selectedYear, setSelectedYear] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [show, setShow] = useState(true);
  const currentYear = new Date().getFullYear();
  const [salaryComponentsArray, setSalaryComponentsArray] = useState([
    { description: "", amount: 0, flag: true },
  ]);
  const [isActiveUser, setIsActiveUser] = useState(true);
  const [taxComponentsArray, setTaxComponentsArray] = useState([
    { des: "", amount: 0, flag: true },
  ]);
  const [regime, setRegime] = useState("new");
  const [taxDeclarationData, setTaxDeclarationData] = useState([]);
  const descriptionRefs = useRef([]);

  const personalInfo = useSelector((state) => state.personalInformationReducer);

  useEffect(() => {
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    setSelectedYear(defaultYear);
    GetAllTaxComponents(defaultYear, "new");
  }, []);

  const generateYears = () => {
    let years = [];
    const startYear = 2016;
    for (let i = startYear; i <= currentYear; i++) {
      years.push(`${i}-${i + 1}`);
    }
    return years;
  };
  const handleChange = (event) => {
    setSelectedYear(event.target.value);
    GetAllTaxComponents(event.target.value, regime);
  };
  const addNewSalaryComponents = () => {
    let tempObj = {
      description: "",
      amount: 0,
      flag: true,
      salaryComponentsType: "addition",
    };
    setSalaryComponentsArray((prevArray) => [...prevArray, tempObj]);
    initSortableTable(salaryComponentsArray);
  };
  const addNewTaxComponents = () => {
    let tempObj = {
      des: "",
      amount: 0,
      flag: true,
      taxComponentsType: "addition",
    };

    setTaxComponentsArray((prevArray) => [...prevArray, tempObj]);
    initSortableTable(taxComponentsArray);
  };
  const changeActiveUser = (event) => {
    setIsActiveUser(event.target.checked);
  };
  const initSortableTable = (getSalaryComponentsArray) => {
    setTimeout(() => {
      window.$("#faqs").sortable({
        items: "tr:not(tr:first-child)",
        cursor: "pointer",
        axis: "y",
        dropOnEmpty: false,
        start: function (e, ui) {
          ui.item.addClass("selected");
        },
        stop: function (e, ui) {
          ui.item.removeClass("selected");
          $(this)
            .find("tr")
            .each(function (index) {
              if (index > 0) {
              }
            });
        },
      });
    }, 1000);
  };
  const removeComponentFromArray = (indexToRemove) => {
    setSalaryComponentsArray((prevArray) =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(salaryComponentsArray);
  };
  const removeCompFromArray = (indexToRemove) => {
    setTaxComponentsArray((prevArray) =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(salaryComponentsArray);
  };
  const handleOld = () => {
    setShow(false);
    setShowModal(true);
    setRegime("old");
    GetAllTaxComponents(selectedYear, "old");
  };

  const handleNew = () => {
    setShow(true);
    setShowModal(false);
    setRegime("new");
    // alert(selectedYear);
    GetAllTaxComponents(selectedYear, "new");
  };

  const validateSalaryoldComponentInputs = () => {
    let tempValidationBit = true;

    // Reset validation
    window.$("#tblBodyId tr").each(function () {
      $(this).find("input[name='descriptionInput']").removeClass("is-invalid");
      $(this).find("input[name='amount']").removeClass("is-invalid");
    });

    // Validation
    window.$("#tblBodyId tr").each(function () {
      const descriptionInput = $(this).find("input[name='descriptionInput']");
      const amountInput = $(this).find("input[name='amount']");

      if (!descriptionInput.val()) {
        descriptionInput.addClass("is-invalid");
        toast.error("Enter Description");
        tempValidationBit = false;
        return false;
      }

      if (!amountInput.val()) {
        amountInput.addClass("is-invalid");
        toast.error("Enter Amount");
        tempValidationBit = false;
        return false;
      }
    });

    return tempValidationBit;
  };

  const validateTaxComponentInputs = () => {
    let tempValidationBit = true;

    // Remove previous validation errors
    window.$("#tblBodyId tr").each(function () {
      $(this).find("input[name='desInput']").removeClass("is-invalid");
    });

    // Validate current inputs
    window.$("#tblBodyId tr").each(function () {
      const desInput = $(this).find("input[name='desInput']");

      if (!desInput.val()) {
        desInput.addClass("is-invalid").focus();
        toast.error("Enter Description");
        tempValidationBit = false;
        return false; // exit loop
      }
    });

    return tempValidationBit;
  };

  const handleSave = async (regimeId) => {
    setIsLoaderActive(true);

    if (!selectedYear) {
      toast.error("Please select a financial year.");
      setIsLoaderActive(false);
      return;
    }

    const selectedArray =
      regimeId == "old" ? salaryComponentsArray : taxComponentsArray;

    // console.log("selectedArray---->", selectedArray);

    // if (selectedArray.length == 0) {
    //     toast.error("Please add at least one component before saving.");
    //     setIsLoaderActive(false);
    //     return;
    // }

    if (regimeId == "old") {
      const isValid = validateSalaryoldComponentInputs(); // 👈 call the jQuery validator
      if (!isValid) {
        setIsLoaderActive(false);
        return;
      }
    } else {
      const isvalid = validateTaxComponentInputs();
      if (!isvalid) {
        setIsLoaderActive(false);
        return;
      }
    }

    const descriptions = selectedArray.map(
      (item) => item.description || item.des
    );

    const amount = selectedArray.map((item) => item.amount || 0);
    if (!descriptions) {
      toast.error("Duplicate descriptions are not allowed.");
      setIsLoaderActive(false);
      return;
    }
    if (!amount) {
      selectedArray.map((item) => (item.amount ? item.amount : 0));
    }

    // const payload = {
    //     regimeId,
    //     financialYear: selectedYear,
    //     itDeclarationDetail: (regimeId == "old"
    //         ? salaryComponentsArray
    //         : taxComponentsArray
    //     ).map((item) => ({
    //         delarationType: regimeId == "old" ? item.description : item.des,
    //         amount: regimeId == "old" ? item.amount : item.amount,
    //         flag: regimeId == "old" ? item.flag : item.flag,
    //     })),
    //     createdBy: personalInfo.userID,
    // };

    const payload = {
      regimeId,
      financialYear: selectedYear,
      itDeclarationDetail: (regimeId === "old"
        ? salaryComponentsArray
        : taxComponentsArray
      ).map((item) => ({
        delarationType: regimeId === "old" ? item.description : item.des,
        amount: item.amount || 0,
        flag: item.flag || false,
      })),
      createdBy: personalInfo.userID,
    };

    // console.log("Payload being sent to API:", payload);

    try {
      const response = await axios.post(
        `${config.API_URL}ITDeclarationMaster/CreateItDeclaration`,
        payload,
        { headers: { "Content-Type": "application/json" } }
      );
      // console.log(response, "Response------>>>");

      if (response.data.success == "True") {
        toast.success(response.data.message);
        const defaultYear = `${currentYear}-${currentYear + 1}`;
        setSelectedYear(defaultYear);
        setIsLoaderActive(false);
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch (error) {
      console.error("Error saving IT Declaration:", error);
      setIsLoaderActive(false);
      toast.error("Failed to save IT Declaration.");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllTaxComponents = async (year, regimee) => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ITDeclarationMaster/GetItDeclarationByFinancialYearAndRegime?FinancialYear=${year}&Regime=${regimee}`
      );
      const componentsArray = response.data.data || [];
      //console.log("GetAllPayrollComponents ===> ", componentsArray);

      const taxDeclarationArray = Array.isArray(componentsArray)
        ? componentsArray
        : [taxDeclarationData];

      const filteredOldData = taxDeclarationArray.filter(
        (item) => item.regimeId == "old" && item.financialYear == year
      );
      const filteredNewData = taxDeclarationArray.filter(
        (item) => item.regimeId == "new" && item.financialYear == year
      );

      //console.log("filterOld Data---->", filteredOldData);
      //console.log("filteredNewData---->", filteredNewData);

      setSalaryComponentsArray(
        filteredOldData.map((item) => ({
          description: item.delarationType || [],
          amount: item.amount || 0,
          flag: item.flag,
        }))
      );
      setTaxComponentsArray(
        filteredNewData.map((item) => ({
          des: item.delarationType || [],
          amount: item.amount || 0,
          flag: item.flag,
        }))
      );
    } catch (error) {
      console.error("Error fetching components:", error);
      //   toast.error("Error fetching components");
    } finally {
      setIsLoaderActive(false);
    }
  };

  return (
    <>
      <main id="main" className="addAssignee">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">
                  IT Declaration
                  <span
                    hover-tooltip="In this page you can set a particular set of contents for the IT declaration and then you can select for which year you are setting this regime and then you can select whether this is an old regime or a new regime."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/employee-dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">IT Decelaration</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid px-3">
          <div className="card p-3">
            <div class="row d-flex align-items-center">
              <div class="col-12 col-sm-6 col-md-4">
                <div
                  class="info-box reportcard mb-0"
                  style={{
                    border: showModal ? "1px solid rgb(35, 142, 220)" : "",
                    cursor: "pointer",
                  }}
                  onClick={handleOld}
                >
                  <span class="info-box-icon bg-primary elevation-1">
                    <div
                      className=""
                      style={{
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <i className="fas fa-money-bill" />
                      <i
                        className="fas fa-rupee-sign"
                        style={{
                          position: "absolute",
                          color: "#007bff",
                          backgroundColor: "white",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                          fontSize: "15px",
                        }}
                      />
                    </div>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md"> Old Tax Slab Regime</span>
                  </div>
                </div>
              </div>
              <div class="col-12 col-sm-6 col-md-4">
                <div
                  class="info-box reportcard mb-0"
                  style={{
                    border: show ? "1px solid rgb(35, 142, 220)" : "",
                    cursor: "pointer",
                  }}
                  onClick={handleNew}
                >
                  <span class="info-box-icon bg-danger elevation-1">
                    <div
                      className=""
                      style={{
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <i class="far fa-money-bill-alt"></i>
                      <i
                        className="fas fa-rupee-sign"
                        style={{
                          position: "absolute",
                          width: "20px",
                          color: "#FFFFFF",
                          backgroundColor: "#dc3545",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                          fontSize: "15px",
                        }}
                      />
                    </div>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md"> New Tax Slab Regime</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* {Old Tax Regime} */}
        {showModal && !show && (
          <div className="container-fluid px-3">
            <div className="card card-outline card-primary">
              <div className="card-header">
                <div className="row d-flex">
                  <div className="col-md-4">
                    <h3 className="card-title text-sm mr-3 mt-1">
                      Old Tax Regime
                    </h3>
                    <select
                      value={selectedYear}
                      onChange={handleChange}
                      className="border border-gray-400 rounded py-1 w-52 cursor-pointer text-center bg-white shadow-md"
                    >
                      {generateYears().map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="card-tools ml-auto">
                    {isLoaderActive ? (
                      <PleaseWaitButton className="btn-xs font-weight-medium auth-form-btn" />
                    ) : (
                      <button
                        type="button"
                        className="btn btn-primary btn-xs"
                        onClick={() => handleSave("old")}
                      >
                        Save
                      </button>
                    )}
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
              </div>
              <div className="card-body position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div className="table-responsive">
                  <table id="faqs" className="table table-bordered table-sm">
                    <thead>
                      <tr className="text-sm">
                        <th></th>
                        <th>Sr. No.</th>
                        <th>Description</th>
                        <th>Active Status</th>
                        <th>Amount</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tblBodyId">
                      {salaryComponentsArray.length > 0
                        ? salaryComponentsArray.map((data, index) => (
                            <tr key={index}>
                              <td
                                className="text-center"
                                style={{ background: "#238edc" }}
                              >
                                <span className="handle ui-sortable-handle mt-5">
                                  <i className="fas fa-ellipsis-v mt-2"></i>
                                  <i className="fas fa-ellipsis-v"></i>
                                </span>
                              </td>
                              <td custAttr={index}>{index + 1}</td>
                              <td>
                                <input
                                  type="text"
                                  name="descriptionInput"
                                  placeholder="Enter description"
                                  value={data.description}
                                  ref={(el) =>
                                    (descriptionRefs.current[index] = el)
                                  }
                                  onChange={(e) => {
                                    const newArray = [...salaryComponentsArray];
                                    newArray[index].description =
                                      e.target.value;
                                    setSalaryComponentsArray(newArray);
                                  }}
                                  className="form-control form-control-sm"
                                />
                              </td>
                              <td className="text-center">
                                <div className="custom-control custom-switch">
                                  <input
                                    type="checkbox"
                                    className="custom-control-input"
                                    id={`customSwitch${index}`}
                                    onChange={(e) => {
                                      const newArray = [
                                        ...salaryComponentsArray,
                                      ];
                                      newArray[index].flag = e.target.checked;
                                      setSalaryComponentsArray(newArray);
                                    }}
                                    checked={data.flag || false}
                                  />
                                  <label
                                    className="custom-control-label"
                                    htmlFor={`customSwitch${index}`}
                                    style={{ color: "#000" }}
                                  ></label>
                                </div>
                              </td>
                              <td>
                                <input
                                  type="text"
                                  name="amount"
                                  placeholder="Enter amount"
                                  value={data.amount >= 0 ? data.amount : 0}
                                  onChange={(e) => {
                                    const newArray = [...salaryComponentsArray];
                                    newArray[index].amount = e.target.value;
                                    setSalaryComponentsArray(newArray);
                                  }}
                                  className="form-control form-control-sm"
                                />
                              </td>
                              <td>
                                <span
                                  className="btn btn-outline-danger btn-sm cursor-pointer"
                                  onClick={() =>
                                    removeComponentFromArray(index)
                                  }
                                  title="Delete"
                                >
                                  <i className="fas fa-trash"></i>
                                </span>
                              </td>
                            </tr>
                          ))
                        : null}
                    </tbody>
                  </table>
                </div>
                <div className="text-right">
                  <button
                    onClick={() => addNewSalaryComponents()}
                    className="btn btn-sm float-right btn-light mb-2"
                  >
                    + Add New Tax Components
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* {New Tax Regime} */}
        {!showModal && show && (
          <div className="container-fluid px-3">
            <div className="card card-outline card-primary">
              <div className="card-header">
                <div className="row d-flex">
                  <div className="col-md-4">
                    <h3 className="card-title text-sm mr-3 mt-1">
                      New Tax Regime
                    </h3>
                    <select
                      value={selectedYear}
                      onChange={handleChange}
                      className="border border-gray-400 rounded py-1 w-52 cursor-pointer text-center bg-white shadow-md"
                    >
                      {generateYears().map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="card-tools ml-auto">
                    {isLoaderActive ? (
                      <PleaseWaitButton className="btn-xs font-weight-medium auth-form-btn" />
                    ) : (
                      <button
                        type="button"
                        className="btn btn-primary btn-xs"
                        onClick={() => handleSave("new")}
                      >
                        Save
                      </button>
                    )}
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
              </div>
              <div className="card-body position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div className="table-responsive">
                  <table id="faqs" className="table table-bordered table-sm">
                    <thead>
                      <tr className="text-sm">
                        <th></th>
                        <th>Sr. No.</th>
                        <th>Description</th>
                        <th>Active Status</th>
                        <th>Amount</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody id="tblBodyId">
                      {taxComponentsArray.length > 0
                        ? taxComponentsArray.map((data, index) => (
                            <tr key={index}>
                              <td
                                className="text-center"
                                style={{ background: "#238edc" }}
                              >
                                <span className="handle ui-sortable-handle mt-5">
                                  <i className="fas fa-ellipsis-v mt-2"></i>
                                  <i className="fas fa-ellipsis-v"></i>
                                </span>
                              </td>
                              <td custAttr={index}>{index + 1}</td>
                              <td>
                                <input
                                  type="text"
                                  name="desInput"
                                  placeholder="Enter description"
                                  value={data.des}
                                  ref={(el) =>
                                    (descriptionRefs.current[index] = el)
                                  }
                                  onChange={(e) => {
                                    const newArray = [...taxComponentsArray];
                                    newArray[index].des = e.target.value;
                                    setTaxComponentsArray(newArray);
                                  }}
                                  className="form-control form-control-sm"
                                />
                              </td>
                              <td className="text-center">
                                <div className="custom-control custom-switch">
                                  <input
                                    type="checkbox"
                                    className="custom-control-input"
                                    id={`customSwitch${index}`}
                                    onChange={(e) => {
                                      const newArray = [...taxComponentsArray];
                                      newArray[index].flag = e.target.checked;
                                      setTaxComponentsArray(newArray);
                                    }}
                                    checked={data.flag || false}
                                  />
                                  <label
                                    className="custom-control-label"
                                    htmlFor={`customSwitch${index}`}
                                    style={{ color: "#000" }}
                                  ></label>
                                </div>
                              </td>
                              <td>
                                {" "}
                                <input
                                  type="text"
                                  name="amount"
                                  placeholder="Enter Amount"
                                  value={data.amount >= 0 ? data.amount : 0}
                                  onChange={(e) => {
                                    const newArray = [...taxComponentsArray];
                                    newArray[index].amount = e.target.value;
                                    setTaxComponentsArray(newArray);
                                  }}
                                  className="form-control form-control-sm"
                                />
                              </td>
                              <td>
                                <span
                                  className="btn btn-outline-danger btn-sm cursor-pointer"
                                  onClick={() => removeCompFromArray(index)}
                                  title="Delete"
                                >
                                  <i className="fas fa-trash"></i>
                                </span>
                              </td>
                            </tr>
                          ))
                        : null}
                    </tbody>
                  </table>
                </div>
                <div className="text-right">
                  <button
                    onClick={() => addNewTaxComponents()}
                    className="btn btn-sm float-right btn-light mb-2"
                  >
                    + Add New Tax Components
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <ToastContainer position="top-center" />
      </main>
    </>
  );
}

export default ItDecelaration;
