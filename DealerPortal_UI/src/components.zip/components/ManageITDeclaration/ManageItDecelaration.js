import React, { useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import $ from "jquery";

function ManageItDeclaration() {
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [selectedYear, setSelectedYear] = useState("");
  const currentYear = new Date().getFullYear();
  const [declarations, setDeclarations] = useState([]);
  const [regimeType, setRegimetype] = useState("new");
  const [selectedRegime, setSelectedRegime] = useState("new");
  const [data, setData] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const [slabTaxComponentsArray, setSlabTaxComponentsArray] = useState([
    // {
    //   descId: "",
    //   amount: "",
    //   attachmentUrl: null,
    //   attachment: "",
    // },
  ]);
  const personalInfo = useSelector((state) => state.personalInformationReducer);

  useEffect(() => {
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    setSelectedYear(defaultYear);
    GetAllItDeclarations();
  }, []);

  useEffect(() => {
    if (selectedYear && selectedRegime) {
      GetSlabDataByYear();
    }
  }, [selectedRegime, selectedYear]);

  const generateYears = () => {
    let years = [];
    let startYear = 2016;
    for (let i = startYear; i <= currentYear; i++) {
      years.push(`${i}-${i + 1}`);
    }

    return years;
  };

  const cardClickHandler = (value) => {
    setSelectedRegime(value);
  };

  const GetAllItDeclarations = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ITDeclarationMaster/GetAllItDeclaration`
      );
      if (response.data.success === "True") {
        setDeclarations(response.data.data);
        // console.log("data", response.data.data);
      } else {
        setDeclarations([]);
      }
    } catch (error) {
      console.error("Error fetching declarations:", error);
      toast.error("Error fetching declarations");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetSlabDataByYear = async () => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ITDeclarationMaster/GetAllEmplyeeSubmittedITDeclarationByEmpIdAndYear?FinancialYear=${selectedYear}&EmpID=${personalInfo.userID}`
      );
      // console.log("API Response:", response.data.data);

      if (response.data.success == "True" && response.data.data.length > 0) {
        const filteredData = response.data.data.filter(
          (item) => item.regimeId == selectedRegime
        );
        // console.log("Filtered Data:", filteredData);
        if (response.data.data) {
          if (filteredData.length > 0) {
            setIsEditing(false);
            setSlabTaxComponentsArray(filteredData);
            setIsLoaderActive(false);
          } else {
            setSlabTaxComponentsArray([]);
            setIsLoaderActive(false);
          }
        }
      } else {
        
        try {
          const response = await axios.get(
            `${config.apiEndPoint}/ITDeclarationMaster/GetItDeclarationByFinancialYearAndRegime?FinancialYear=${selectedYear}&Regime=${selectedRegime}`
          );
          // console.log("API Response 2:", response.data.data);
          if (response.data.success === "True") {
            const filteredData = response.data.data.filter(
              (item) => item.regimeId == selectedRegime
            );
            // console.log("Filtered Data:", filteredData);
            if (response.data.data) {
              setData(true);
              if (filteredData.length > 0) {
                setIsEditing(true);

                setSlabTaxComponentsArray(filteredData);
                setIsLoaderActive(false);
              } else {
                setSlabTaxComponentsArray([]);
                setIsLoaderActive(false);
              }
            }
          }
        } catch (error) {
          console.error("Error fetching employee tax details:", error);
          toast.error("Error fetching employee tax details");
          return false;
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Error fetching data");
    } finally {
      setIsLoaderActive(false);
      setData(false);
    }
  };

  const handleSalaryComponentsNameChange = (e, index, inputName, value) => {
    if (inputName == "name") {
      const updatedValue = value;
      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray];
        updatedArray[index] = {
          ...updatedArray[index],
          delarationType: updatedValue,
        };
        return updatedArray;
      });
    } else if (inputName == "maxname") {
      const updatedValue = e.target.value;
      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray];
        updatedArray[index] = {
          ...updatedArray[index],
          amount: updatedValue,
        };
        return updatedArray;
      });
    } else {
      const updatedValue = e.target.files[0];
      const prevAttachment = slabTaxComponentsArray[index]?.attachment || null; // Ensure safe access

      // console.log("file Value -->", updatedValue);

      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray];

        updatedArray[index] = {
          ...updatedArray[index],
          isDocumentAdded: true,
          prevAttachment: prevAttachment, // Store old attachment
          attachment: updatedValue, // Store new attachment
        };

        return updatedArray; // ✅ Ensure to return the updated state
      });
    }
  };

  const handleSave = async () => {
    try {
      const formData = new FormData();

      formData.append("RegimeId", regimeType);
      formData.append("EmpId", personalInfo.userID);
      formData.append("FinancialYear", selectedYear);
      formData.append("CreatedBy", personalInfo.userID);
      formData.append("ModifiedBy", personalInfo.userID);

      slabTaxComponentsArray.forEach((item, index) => {
        formData.append(`DelarationId[${index}]`, item.delarationId || "");
        // alert(item.delarationType);
        formData.append(`Amount[${index}]`, item.amount > 0 ? item.amount : 0);
        formData.append(`IsDeleted[${index}]`, "false");
        // ✅ Corrected Attachment Field
        if (item.attachment && item.attachment instanceof File) {
          formData.append(`Attachment`, item.attachment);
        }

        formData.append(
          `PrevAttachmentUrl[${index}]`,
          item.prevAttachment ? item.prevAttachment : ""
        );
        formData.append(
          `isDocumentAdded[${index}]`,
          item.isDocumentAdded ? item.isDocumentAdded : false
        );
      });

      // console.log("all data---->", slabTaxComponentsArray);
      const response = await axios.post(
        `${config.API_URL}ITDeclarationMaster/addDeclaration`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );

      if (response.data.success == "True") {
        toast.success(response.data.message);
        // GetEmpTaxComponents(selectedYear);
        setIsEditing(false);
        GetSlabDataByYear();
        setIsLoaderActive(false);
      } else {
        setIsLoaderActive(false);
        toast.error(response.data.message);
      }
    } catch (e) {}
  };
  const handleEdit = () => {
    setIsEditing(true);
  };

  const handleCancel = () => {
    // setSlabTaxComponentsArray((prevArray) => {
    //   ...prevArray;
    //   });
    setIsEditing(false);
  };

  const handleRemoveAttachment = (index) => {
    if (isEditing == true) {
      setSlabTaxComponentsArray((prev) =>
        prev.map((item, i) =>
          i === index ? { ...item, attachment: null, prevAttachment: "" } : item
        )
      );
    }
  };

  return (
    <>
      <main id="main" className="addAssignee">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">
                  Manage IT Declaration
                  <span
                    hover-tooltip="In this page you have to fill thses predefined components for your IT declaration , with the amount you have paid and proof of the payment should be attached when filling the contents and also you can see whether that particular is accepted or rejected and it will shows remarks when it is rejected."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/employee-dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">
                    Manage IT Declaration
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid px-3">
          <div className="card p-2">
            <div class="row">
              <div class="col-12 col-sm-6 col-md-3">
                <div
                  class="info-box reportcard mb-0"
                  value="old"
                  onClick={(e) => cardClickHandler("old")}
                  style={{
                    border:
                      selectedRegime === "old"
                        ? "1px solid rgb(35, 142, 220)"
                        : "",
                    cursor: "pointer",
                  }}
                >
                  <span class="info-box-icon bg-primary elevation-1">
                    <div
                      className=""
                      style={{
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <i className="fas fa-money-check-alt" />
                      <i
                        className="fas fa-rupee-sign"
                        style={{
                          position: "absolute",
                          color: "#007bff",
                          backgroundColor: "white",
                          top: "50%",
                          left: "26%",
                          transform: "translate(-50%, -50%)",
                          fontSize: "15px",
                        }}
                      />
                    </div>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md">Old Regime</span>
                  </div>
                </div>
              </div>
              <div
                class="col-12 col-sm-6 col-md-3"
                style={{
                  cursor: "pointer",
                }}
                value="new"
                onClick={(e) => cardClickHandler("new")}
              >
                <div
                  class="info-box reportcard mb-0"
                  style={{
                    border:
                      selectedRegime === "new"
                        ? "1px solid rgb(35, 142, 220)"
                        : "",
                    cursor: "pointer",
                  }}
                >
                  <span class="info-box-icon bg-danger elevation-1">
                    <i class="fas fa-file-invoice"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md">New Regime</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Table */}

        <div className="container-fluid">
          <div className="col-md-12">
            {/* First Card Section */}
            <div className="card card-outline card-primary position-relative">
              {isLoaderActive && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgb(233 236 239 / 81%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 10,
                  }}
                >
                  <i
                    className="fas fa-sync-alt fa-spin"
                    style={{ fontSize: "2rem", color: "#333" }}
                  ></i>
                </div>
              )}
              <div className="card-header">
                <div className="row align-items-center">
                  <div className="col-md-6">
                    <h3 className="card-title">
                      {selectedRegime == "new" ? "New Regime" : "Old Regime"}{" "}
                      {selectedYear}
                    </h3>
                  </div>

                  <div className="col-md-6 float-right">
                    <div className="card-tools float-right">
                      <select
                        value={selectedYear}
                        onChange={(e) => {
                          setSelectedYear(e.target.value);
                          // GetSlabDataByYear();
                        }}
                        className="border border-gray-400 rounded px-2 py-1 w-52 cursor-pointer text-center bg-white shadow-md mr-2"
                      >
                        {generateYears().map((year) => (
                          <option key={year} value={year}>
                            {year}
                          </option>
                        ))}
                      </select>
                      {isEditing == true && !data ? (
                        <>
                          {isLoaderActive ? (
                            <PleaseWaitButton className="btn-xs ml-2 font-weight-medium auth-form-btn" />
                          ) : (
                            <button
                              type="button"
                              className="btn btn-xs btn-primary"
                              onClick={(e) => handleSave(e)}
                            >
                              Save
                            </button>
                          )}
                        </>
                      ) : (
                        slabTaxComponentsArray.length > 0 && (
                          <>
                            <span className="text-sm mr-3">
                              HR Remark :{" "}
                              {slabTaxComponentsArray.find(
                                (item) => item.hrRemarks
                              )?.hrRemarks || "N/A"}
                            </span>
                            <span
                              className={`badge 
                                 ${
                                   slabTaxComponentsArray.some(
                                     (item) => item.status === "Rejected"
                                   )
                                     ? "badge-danger"
                                     : slabTaxComponentsArray.every(
                                         (item) => item.status === "Approved"
                                       )
                                     ? "badge-success"
                                     : "badge-warning"
                                 } mr-3 ml-auto pb-1`}
                            >
                              {slabTaxComponentsArray.some(
                                (item) => item.status === "Rejected"
                              )
                                ? "Rejected"
                                : slabTaxComponentsArray.every(
                                    (item) => item.status === "Approved"
                                  )
                                ? "Approved"
                                : "Pending"}
                            </span>
                          </>
                        )
                      )}
                      {!data &&
                        slabTaxComponentsArray.some(
                          (item) => item.status === "Rejected"
                        ) && (
                          <>
                            {!isEditing ? (
                              <button
                                type="button"
                                className="btn btn-warning btn-xs mr-2 px-2"
                                onClick={handleEdit}
                              >
                                Edit
                              </button>
                            ) : (
                              <>
                                {/* {isLoaderActive ? <PleaseWaitButton className='btn-xs font-weight-medium auth-form-btn' /> :
                                  <button
                                    type="button"
                                    className="btn btn-primary btn-xs"
                                    onClick={() => handleSave("new")}
                                  >
                                    Update
                                  </button>
                                } */}
                                <button
                                  type="button"
                                  className="btn btn-danger btn-xs ml-2"
                                  onClick={() => handleCancel("new")}
                                >
                                  Cancel
                                </button>
                              </>
                            )}
                          </>
                        )}
                      <button
                        type="button"
                        className="btn btn-tool ml-2"
                        data-card-widget="maximize"
                      >
                        <i className="fas fa-expand"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="card-body px-0">
                <div className="row">
                  <div className="col-md-12 ">
                    <div className="col-md-12">
                      <div className="table-responsive">
                        <table
                          id="faqs"
                          className="table table-bordered table-sm"
                        >
                          <thead>
                            <tr className="text-sm">
                              <th>Sr. No.</th>
                              <th>Description</th>
                              <th>Amount</th>
                              <th>Attachments</th>
                            </tr>
                          </thead>
                          <tbody id="tblBodyId">
                            {slabTaxComponentsArray.length > 0
                              ? slabTaxComponentsArray.map((data, index) => (
                                  <tr key={data.id || index}>
                                    <td>{index + 1}</td>
                                    <td>
                                      <input
                                        type="text"
                                        name="SalaryComponentsNameInput"
                                        placeholder="Enter description"
                                        value={
                                          // data.id
                                          // ||
                                          // data.delarationId
                                          // data.delarationId
                                          declarations.find(
                                            (item) =>
                                              item.delarationId ==
                                              data.delarationId
                                          )?.delarationType || ""
                                        }
                                        onChange={(e) =>
                                          handleSalaryComponentsNameChange(
                                            e,
                                            index,
                                            "name",
                                            0
                                          )
                                        }
                                        className="form-control form-control-sm"
                                        disabled
                                      />
                                    </td>
                                    <td>
                                      <input
                                        type="text"
                                        name="SalaryComponentsNameInput"
                                        placeholder="Enter amount"
                                        value={data.amount}
                                        onChange={(e) =>
                                          handleSalaryComponentsNameChange(
                                            e,
                                            index,
                                            "maxname",
                                            0
                                          )
                                        }
                                        className="form-control form-control-sm"
                                        disabled={data.flag || !isEditing}
                                      />
                                    </td>
                                    <td
                                      className="pt-1"
                                      style={{ width: "30%" }}
                                    >
                                      {data.attachment ||
                                      data.prevAttachment ? (
                                        <>
                                          <a
                                            href={`${config.file_URL}${
                                              data.attachment ||
                                              data.prevAttachment
                                            }`}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                          >
                                            <i
                                              className="far fa-file-alt mr-1"
                                              aria-hidden="true"
                                            ></i>{" "}
                                            View
                                          </a>

                                          {isEditing ? (
                                            <i
                                              className="fas fa-times-circle text-danger  ml-2"
                                              title="Remove attachment"
                                              style={{ cursor: "pointer" }}
                                              onClick={() =>
                                                handleRemoveAttachment(index)
                                              }
                                            ></i>
                                          ) : null}
                                        </>
                                      ) : (
                                        <>
                                          {isEditing ? (
                                            <input
                                              type="file"
                                              name="SalaryComponentsNameInput"
                                              placeholder="select attachment"
                                              onChange={(e) =>
                                                handleSalaryComponentsNameChange(
                                                  e,
                                                  index,
                                                  "minname",
                                                  0
                                                )
                                              }
                                              className="form-control form-control-sm"
                                              style={{ paddingTop: "2px" }}
                                            />
                                          ) : (
                                            "No attachment found"
                                          )}
                                        </>
                                      )}
                                    </td>
                                  </tr>
                                ))
                              : null}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <ToastContainer position="top-center" />
      </main>
    </>
  );
}

export default ManageItDeclaration;
