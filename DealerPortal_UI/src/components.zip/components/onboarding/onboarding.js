import React, { useState, useEffect, useRef } from "react";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import axios from "axios";
import { useNavigate, useSearchParams } from "react-router-dom";
import $ from "jquery";
import "./form1.css";
import Footer from "../../shared/Footer";
import default_image from "../../assets/images/default_img.png";
import PleaseWaitButton from "../../shared/PleaseWaitButton";

function Onboarding() {
  const [jsonData, setJsonData] = useState(null);
  const [appendIndexId, setAppendIndexId] = useState(1);
  const [urlCalled, setUrlCalled] = useState(false);
  const [apiResult, setApiResult] = useState(null);
  const [userName, setUserName] = useState("");

  const [lastName, setLastName] = useState("");

  const [empId, setEmpId] = useState("");
  const [searchParams] = useSearchParams();
  const initialStep = parseInt(searchParams.get("currentStep")) || 1;
  const [currentStep, setCurrentStep] = useState(initialStep);
  const [status, setStatus] = useState(false);
  const [documentsObject, setDocumentsObject] = useState([]);
  const [documentsName, setDocumentsName] = useState([]);
  const [email, setEmail] = useState();
  const [gender, setGender] = useState();
  const [contact, setContact] = useState();
  const [profileImage, setProfileImage] = useState("");
  const [isLoading, setIsLoading] = React.useState(false);
  const [addharValue, setAddharValue] = useState(null);

  let tempVariableForAdhar = 0;
  const [profilePath, setProfilePath] = useState(false);

  const navigate = useNavigate();
  const toastId = React.useRef(null);

  $(document).ready(function () {
    var hasExperience = localStorage.getItem("hasExperience");
  
    if (hasExperience === "true") {
      if ($(".experienceCertificate span").length === 0) {
        $(".experienceCertificate").append('<span class="text-danger"> *</span>');
      }
  
      if ($(".payslip span").length === 0) {
        $(".payslip").append('<span class="text-danger"> *</span>');
      }
    }

    if($("#pancardAttachment").attr('value') != "" ){
      $("#pancardAttachment").removeAttr('required');
    }else{
      if (!$("#pancardAttachment").attr('required')) {
        $("#pancardAttachment").attr('required', 'required');
    }
  }

    if($("#adharAttachment").attr('value') != "" ){
      $("#adharAttachment").removeAttr('required');
    }else{
      if (!$("#adharAttachment").attr('required')) {
        $("#adharAttachment").attr('required', 'required');
    }
    
    }

  });
  
  function fileUploadDiv() {
    $("#dynamic-form-container")
      .find("input[type='file']")
      .each(function () {
        const $fileInput = $(this);
        if ($fileInput.attr("class") == "document-upload-field") {
          $fileInput.parent("div").parent("div").addClass("file-upload");
          $fileInput.parent("div").addClass("file-select");
          $fileInput.parent("div").find("label").addClass("file-select-button");
          $fileInput.parent("div").find("label").html("Choose File");
          $fileInput
            .parent("div")
            .append(
              `<div class="file-select-name noFile">No file chosen...</div>`
            );

          let $removeButtond = $fileInput.siblings("label").find(".Removebtn");

          if (!$removeButtond.length) {
            // const newDiv = $("<div>").addClass("tickbox col-lg-2").css({
            //   display: "inline-block",
            //   marginLeft: "10px",
            // });

            $removeButtond = $("<div>")
              .addClass("cross Removebtn")
              .css("display", "none")
              .on("click", function (event) {
                event.preventDefault();
                $fileInput.val("");
                $fileInput
                  .parent("div")
                  .find(".noFile")
                  .text("No file chosen...");
                $fileInput.parent("div").removeClass("activeB");
                $fileInput
                  .parent("div")
                  .find(".file-select-button")
                  .removeClass("active");
                $fileInput.parent("div").find(".tick").remove();
                $(this).css("display", "none");
                
                if (!$("#adharAttachment").attr('required')) {
                  $("#adharAttachment").attr('required', 'required');
                }

                if (!$("#pancardAttachment").attr('required')) {
                  $("#pancardAttachment").attr('required', 'required');
                }
              
              });

            // newDiv.append($removeButtond);
            $fileInput.parent().append($removeButtond);
          }

          $fileInput.on("input change", function () {
            $fileInput.parent("div").find(".tick").remove();
            if ($fileInput.val()) {
              $removeButtond.css("display", "inline-block");
              $fileInput.parent("div").addClass("activeB");
              $fileInput
                .parent("div")
                .find(".file-select-button")
                .addClass("active");
              // if ($fileInput.parent('div').hasClass('tick')) {

              // } else {
              var file = $fileInput[0].files[0];
              var fileUrl = URL.createObjectURL(file);
              $fileInput
                .parent("div")
                .append(
                  `<div class="tick"><a href="${fileUrl}" target="_blank" title="${file.name}"><i class="fa fa-eye" aria-hidden="true"></i></a></div>`
                );
              // }

              $fileInput
                .parent("div")
                .find(".noFile")
                .text(
                  add3Dots($fileInput.val().replace("C:\\fakepath\\", ""), 55)
                );
            } else {
              $removeButtond.css("display", "none");
              $fileInput
                .parent("div")
                .find(".noFile")
                .text("No file chosen...");
              $fileInput.parent("div").removeClass("activeB");
              $fileInput
                .parent("div")
                .find(".file-select-button")
                .removeClass("active");
            }
          });
        }
      });
  }
  var loadFile = function (event) {
    var image = document.getElementById("output");
    image.src = URL.createObjectURL(event.target.files[0]);
    setProfileImage(event.target.files[0]);
    // var selectedFile = event.target.files[0];
    let getTempJsonDataArray = JSON.parse(jsonData);
    const index = getTempJsonDataArray.findIndex(
      (item) =>
        item.type === "file" && item.className === "profile-upload-field"
    );
    // getTempJsonDataArray[index]["filePath"] = "";
    setJsonData(JSON.stringify(getTempJsonDataArray));
  };

  function add3Dots(string, limit) {
    var dots = "...";
    if (string.length > limit) {
      // you can also use substr instead of substring
      string = string.substring(0, limit) + dots;
    }

    return string;
  }

  // ......................................Tejas Code .........................................................

  function AddingDiv() {
    // $("#dynamic-form-container")
    //   .find("input[type='file']")
    //   .each(function () {
    //     const $fileInput = $(this);
    //     let $removeButtond = $fileInput.siblings("label").find(".Removebtn");
    //     if (!$removeButtond.length) {
    //       // const newDiv = $("<div>").addClass("tickbox col-lg-2").css({
    //       //   display: "inline-block",
    //       //   marginLeft: "10px",
    //       // });
    //       $removeButtond = $("<label>")
    //         .text("Remove")
    //         .addClass("formbuilder-file-label file-select-button Removebtn")
    //         .css("float", "inline-end")
    //         .on("click", function (event) {
    //           event.preventDefault();
    //           $fileInput.val("");
    //           $(this).css("display", "none");
    //         });
    //       // newDiv.append($removeButtond);
    //       $fileInput.parent().append($removeButtond);
    //     }
    //   });
  }

  function adddingClassNameHeader() {
    $("#dynamic-form-container")
      .find("h6")
      .each(function () {
        $(this).addClass("documentHeader");
      });
  }

  useEffect(() => {
    // event.preventDefault();
    fetchUserDetails();
    setTimeout(() => {
      // AddingDiv();
      adddingClassNameHeader();
    }, 500);
  }, []);

  // ......................................End Tejas Code .........................................................

  //-----------------------------------------fetch API
  useEffect(() => {
    fetchUserDetails();
    // Bind the event listener
  }, []);

  const fetchUserDetails = async () => {
    if (urlCalled) {
      return;
    }

    try {
      const urlParams = new URLSearchParams(window.location.search);
      const encryptedData = urlParams.get("details")?.replace(/ /g, "+");
      if (!encryptedData) {
        handleErrorToastUsingMessage("No data found in the URL");
        return;
      }

      const response = await axios.get(
        `${config.apiEndPoint}/EmployeeData/GetEmployeeData`,
        { params: { encryptedData } }
      );
      // console.log("encryptedData--->", response.data.data);

      if (response.data.success == "True") {
        var getRes = response.data.data;
        setUserName(getRes.firstName);
        setLastName(getRes.lastName);
        setEmail(getRes.email);
        setGender(getRes.gender);
        setContact(getRes.mobile);
        setEmpId(getRes.empId);
        setApiResult(response.data.data); // This updates the state
        setUrlCalled(true);
      } else if (response.data.success === "False") {
        if (response.data.message == "completed") {
          //handlecongrats();
          navigate("/congratulations");
        } else {
          handleErrorToast(response.data);
        }
      }
    } catch (error) {
      handleErrorToast(error);
    }
  };

  const getSubModuleJsonByUserId = async (empId, formId) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AdminFormFormat/GetUserJsonDataByUserIdANDFormId`,
        {
          params: { empId, formId },
        }
      );

      if (response.data.success === "True") {
        if (response.data.data.isData === "True") {
          let jsonData = response.data.data.data.jsonData;
          let temp = false;
          var hasExperience = localStorage.getItem("hasExperience");

          if (hasExperience == "true") {
            //alert(hasExperience);
            if (typeof jsonData === "string") {
              jsonData = JSON.parse(jsonData);
            }
            jsonData = jsonData.map((item) => {
              // console.log("Item name:", item.name);
              if (
                item.name === "comDetailsAttachments" ||
                item.name === "paySlipAttachment"
              ) {
                // console.log("doneeee------------->");
                return { ...item, required: true };
              }
              temp = true;
              return item;
            });
          } else if (hasExperience == "false") {
            if (typeof jsonData === "string") {
              jsonData = JSON.parse(jsonData);
            }
            jsonData = jsonData.map((item) => {
              // console.log("Item name:", item.name);
              if (
                item.name === "comDetailsAttachments" ||
                item.name === "paySlipAttachment"
              ) {
                return { ...item, required: false };
              }
              temp = true;
              return item;
            });
          }
          if (temp) {
            jsonData = JSON.stringify(jsonData);
          }

          // console.log("json data---->", jsonData);

          setJsonData(jsonData); // Update jsonData for rendering
          return true;
        } else {
          return false;
        }
      } else {
        // // console.log("Form data not fetched");
        return false;
      }
    } catch (error) {
      // console.error("Error fetching form data:", error);
      return false;
    }
  };

  const getSubModuleJsonByModuleId = async (moduleId, subModuleId) => {
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/AdminFormFormat/GetFormFormatById/${moduleId}/${subModuleId}`
      );
      if (response.data.success === "True") {
        let jsonData = response.data.data.jsonData;
        let temp = false;
        var hasExperience = localStorage.getItem("hasExperience");

        if (hasExperience == "true") {
          if (typeof jsonData === "string") {
            jsonData = JSON.parse(jsonData);
          }
          jsonData = jsonData.map((item) => {
            // console.log("Item name:", item.name);
            if (
              item.name === "comDetailsAttachments" ||
              item.name === "paySlipAttachment"
            ) {
              return { ...item, required: true };
            }
            temp = true;
            return item;
          });
        }
        if (temp) {
          jsonData = JSON.stringify(jsonData);
        }
        if (jsonData) {
          // console.log("module jsonData--->", jsonData);
          setJsonData(jsonData); // Update jsonData for rendering
        }
      } else {
        // console.log("Form data not fetched");
      }
    } catch (error) {
      // console.error("Error fetching form data:", error);
    }
  };

  useEffect(() => {
    if (apiResult) {
      loadData(1, currentStep); // Load data based on current step
    }
  }, [apiResult, currentStep]);

  const loadData = async (moduleId, subModuleId) => {
    if (apiResult != null) {
      const getResult = await getSubModuleJsonByUserId(
        apiResult.empId,
        currentStep
      );

      if (getResult == false) {
        getSubModuleJsonByModuleId(moduleId, subModuleId);
      }
    }
  };

  useEffect(() => {
    if (jsonData) {
      $(document).on("click", ".add-more", function () {
        let currentJsonData = getNewJsonDataWithValues();
        const getHowManyObjectsWeNeedToCopy = $(this)
          .attr("class")
          .split(" ")
          .pop();
        const getCurrentObjectId = $(this).attr("id");
        let getUpdatedJsonArray = copyAndPastePreviousObjects(
          currentJsonData,
          getCurrentObjectId,
          getHowManyObjectsWeNeedToCopy,
          appendIndexId
        );
        setJsonData(JSON.stringify(getUpdatedJsonArray));
        setAppendIndexId(appendIndexId + 1);
      });
      $(document).on("click", ".remove-more", function () {
        let getHowManyObjectNeedToRemove = $(".add-more")
          .attr("class")
          .split(" ")
          .pop();
        let currentJsonData = JSON.parse(jsonData);
        const searchName = $(this).attr("id");
        let getUpdatedJsonArray = removePreviousObjects(
          currentJsonData,
          searchName,
          getHowManyObjectNeedToRemove - 1
        );
        // // console.log("Akshay --",currentJsonData);
        setJsonData(JSON.stringify(getUpdatedJsonArray));
        setAppendIndexId(appendIndexId - 1);
      });
      // Cleanup function to remove the event listener when the component unmounts

      return () => {
        $(document).off("click", ".add-more");
        $(document).off("click", ".remove-more");
      };
    }
  }, [jsonData]);

  const removePreviousObjects = (
    getJsonArray,
    searchName,
    howManyObjectWeNeedToCopy
  ) => {
    // console.log("getJsonArray---->", getJsonArray);
    // console.log("searchName---->", searchName);

    // console.log("howManyObjectWeNeedToCopy---->", howManyObjectWeNeedToCopy);

    // Find the index of the element with the specific name
    let index = getJsonArray.findIndex((item) => item.name === searchName);
    const heading = getJsonArray[index - howManyObjectWeNeedToCopy - 1];
    // console.log("heading---->", heading);

    if (index !== -1) {
      // Remove the previous 6 objects (if they exist)
      let removeCount = Math.min(
        parseInt(howManyObjectWeNeedToCopy) + 1,
        index
      ); // Ensure we don't remove negative indices
      // console.log("removeCount---->",removeCount);
      // console.log("index---->",index);

      getJsonArray.splice(index - removeCount, removeCount + 1); // Remove the previous 6 items and the found item
    }
    // console.log("getJsonArray after op---->",getJsonArray);

    setTimeout(() => {
      $(".myCustomClass").each(function (i, obj) {
        $(this).html(i + 1 + " " + heading["label"]);
      });
    }, 500);
    return getJsonArray;
  };

  const copyAndPastePreviousObjects = (
    getJsonArray,
    searchName,
    howManyObjectWeNeedToCopy,
    appendIndexId
  ) => {
    // Find the index of the object with the specific "name" field
    const index = getJsonArray.findIndex((item) => item.name === searchName);
    // console.log("index---->", index);

    // If the name is found and index is valid
    if (index !== -1) {
      var removeBtnLength = $(".remove-more").length;

      let howmanyObjectNeedToCopy =
        removeBtnLength == 0
          ? howManyObjectWeNeedToCopy
          : parseInt(howManyObjectWeNeedToCopy) + 1;

      // Get the previous 6 objects from the found index (considering boundary cases)
      const startIndex = Math.max(0, index - howmanyObjectNeedToCopy); // Ensure we don't go out of bounds
      // console.log("startIndex--->", startIndex);
      //   if (!getJsonArray[index - howmanyObjectNeedToCopy].className.includes('myCustomClass')) {
      //     let tempObject = {
      //         type: "header",
      //         subtype: "h6",
      //         label:"hii",
      //         className: "myCustomClass w-100 col-md-12 " + 1,
      //         access: false,
      //     };
      //     // Insert tempObject at index startIndex - 2
      //     getJsonArray.splice(index - howmanyObjectNeedToCopy+1, 0, tempObject);
      // }

      const previousObjects = getJsonArray.slice(startIndex, index); // Extract the previous objects
      // console.log("previousObject--->", previousObjects[0]["label"]);

      const modifiedObjects = previousObjects.slice(1).map((item) => {
        return { ...item, name: item.name + "-" + appendIndexId, value: "" }; // Append '+1' to the "name"
      });

      let tempObject = {
        type: "header",
        subtype: "h6",
        label: previousObjects[0]["label"],
        className: "myCustomClass w-100 col-md-12 " + appendIndexId,
        access: false,
      };
      modifiedObjects.unshift(tempObject);
      // console.log("modifiedObjects---->", modifiedObjects);
      if (removeBtnLength == 0) {
        let removeTempObject = {
          type: "button",
          label: "- Remove",
          subtype: "button",
          className: "btn-danger btn remove-more col-md-2",
          name: "button-1733230103748-0" + "-" + appendIndexId,
          access: false,
          style: "danger",
        };
        modifiedObjects.push(removeTempObject);
      }
      getJsonArray.splice(index, 0, ...modifiedObjects); // Insert at the found index

      setTimeout(() => {
        $(".myCustomClass").each(function (i, obj) {
          $(this).html(i + 1 + " " + previousObjects[0]["label"]);
        });
      }, 10);

      return getJsonArray;
    } else {
      return null; // Return null if the name was not found
    }
  };

  const handleErrorToastUsingMessage = (message) => {
    if (!toast.isActive(toastId.current)) {
      toast.error(message, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };
  const handleSuccesToastWithMessage = (message) => {
    if (!toast.isActive(toastId.current)) {
      toast.success(message, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };
  const handleErrorToast = (error) => {
    if (!toast.isActive(toastId.current)) {
      toast.error(error.message, {
        toastId: "unique-toast-id", // A unique ID to ensure only one toast
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        pauseOnHover: true,
        draggable: true,
      });
    }
  };

  function findFilePath(jsonArray) {
    // Iterate through each item in the array
    for (let item of jsonArray) {
      if (item.filePath) {
        // // // console.log("item.filePath---->",item.filePath);

        return item.filePath; // Return the filePath if found
      }
    }
    return null; // Return null if filePath is not found
  }
  const readDocumentURL = function (Input) {
    if (
      $(Input).attr("file-document-path") &&
      $(Input).attr("file-document-path") != ""
    ) {
      let getAttrId = $(Input).attr("id");

      var label = $(Input).closest("input").prev("label");

      var anchor = $("<a>", {
        text: "Download File",
        href: $(Input).attr("file-document-path"),
        target: "_blank",
      });

      var button = $("<button>", { class: "file-button" }).append(anchor);

      var container = $(".document-upload-field-label");

      if (container.length) {
        $("#" + getAttrId)
          .parent("div")
          .append(button);
      } else {
        console.error(".document-upload-field container not found");
      }
    } else {
      $(label).hide();
      $(Input).hide();
    }
  };
  function findDocumentFilePath(jsonArray) {
    // Iterate through each item in the array
    for (let item of jsonArray) {
      if (item.fileDocumentPath) {
        // console.log("Shridhar------> ", item);
        let $fileInput = $("#" + item.name);
        $fileInput.parent("div").addClass("activeB");
        $fileInput.parent("div").find(".file-select-button").addClass("active");
        // $fileInput.parent('div').append(`<div class="tick"></div>`);
        $fileInput
          .parent("div")
          .append(
            `<div class="tick"><a href="${item.fileDocumentPath}" target="_blank" title="${item.value}"><i class="fa fa-eye" aria-hidden="true"></i></a></div>`
          );
        $fileInput.parent("div").find(".noFile").text(add3Dots(item.value, 55));
        $fileInput.parent("div").find(".cross").css("display", "inline-block");
      }
    }
    return null; // Return null if filePath is not found
  }
  useEffect(() => {
    if (jsonData) {
      let newJsonData = JSON.parse(jsonData);
      newJsonData.forEach((item) => {
        if (item.name === "fname") {
          item.value = userName + " " + lastName;
          item.disabled = true;
        }

        if (item.name === "cno") {
          item.value = contact;
          item.disabled = true;
        }
        if (item.name === "cmail") {
          item.value = email;
          item.disabled = true;
        }
      });
      setJsonData(JSON.stringify(newJsonData));
      let newJson = JSON.stringify(newJsonData);
      const $ = window.jQuery;
      const formContainer = document.getElementById("dynamic-form-container");
      if (formContainer) {
        $(formContainer).formRender({ formData: newJson });
        fileUploadDiv();
        const filePath = findFilePath(JSON.parse(jsonData));

        if (filePath == "") {
          filePath =
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTtuphMb4mq-EcVWhMVT8FCkv5dqZGgvn_QiA&s";
        }
        // // console.log("filePath----------->>>>>>>", filePath); // Output the filePath
        if (filePath != null) {
          // console.log("filePath----------->>>>>>>", filePath);
          setProfilePath(filePath);
          const container = $(".profile-upload-field").closest(
            ".formbuilder-file"
          );

          container.find(".image-preview").remove();
          container.append(
            '<img src="' +
              filePath +
              '" class="image-preview" id="output" alt="Image Preview" />'
          );
        }
        const fileDocumentPath = findDocumentFilePath(JSON.parse(newJson));

        // Append custom script for additional functionality
        const script = document.createElement("script");
        script.innerHTML = `
          $(document).ready(function() {
            const formData = ${JSON.stringify(jsonData)};
            // Apply dynamic classes for file upload fields
            $('.formbuilder-file').each(function(i, obj) {
              if($(this).find('input').attr('class') == "profile-upload-field") {
                $(this).addClass('profile-upload-field-label');
              }
            });
            $('.formbuilder-file').each(function(i, obj) {
              if($(this).find('input').attr('class') == "document-upload-field") {
                $(this).addClass('document-upload-field-label');
              }
            });
            // Handle file upload preview for profile 
          });
        `;
        document.body.appendChild(script);

        //used to remove empty label div
        $("label").each(function () {
          if ($(this).html() === "") {
            $(this).addClass("d-none");
          }
        });

        //used to remove margin-top of remove button if it is in the side of document upload
        $("button").each(function () {
          if ($(this).hasClass("btn-danger")) {
            if (
              $(this)
                .parent("div")
                .prev("div")
                .hasClass("document-upload-field-label")
            ) {
              $(this).addClass("mt-0");
            }
          }
        });

        if ($(".profile-upload-field-label").length > 0) {
          setProfilePath($(".profile-upload-field").attr("file-path"));
        }
        $(document).ready(function () {
          const today = new Date().toISOString().split("T")[0];

          $("input[type='date']").each(function () {
            $(this).attr("max", today);
          });
          $("input[type='date'].todayDate").each(function () {
            $(this).attr("max", today);
          });
        });
        // Apply the 'row' class to the rendered form
        const renderedForm = $(formContainer).find(".rendered-form");
        if (renderedForm.length) {
          renderedForm.addClass("row");
        }

        const uploadFields = document.querySelectorAll(
          ".document-upload-field"
        );
        if (uploadFields) {
          uploadFields.forEach((field) => {
            readDocumentURL(field);
          });
        }
      }
    }
  }, [jsonData]);

  //--------------------------------------getNewJsonDataWithValues
  const getNewJsonDataWithValues = () => {
    const $ = window.jQuery;
    const formContainer = document.getElementById("dynamic-form-container");

    if (!formContainer || !jsonData) {
      // console.error("Form container or jsonData is missing.");
      return null;
    }

    // Parse jsonData if it's a string
    let parsedJsonData = jsonData;
    if (typeof jsonData === "string") {
      try {
        parsedJsonData = JSON.parse(jsonData);
      } catch (error) {
        // console.error("Failed to parse jsonData:", error);
        return null;
      }
    }

    // Ensure it's an array
    const jsonDataArray = Array.isArray(parsedJsonData)
      ? parsedJsonData
      : Object.values(parsedJsonData);

    // Map through the array to attach values
    const newJsonData = jsonDataArray.map((field) => {
      const fieldName = field.name;
      const fieldType = field.type;

      // Find the corresponding input element in the form
      const inputElement = $(formContainer).find(`[name="${fieldName}"]`);
      if (!inputElement.length) return field; // Skip if the field doesn't exist in the form

      let fieldValue;

      // Extract value based on field type
      if (fieldType === "checkbox") {
        fieldValue = inputElement.is(":checked");
      } else if (fieldType === "radio") {
        fieldValue = $(formContainer)
          .find(`input[name="${fieldName}"]:checked`)
          .val();
      } else if (fieldType === "file") {
        const file = inputElement[0]?.files[0];
        fieldValue = file ? file.name : null; // Get the file name or null
      } else {
        fieldValue = inputElement.val(); // Get the input value for text, email, etc.
      }

      // Return updated field object with the new value
      return { ...field, value: fieldValue };
    });
    // console.log("newJsonData--->",newJsonData);

    // newJsonData.forEach((item) => {
    //   if (item.className.includes("Aadhar-Number")) {
    //     if(addharValue != null || addharValue != "")
    //       alert(addharValue);
    //     item.value = addharValue;
    //   }
    // });

    return newJsonData;
  };

  const postFormData = async (formData) => {
    try {
      // const documentObject = window.getDocumentObject();
      // debugger;
      const documentObject = window.getDocumentObject();
      const documentName = window.getDocumentName();
      setDocumentsObject(formData.attachments);
      setDocumentsName(documentName);
      const formDataToSend = new FormData();
      formDataToSend.append("empId", formData.empId);
      formDataToSend.append("subModuleId", formData.subModuleId);
      formDataToSend.append("jsonData", formData.jsonData);
      formDataToSend.append("formStatusFromUI", formData.formStatusFromUI);
      formDataToSend.append("profileImage", profileImage);
      // Append each item in the `attachments` array
      // debugger
      formData.attachments.forEach((attach, index) => {
        formDataToSend.append(`docAttachments`, attach);
      });
      //formDataToSend.append(`attachments`, formData.attachments);
      formData.attachmentsNames.forEach((attachmentName, index) => {
        formDataToSend.append(`attachmentsNames[${index}]`, attachmentName);
      });

      formData.selectedAttachmentsNames.forEach(
        (attachmentSelectedName, index) => {
          formDataToSend.append(
            `selectedAttachmentsNames[${index}]`,
            attachmentSelectedName
          );
        }
      );

      formDataToSend.append("createdBy", formData.createdBy);

      // console.log("Prepared form data:", formData.jsonData);
      // alert("");
      const response = await axios.post(
        `${config.apiEndPoint}/AdminFormFormat/PostUserJsonFormData`,
        formDataToSend,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            ...config.header3,
          },
        }
      );
      // const response = "";
      if (response.data.success == "True") {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      // console.error("Error saving data:", error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const handlecongrats = async () => {
    try {
      const response = await axios.post(
        `${config.apiEndPoint}/EmployeeData/OnboardingProcessComplete?EmpId=${empId}`
      );
      // debugger;
      // console.log("response--->", response.data);
      navigate("/congratulations");
    } catch (error) {
      // console.log("Error while sending mail to HR");
    }
  };

  const handleNext = async (event) => {
    event.preventDefault();

    if (validateForm()) {
      const newJsonData = getNewJsonDataWithValues();
      const profile_image = window.returnFileObject();
      const document = window.returnDocumentFileObject();
      // localStorage.setItem('hasExperience', 'false');
      if (currentStep == 2) {
        const hasNonEmptyValue = newJsonData.some(
          (item) => item.hasOwnProperty("value") && item.value !== ""
        );
        if (hasNonEmptyValue) {
          localStorage.setItem("hasExperience", true);
        } else {
          localStorage.setItem("hasExperience", false);
        }
      }

      if (newJsonData) {
        if (currentStep < 3) {
          // console.log("currentStep----->>>", currentStep);
          setStatus("In Progress");
        } else if (currentStep === 3) {
          // console.log("currentStep----->>>", currentStep);
          setStatus("Completed");
        }
        let tempAllDocumentNameArray = [];
        let tempAllSelectedDocumentNameArray = [];
        let tempAllGetSelectedFilesArray = [];
        // let tempDocumentActualFileArray = [];

        $("#dynamic-form-container")
          .find("input:file")
          .each(function () {
            let getThis = $(this);
            let getDocumentClassName = $(this).attr("name");
            tempAllDocumentNameArray.push(getDocumentClassName);
            if ($("#" + getThis.attr("id"))[0].files.length > 0) {
              tempAllSelectedDocumentNameArray.push(getDocumentClassName);
              const getSelectedFile = $("#" + getThis.attr("id"))[0].files[0];
              tempAllGetSelectedFilesArray.push(getSelectedFile);
            }
            // let getSelectedDocumentFile = $(this).val();
            // tempDocumentArray.push(getSelectedDocumentFile);
          });

        const formData = {
          empId: empId,
          subModuleId: currentStep,
          jsonData: JSON.stringify(newJsonData),
          formStatusFromUI: status,
          profileImage: profile_image,
          attachments: tempAllGetSelectedFilesArray,
          attachmentsNames: tempAllDocumentNameArray,
          selectedAttachmentsNames: tempAllSelectedDocumentNameArray,
          createdBy: empId,
        };

        try {
          setIsLoading(true);

          if (currentStep <= 4) {
            const check = await postFormData(formData);

            if (check === true) {
              if (currentStep <= 4) {
                setCurrentStep(currentStep + 1);
              }

              if (currentStep === 4) {
                handlecongrats();
              } else {
                handleSuccesToastWithMessage("Saved Succesfully!");
              }
            } else {
              handleErrorToastUsingMessage("Error while storing data!");
            }
          } else {
          }
        } catch (error) {
          handleErrorToastUsingMessage("Unexpected error while storing data!");
        } finally {
          setIsLoading(false);
        }
      }
    }
  };

  const handlePrevious = (event) => {
    event.preventDefault();
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const validateForm = () => {
    const $ = window.jQuery;
    let isValid = true;

    $(".rendered-form [required]").each(function () {
      const field = $(this);

      let className;
      if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("Aadhar-Number")
      ) {
        className = "Aadhar-Number";
      } else if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("pincode")
      ) {
        className = "pincode";
      } else if (
        field.attr("class") &&
        field.attr("class").split(" ").includes("pan-card")
      ) {
        className = "pan-card";
      }
      const value = field.val();
      const type = field.attr("type");
      const label = field.attr("label");

      const fieldName = field.attr("name");
      // console.log("field--->", field.attr());
      if (!value) {
        isValid = false;
        highlightError(field);
        toast.error(field.attr("placeholder"));
        return isValid;
      } else {
        removeHighlight(field);
      }

      if (type === "email" && value && !validateEmail(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid email address");
        return isValid;
      }

      if (type === "tel" && value && !validateTel(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid contact number");
        return isValid;
      }

      if (type === "number" && value && isNaN(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid number");
        return isValid;
      }
      if (fieldName === "bno" || fieldName === "cbno") {
        const bankAccountNumber = $("input[name='bno']").val();
        const confirmBankAccountNumber = $("input[name='cbno']").val();

        if (
          bankAccountNumber &&
          confirmBankAccountNumber &&
          bankAccountNumber !== confirmBankAccountNumber
        ) {
          isValid = false;
          highlightError($("input[name='cbno']"));
          toast.error("Plase enter a valid bank account number");
          return isValid;
        } else {
          removeHighlight($("input[name='cbno']"));
        }
      }

      if (className === "Aadhar-Number" && value && !validateAadhaar(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid adhar number");
        return isValid;
      }
      // debugger
      if (className === "pincode" && value && !validatePincode(value)) {
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid pincode");
        return isValid;
      }

      if (className === "pan-card" && value && !validatePancard(value)) {
        // alert("");
        isValid = false;
        highlightError(field);
        toast.error("Plase enter a valid pancard number");
        return isValid;
      }
    });

    return isValid;
  };

  const validateEmail = (email) => {
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return regex.test(email);
  };
  const validateTel = (tel) => {
    const regex = /^[1-9][0-9]{9}$/;
    return regex.test(tel);
  };
  const validateAadhaar = (aadhaar) => {
    const aadhaarRegex = /^[0-9]{12}$/; // Matches exactly 12 digits
    return aadhaarRegex.test(aadhaar);
  };

  const validatePincode = (pincode) => {
    const pincodeRegex = /^[0-9]{6}$/; // Regex to match exactly 6 numeric digits
    return pincodeRegex.test(pincode); // Returns true if valid, false otherwise
  };
  const validatePancard = (pancard) => {
    // alert("");
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/i;
    if (pancard.length === 10 && panRegex.test(pancard)) {
      return true;
    } else {
      return false;
    }
  };

  const highlightError = (element) => {
    element.css("border", "1px solid red");
  };
  const removeHighlight = (element) => {
    element.css("border", "");
  };

  return (
    <>
      <div style={{ backgroundColor: "#fbfbfb", display: "contents" }}>
        <div
          className="Header py-2"
          style={{ borderBottom: "1px solid #e0e0e0" }}
        >
          <a href="" className="brand-link mb-4">
            <img
              src={require("../../assets/images/Hlogo.png")}
              alt="Iteos Logo"
              className="brand-image"
            />
          </a>
        </div>

        <div className="header text-center">
          <h1>
            Hi, Welcome{" "}
            {userName ? userName + (lastName ? " " + lastName : "") : "User"}
          </h1>

          <p>
            Help us know you better! Provide all your Employment Information
          </p>
        </div>

        <div className="container-fluid">
          <div
            className="p-3"
            style={{
              width: "70%",
              marginLeft: "15%",
              background: "#f3f5fd",
              border: "1px solid #cbd5fb",
            }}
          >
            <div className="row">
              <div className="col-md-8">
                <div className="row d-flex align-items-center">
                  <div className="col-md-4">
                    <div className="profile-pic">
                      {currentStep == 1 ? (
                        <>
                          <label
                            className="-label mb-0"
                            htmlFor="file"
                            style={{ width: "50px", height: "50px" }}
                          >
                            <span className="fas fa-camera"></span>
                            {/* <span>Change Image</span> */}
                          </label>
                          <input
                            id="file"
                            type="file"
                            onChange={(event) => loadFile(event)}
                          />
                        </>
                      ) : null}
                      <img
                        src={
                          profilePath ||
                          (gender?.toLowerCase() === "male"
                            ? require("../../assets/images/default_img.png")
                            : require("../../assets/images/download.jpeg"))
                        }
                        id="output"
                        width="200"
                        alt="Profile"
                      />
                    </div>
                  </div>
                  <div className="col-md-8">
                    <label className="mb-0">UserName : </label>
                    <span>
                      {" "}
                      {userName
                        ? userName + (lastName ? " " + lastName : "")
                        : "User"}{" "}
                    </span>
                    <br />
                    <label className="mb-0">Email ID : </label>
                    <span> {email || null}</span>
                  </div>
                </div>
              </div>
              <div className="col-md-4 mt-2">
                <label className="mb-0">Contact Number : </label>
                <span> {contact || null}</span> <br />
                {/* <label className="mb-0">Location : </label>
                <span> Banglore</span> <br /> */}
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid mt-4">
          <div className="stepper">
            <div className="step">
              <div className={`circle ${currentStep === 1 ? "active" : ""}`}>
                1
              </div>
              <div className={`label ${currentStep === 1 ? "active" : ""}`}>
                Personal Details
              </div>
            </div>
            <div className="line"></div>
            <div className="step">
              <div className={`circle ${currentStep === 2 ? "active" : ""}`}>
                2
              </div>
              <div className={`label ${currentStep === 2 ? "active" : ""}`}>
                Professional Details
              </div>
            </div>
            <div className="line"></div>
            <div className="step">
              <div className={`circle ${currentStep === 3 ? "active" : ""}`}>
                3
              </div>
              <div className={`label ${currentStep === 3 ? "active" : ""}`}>
                Educational Details
              </div>
            </div>
            <div className="line"></div>
            <div className="step">
              <div className={`circle ${currentStep === 4 ? "active" : ""}`}>
                4
              </div>
              <div className={`label ${currentStep === 4 ? "active" : ""}`}>
                Document Details
              </div>
            </div>
          </div>
        </div>

        <hr />

        {/* Dynamic Form Rendering */}
        <div className="container form1 belowcon">
          <form method="post" href="#">
            <div id="dynamic-form-container">
              {/* Form will be dynamically rendered here */}
              {!jsonData && "Loading form..."}
            </div>
            <div className="button-container text-center float-right p-2">
              {currentStep >= 1 && (
                <button className="prevbtn mr-2" onClick={handlePrevious}>
                  Previous
                </button>
              )}
              {currentStep < 4 && (
                <>
                  {isLoading ? (
                    <PleaseWaitButton className="float-right btn-sm font-weight-medium auth-form-btn" />
                  ) : (
                    <button
                      type="submit"
                      className="nxtbtn btn-sm btn-primary"
                      onClick={handleNext}
                    >
                      Save & Next
                    </button>
                  )}
                </>
              )}
              {currentStep === 4 && (
                <button
                  className="nxtbtn btn-sm btn-primary"
                  onClick={handleNext}
                >
                  Finish
                </button>
              )}
            </div>
            <div className="container" style={{ marginTop: "70px" }}>
              <Footer />
            </div>
          </form>
        </div>

        <ToastContainer position="top-center" />
      </div>
    </>
  );
}

export default Onboarding;
