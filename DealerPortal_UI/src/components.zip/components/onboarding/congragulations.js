import React, { useRef, useState, useEffect } from "react";
import "./congrats.css";
import clogo from "../../assets/images/party-popper.svg";

import { useNavigate } from "react-router-dom";

function Congragulations() {
  const navigate = useNavigate();
  const handleAddEmployee = () => {
    navigate("/onboarding?currentStep=4");
  };

  const Confettiful = function (el) {
    this.el = el;
    this.containerEl = null;

    this.confettiFrequency = 3;
    this.confettiColors = ["#EF2964", "#00C09D", "#2D87B0", "#48485E", "#EFFF1D"];
    this.confettiAnimations = ["slow", "medium", "fast"];

    this._setupElements();
    this._renderConfetti();
  };

  Confettiful.prototype._setupElements = function () {
    const containerEl = document.createElement("div");
    const elPosition = this.el.style.position;

    if (elPosition !== "relative" || elPosition !== "absolute") {
      this.el.style.position = "relative";
    }

    containerEl.classList.add("confetti-container");

    this.el.appendChild(containerEl);

    this.containerEl = containerEl;
  };

  Confettiful.prototype._renderConfetti = function () {
    this.confettiInterval = setInterval(() => {
      const confettiEl = document.createElement("div");
      const confettiSize = Math.floor(Math.random() * 3) + 7 + "px";
      const confettiBackground = this.confettiColors[
        Math.floor(Math.random() * this.confettiColors.length)
      ];
      const confettiLeft = Math.floor(Math.random() * this.el.offsetWidth) + "px";
      const confettiAnimation = this.confettiAnimations[
        Math.floor(Math.random() * this.confettiAnimations.length)
      ];

      confettiEl.classList.add(
        "confetti",
        "confetti--animation-" + confettiAnimation
      );
      confettiEl.style.left = confettiLeft;
      confettiEl.style.width = confettiSize;
      confettiEl.style.height = confettiSize;
      confettiEl.style.backgroundColor = confettiBackground;

      confettiEl.removeTimeout = setTimeout(function () {
        confettiEl.parentNode.removeChild(confettiEl);
      }, 3000);

      this.containerEl.appendChild(confettiEl);
    }, 25);
  };
  useEffect(() => {
    window.confettiful = new Confettiful(document.querySelector(".js-container"));
  }, []);



  return (
    <>
      <div class="js-container containerCust" style={{ top: '0px !important' }}></div>

      <div className="container" style={{ textAlign: 'center', marginTop: '30px', position: 'fixed', width: '100%', top: '150px', right: '0px', left: '0px', padding: '50px', background: 'rgb(193 220 163 / 37%)' }}>
        <div class="checkmark-circle">
          <div class="background"></div>
          <div class="checkmark draw"></div>
        </div>
        <h1>Congratulations!</h1>
        <p>You are all set. Well done!</p>
        <div className="w-100">
          <p className="content mt-3" style={{ fontSize: '1.4em' }}>
            Thank you for completing the first step!
            We are now reviewing your details. Once the verification is complete,
            we will get back to you with the next steps. Stay tuned!
          </p>
        </div>
      </div>

    </>
  );
}

export default Congragulations;
{/* <div className=" card text-center p-5 d-flex align-items-center">
<div className="card-body cbody">
  <img src={clogo} className="clogo" alt="Logo" />
  <h4 className="heading">Congragulations</h4>
  <p className="content mt-3">
  Thank you for completing the first step! 
  We are now reviewing your details. Once the verification is complete, 
  we will get back to you with the next steps. Stay tuned!
  </p>
</div>
</div> */}