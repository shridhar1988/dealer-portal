import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import $ from "jquery";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { Link } from "react-router-dom";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import "./ManageExpenses.css";
import { saveAs } from "file-saver";
import * as XLSX from "xlsx";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";


function ManageExpense() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const inputComponentReference = useRef(null);
  const expensenameRef = useRef(null);
  const dateofjourneyRef = useRef(null);
  const fromDateRef = useRef(null);
  const toDateRef = useRef(null);
  const expensecomponentnameRef = useRef(null);
  const priceRef = useRef(null);
  const fileRef = useRef(null);
  const [addNewSectionsDisplay, setAddNewSectionsDisplay] = useState(false);
  const [showSelectedExpenses, setShowSelectedExpenses] = useState(false);
  const [selectedExpense, setSelectedExpense] = useState(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [employeeExpenses, setEmployeeExpenses] = useState([]);
  const [component, setComponent] = useState("");
  const [payrollTemplateName, setPayrollTemplateName] = useState("");
  const [probationType, setProbationType] = useState("");
  const [allTempalatesArray, setAllTempalatesArray] = useState([]);
  const [payrollComponents, setPayrollComponents] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [isExpenseNameInvalid, setIsExpenseNameInvalid] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 10;


  const [salaryComponentsArray, setSalaryComponentsArray] = useState([
    {
      componentName: "",
      percentage: "",
      fileUpload: "",
      fromDate: "",
      toDate: "",
      dateOfExpense: "",
      expenseName: "",
    },
  ]);

  const [expenseName, setExpenseName] = useState("");
  const [dateOfJourney, setDateOfJourney] = useState("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");
  const today = new Date().toISOString().split("T")[0];
  const [dateOfExpense, setDateOfExpense] = useState("");

  const [salaryComponents, setSalaryComponents] = useState(salaryComponentsArray || []);
  const handleChange = (date, index) => {
  if (!date) return;

  const updatedComponents = [...salaryComponents];
  if (!updatedComponents[index]) {
    updatedComponents[index] = { dateOfExpense: "" };
  }

  // Format date in local timezone as YYYY-MM-DD
  const formattedDate = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;

  updatedComponents[index] = {
    ...updatedComponents[index],
    dateOfExpense: formattedDate,
  };

  setSalaryComponents(updatedComponents);
  handleDateOfExpenseChange({ target: { value: formattedDate } }, index);
};



  const renderDayContents = (day, date) => {
    const tooltipText = `Day: ${day}`;
    return <span title={tooltipText}>{day}</span>;
  };



  // Handle input changes
  const handleExpenseNameChange = (e, index) => {
    const { value } = e.target;

    // Create a new array to avoid mutating state directly
    const updatedArray = [...salaryComponentsArray];

    // Update the specific entry in the array
    updatedArray[index] = {
      ...updatedArray[index],
      expenseName: value, // Update the expenseName field
    };

    // Update the state with the new array
    setSalaryComponentsArray(updatedArray);
  };
  const handleFromDateChange = (e) => setFromDate(e.target.value);
  const handleToDateChange = (e) => setToDate(e.target.value);
  const handleDateOfExpenseChange = (e, index) => {
    const updatedArray = [...salaryComponentsArray];
    updatedArray[index].dateOfExpense = e.target.value; // Set the specific row's date
    setSalaryComponentsArray(updatedArray); // Update state
  };

  const ShowSelectedExpenses = (expenseId) => {
    // console.log("Selected expense ID: ", expenseId); // Log the selected expense ID

    // Find the specific expense object by its id
    const selected = employeeExpenses.find(
      (expense) => expense.id === expenseId
    );

    if(selected) {
      setSelectedExpense(selected); // Save the selected expense object
      setShowSelectedExpenses(true); // Show the selected expense details section
    } else {
      console.error("Expense not found with ID: ", expenseId);
    }
  };

  const CloseSelectedExpensenses = () => {
    setShowSelectedExpenses(false);
    setTimeout(() => {
      window.initDataTable();
    }, 500);
  };

  const AddNewPayrollTemplateClickHandler = (e) => {
    setAddNewSectionsDisplay(true);
  };

  const cancleAddNewPayrollTemplateClickHandler = (e) => {
    setAddNewSectionsDisplay(false);
    setSelectedTemplateId("");
    GetAllTempalates();
    setFromDate("");
    setToDate("");
    setDateOfExpense("");
    setPayrollTemplateName("");
    setProbationType("");
    setSalaryComponentsArray([
      {
        componentName: "",
        percentage: "",
        fileUpload: null,
        fromDate: "",
        toDate: "",
        expenseName: "",
        dateOfExpense: "",
      },
    ]);
    setTimeout(() => {
      window.initDataTable();
    }, 500);
  };
  // const handleFileChange = (e, index) => {
  //   const file = e.target.files[0];
  //   setSalaryComponentsArray((prevArray) =>
  //     prevArray.map((item, i) =>
  //       i === index ? { ...item, fileUpload: file } : item
  //     )
  //   );
  // };

  const handleFileChange = (e, index) => {
    const file = e.target.files[0];
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
  
    if (file && allowedTypes.includes(file.type)) {
      setSalaryComponentsArray((prevArray) =>
        prevArray.map((item, i) =>
          i === index ? { ...item, fileUpload: file } : item
        )
      );
    } else {
      toast.error('Only JPEG, JPG, PNG, and PDF files are allowed.');
      e.target.value = null; // Clear the file input
  
      // Set fileUpload to null for the specific index
      setSalaryComponentsArray((prevArray) =>
        prevArray.map((item, i) =>
          i === index ? { ...item, fileUpload: null } : item
        )
      );
    }
  };

  useEffect(() => {
    GetAllTempalates();
    window.initDataTable();
    GetAllPayrollComponents();
    GetExpensesByEmpId(empid);
  }, []);

  const empid = personalInfo.userID;

  const formattedTotal =
    selectedExpense?.expenseDetails?.length > 0
      ? new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
      }).format(
        selectedExpense.expenseDetails.reduce((total, detail) => {
          return total + (detail.amount || 0);
        }, 0)
      )
      : "N/A";

  const GetAllTempalates = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        config.apiEndPoint + "/Payroll/GetTempalates"
      );
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);
      setAllTempalatesArray(tempalatesArray);
    } catch(error) {
      console.error("Error fetching tempalates:", error);
      toast.error("Error fetching tempalates");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetExpensesByEmpId = async (empid) => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.apiEndPoint}/ExpenseManagment/GetExpensesByEmpId?empId=${empid}`
      );
      const employeeExpenses = response.data.data || [];
      // console.log("employeeExpenses ===> ", employeeExpenses);
      setEmployeeExpenses(employeeExpenses);
      setTimeout(() => {
        window.initDataTable();
      }, 500);
    } catch(error) {
      console.error("Error fetching expenseDetails", error);
      toast.error("Error fetching Details");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const percentageOrRupeesChangeHandler = (
    getSelectedChangedValue,
    getIndexToChange
  ) => {
    setSalaryComponentsArray((prevArray) => {
      // Create a copy of the array and modify the object at the specified index
      const updatedArray = [...prevArray];
      updatedArray[getIndexToChange] = {
        ...updatedArray[getIndexToChange], // Copy the existing object at that index
        isPercentageOrAmount: getSelectedChangedValue, // Update the specific field (IsPercentageOrAmount)
      };
      return updatedArray; // Return the updated array
    });
  };

  const removeComponentFromArray = (indexToRemove) => {
    // Filter out the item at the provided index
    setSalaryComponentsArray((prevArray) =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(salaryComponentsArray);
  };
  const GetAllExpensesById = {};
  const addNewSalaryComponents = () => {
    let tempObj = {
      componentName: "",
      percentage: "",
      fileUpload: null,
      fromDate: "",
      toDate: "",
      expenseName: "",
      dateOfExpense: "",
    };

    // Instead of mutating the array, create a new array
    setSalaryComponentsArray((prevArray) => [...prevArray, tempObj]);
    initSortableTable(salaryComponentsArray);
  };

  const initSortableTable = (getSalaryComponentsArray) => {
    setTimeout(() => {
      window.$("#faqs").sortable({
        items: "tr:not(tr:first-child)",
        cursor: "pointer",
        axis: "y",
        dropOnEmpty: false,
        start: function(e, ui) {
          ui.item.addClass("selected");
        },
        stop: function(e, ui) {
          ui.item.removeClass("selected");
          $(this)
            .find("tr")
            .each(function(index) {
              if(index > 0) {
                // allTasksArray = projectTaskListData;
                // //console.log("Sort allTasksArray ===>", allTasksArray);
                // createTableDesign(allTasksArray)
              }
            });
        },
      });
    }, 1000);
  };

  const handleSalaryComponentsNameChange = (e, index, inputName) => {
    if(inputName == "name") {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the salaryComponentsArray by creating a new array and modifying the object at the specific index
      setSalaryComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          componentName: updatedValue, // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    } else {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the salaryComponentsArray by creating a new array and modifying the object at the specific index
      setSalaryComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          percentage: updatedValue, // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    }
  };

  const expensesUploadHandler = async () => {
    // console.log("slabTaxComponentsArray: ", salaryComponentsArray);

    var salaryComponentsRows = $("#tblBodyId tr");
    var newSalaryComponentsListData = [];
    salaryComponentsRows.each(function() {
      var getIndex = $(this).find("td:eq(1)").attr("custAttr");
      // console.log("getIndex ...", getIndex);

      if(salaryComponentsArray.hasOwnProperty(getIndex)) {
        if(salaryComponentsArray[getIndex] !== undefined) {
          let tempObj = {
            componentName: salaryComponentsArray[getIndex].componentName,
            percentage: salaryComponentsArray[getIndex].percentage,
            isPercentageOrAmount:
              salaryComponentsArray[getIndex].isPercentageOrAmount,
          };
          newSalaryComponentsListData.push(tempObj);
        }
      } else {
        // console.log("No match found for getIndex:", getIndex);
      }
    });

    // console.log("newSalaryComponentsListData ...", newSalaryComponentsListData);

    // Reset invalid classes
    window.$("#tblBodyId tr").each(function() {
      $(this)
        .find(
          "input[name='SalaryComponentsNameInput'], input[name='PercentageInput']"
        )
        .each(function() {
          if(window.$(this).val()) {
            window.$(this).removeClass("is-invalid");
          }
        });
    });
    window
      .$("#SalaryComponentsNameInput, #PercentageInput")
      .removeClass("is-invalid");

    let tempValidationBit = true;
    window.$("#tblBodyId tr").each(function() {
      // Check for SalaryComponentsNameInput
      $(this)
        .find("input[name='SalaryComponentsNameInput']")
        .each(function() {
          if(!window.$(this).val()) {
            window.$(this).addClass("is-invalid");
            tempValidationBit = false;
            toast.error("Enter Expense Category");
            return false; // Break out of .each loop on error
          }
        });

      if(!tempValidationBit) return false; // Exit early if validation failed

      // Check for PercentageInput
      $(this)
        .find("input[name='PercentageInput']")
        .each(function() {
          if(!window.$(this).val()) {
            window.$(this).addClass("is-invalid");
            tempValidationBit = false;
            toast.error("Enter Price");
            return false; // Break out of .each loop on error
          }
        });

      if(!tempValidationBit) return false;

      $(this)
        .find("input[name='FileInput']")
        .each(function() {
          if(!window.$(this).val()) {
            window.$(this).addClass("is-invalid");
            tempValidationBit = false;
            toast.error("please upload file");
            return false; // Break out of .each loop on error
          }
        });

      if(!tempValidationBit) return false;


    });

    if(!salaryComponentsArray[0]?.expenseName?.trim()) {
      setIsExpenseNameInvalid(true);
      expensenameRef.current?.focus();
      toast.error("Expense name is required.");
      return;
    } else {
      setIsExpenseNameInvalid(false);
    }

    // dateofjourneyRef.current.focus();
    // if (!dateOfJourney.trim()) {
    //   dateofjourneyRef.current.focus();
    //   dateofjourneyRef.current.classList.add("is-invalid");
    //   toast.error("Date is required.");
    //   return;
    // }




    // if (!fileRef.current || !fileRef.current.files.length) {
    //   fileRef.current?.classList.add("is-invalid");
    //   toast.error("Please add a file");
    //   return;
    // }

    // console.log("salaryComponentsArray:", salaryComponentsArray);

    const empId = personalInfo.userID; // Replace with actual ID if dynamic
    const expenseHeading =
      salaryComponentsArray[0]?.expenseName || "defaultHeading"; // Use expenseName

    const fromdate = fromDate;
    const todate = toDate; // Replace with dynamic date if needed

    // Create a FormData instance for file and data
    const formData = new FormData();

    // Append shared parameters
    formData.append("empId", empId);
    formData.append("expenseHeading", expenseHeading);
    formData.append("fromDate", fromdate);
    formData.append("toDate", todate);

    // Append repeated parameters (ExpenseDescription, Amount, and files)
    // console.log("expense---------->", salaryComponentsArray);
    salaryComponentsArray.forEach((expense) => {
      formData.append("ExpenseDescription", expense.componentName);
      formData.append("Amount", expense.percentage);

      if(expense.dateOfExpense) {
        formData.append("Date", expense.dateOfExpense);
      } else {
        console.error("Missing date for expense:", expense);
      }

      if(expense.fileUpload) {
        formData.append("attachment", expense.fileUpload);
      }
    });

    // console.log("Final formData values:");
    for(let pair of formData.entries()) {
      // console.log(pair[0] + ": " + pair[1]);
    }

    setIsLoaderActive(true);

    try {
      // Make the POST request
      const response = await axios.post(
        config.apiEndPoint + "/ExpenseManagment/AddNewExpenses",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      // console.log("Response:", response);

      if(response.data.status === "True") {
        toast.success(response.data.message);
        setIsLoaderActive(false);

        setTimeout(() => {
          window.location.reload();
        }, 1000);
      } else {
        toast.error(response.message);
        setIsLoaderActive(false);
      }
    } catch(error) {
      toast.error(error.response.data.message);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handlePayrollTemplateEditChange = (e, getInputName) => {
    const { name, value } = e.target;
    if(getInputName == "name") {
      setPayrollTemplateName(value);
    } else {
      setProbationType(value);
    }
  };

  const templateDropDownChangeHandler = async (getSelectedTemplateId) => {
    setIsLoaderActive(true);
    setSelectedTemplateId(getSelectedTemplateId);
    try {
      const response = await axios.get(
        config.apiEndPoint +
        "/Payroll/GetTempalateByTemplateId?id=" +
        getSelectedTemplateId
      );
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);

      if(response.data.success) {
        // console.log(
        //   "tempalatesArray[0]['payrollTemplateMaster'].templateName ===> ",
        //   tempalatesArray[0]["payrollTemplateMaster"].templateName
        // );
        setPayrollTemplateName(
          tempalatesArray[0]["payrollTemplateMaster"].templateName
        );
        setProbationType(
          tempalatesArray[0]["payrollTemplateMaster"].probationType
        );
        setSalaryComponentsArray(tempalatesArray[0]["payrollComponents"]);
        setAddNewSectionsDisplay(true);
        initSortableTable(tempalatesArray[0]["payrollComponents"]);
      }
      //setPayrollTemplateName()
      //   setAllTempalatesArray(tempalatesArray);
    } catch(error) {
      console.error("Error fetching tempalates:", error);
      toast.error("Error fetching tempalates");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const RemovePayrollTemplateClickHandler = async () => {
    window.$("#deleteModal").modal("show");
  };

  const hideModal = async () => {
    window.$("#deleteModal").modal("hide");
  };

  const confirmDeleteTemplate = async () => {
    setIsLoaderActive(true);
    const response = await axios.post(
      config.apiEndPoint +
      "/Payroll/deleteTempalate?templateId=" +
      selectedTemplateId
    );
    const tempalatesArray = response.data.data || [];
    // console.log("tempalatesArray ===> ", tempalatesArray);

    if(response.data.success) {
      // console.log("response ===> ", response);
      setPayrollTemplateName("");
      setProbationType("");
      setSalaryComponentsArray([
        {
          componentName: "",
          percentage: "",
          dateOfExpense: "",

          fromDate: "",
          toDate: "",
          expenseName: "",
        },
      ]);
      setAddNewSectionsDisplay(false);
      setSelectedTemplateId("");
      window.$("#deleteModal").modal("hide");
      GetAllTempalates();
      toast.error("Payroll template deleted successfully...");
    }
    setIsLoaderActive(false);
  };

  const showModal = async () => {
    window.$("#showModal").modal("show");
  };

  const closeModal = async () => {
    window.$("#showModal").modal("hide");
  };

  const handleSave = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.API_URL}Payroll/AddPayrollComponent`,
        {
          componentName: component,
          createdBy: personalInfo.userID,
        }
      );

      if(response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
        setIsLoaderActive(false);

        setComponent("");
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch(error) {
      if(
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        toast.error(error.response.data.message);
      } else {
        toast.error("Please try again later.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllPayrollComponents = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        config.apiEndPoint + "/Payroll/GetAllPayrollComponents"
      );
      const componentsArray = response.data.data || [];
      // console.log("GetAllPayrollComponents ===> ", componentsArray);
      setPayrollComponents(componentsArray);
      setIsLoaderActive(false);
    } catch(error) {
      console.error("Error fetching components:", error);
      setPayrollComponents([]);
      setIsLoaderActive(false);

      toast.error("Error fetching components");
    } finally {
      setIsLoaderActive(false);
    }
  };

  const handleDelete = async (userObj) => {
    try {
      setIsLoaderActive(true);
      const response = await axios.post(
        `${config.apiEndPoint}/Payroll/DeleteComponent/${userObj.autoId}`
      );

      if(response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
        setIsLoaderActive(false);
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch(error) {
      if(error.response && error.response.data) {
        toast.error(error.response.data.message || "An error occurred.");
      } else {
        toast.error("Please try again later.");
      }
    } finally {
      setIsLoaderActive(false);
    }
  };


  const filteredExpenses = employeeExpenses.filter((expense) =>
    (expense.expenseHeading || "").toLowerCase().includes(searchText.toLowerCase()) ||
    (expense.status || "").toLowerCase().includes(searchText.toLowerCase())
  );

  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredExpenses.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(filteredExpenses.length / rowsPerPage);

  const startEntry = indexOfFirstRow + 1;
  const endEntry = Math.min(indexOfLastRow, filteredExpenses.length);

  const handlePageChange = (newPage) => {
    if(newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };



  const exportToCSV = () => {
    let csv = "Expense Name,Status\n";
    filteredExpenses.forEach((exp) => {
      csv += `"${exp.expenseHeading}","${exp.status}"\n`;
    });
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    saveAs(blob, "ExpensesList.csv");
  };

  const exportToExcel = () => {
    const worksheet = XLSX.utils.json_to_sheet(
      filteredExpenses.map((exp) => ({
        "Expense Name": exp.expenseHeading,
        "Status": exp.status,
      }))
    );
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Expenses");
    const excelBuffer = XLSX.write(workbook, { bookType: "xlsx", type: "array" });
    const data = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    saveAs(data, "ExpensesList.xlsx");
  };

  const exportToPDF = () => {
    const doc = new jsPDF();
    doc.text("Expenses List", 14, 10);
    autoTable(doc, {
      head: [["Expense Name", "Status"]],
      body: filteredExpenses.map((exp) => [exp.expenseHeading, exp.status]),
    });
    doc.save("ExpensesList.pdf");
  };

  const printTable = () => {
    const printWindow = window.open("", "", "width=800,height=600");
    printWindow.document.write("<html><head><title>Print</title></head><body>");
    printWindow.document.write("<h3>Expenses List</h3>");
    printWindow.document.write("<table border='1'><thead><tr><th>Expense Name</th><th>Status</th></tr></thead><tbody>");
    filteredExpenses.forEach((exp) => {
      printWindow.document.write(`<tr><td>${exp.expenseHeading}</td><td>${exp.status}</td></tr>`);
    });
    printWindow.document.write("</tbody></table></body></html>");
    printWindow.document.close();
    printWindow.print();
  };



  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">
                Apply Reimbursement
                <span
                  hover-tooltip="In this page you can apply for reimbursement"
                  tooltip-position="bottom"
                >
                  <i
                    class="fas fa-info-circle"
                    style={{
                      marginLeft: "5px",
                      cursor: "pointer",
                      color: "rgb(0 0 0 / 51%)",
                    }}
                  ></i>
                </span>{" "}
              </h5>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">
                  Apply Reimbursement{" "}
                </li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="col-md-12">
          {/* First Card Section */}
          <div className="card card-outline card-primary">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <h3 className="card-title">
                    Apply Reimbursement{" "}
                    {addNewSectionsDisplay == true ? (
                      <span
                        hover-tooltip="From this page you can filled the detailed information for reimbursement by filling expense name and other details with attachment."
                        tooltip-position="bottom"
                      >
                        <i
                          class="fas fa-info-circle"
                          style={{
                            marginLeft: "5px",
                            cursor: "pointer",
                            color: "rgb(0 0 0 / 51%)",
                          }}
                        ></i>
                      </span>
                    ) : null}
                  </h3>
                </div>

                <div className="col-md-6 float-right">
                  <div className="card-tools float-right mt-1">
                    {!showSelectedExpenses && (
                      <button
                        type="button"
                        className="btn btn-tool"
                        data-card-widget="maximize"
                      >
                        <i className="fas fa-expand"></i>
                      </button>
                    )}
                  </div>

                  {showSelectedExpenses ? (
                    <>
                      <div className="card-tools float-right">
                        <button
                          className="btn btn-sm btn-default "
                          onClick={CloseSelectedExpensenses}
                        >
                          Close
                        </button>
                        <button
                          type="button"
                          className="btn btn-tool"
                          data-card-widget="maximize"
                        >
                          <i className="fas fa-expand"></i>
                        </button>
                      </div>
                    </>
                  ) : addNewSectionsDisplay == false ? (
                    <button
                      className="btn btn-sm float-right btn-primary mr-1"
                      type="button"
                      onClick={() => AddNewPayrollTemplateClickHandler()}
                    >
                      Add New Expense
                    </button>
                  ) : (
                    <>
                      <button
                        className="btn btn-sm float-right btn-default mr-1"
                        onClick={() => {
                          cancleAddNewPayrollTemplateClickHandler();
                        }}
                        type="button"
                      >
                        Cancel
                      </button>
                      {isLoaderActive ? (
                        <PleaseWaitButton className="float-right btn-sm mr-2 font-weight-medium auth-form-btn" />
                      ) : (
                        <button
                          className="btn btn-sm float-right btn-primary mr-2"
                          onClick={() => {
                            expensesUploadHandler();
                          }}
                          type="button"
                        >
                          Save Expense
                        </button>
                      )}
                    </>
                  )}
                  {selectedTemplateId != "" ? (
                    <button
                      className="btn btn-sm float-right btn-danger mr-1"
                      type="button"
                      onClick={() => RemovePayrollTemplateClickHandler()}
                    >
                      Remove Expense
                    </button>
                  ) : null}
                </div>
              </div>
            </div>
            <div className="card-body position-relative">
              {isLoaderActive && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgb(233 236 239 / 81%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 10,
                  }}
                >
                  <i
                    className="fas fa-sync-alt fa-spin"
                    style={{ fontSize: "2rem", color: "#333" }}
                  ></i>
                </div>
              )}
              {addNewSectionsDisplay == false &&
                showSelectedExpenses == false ? (
                <div className="row">
                  <div className="col-md-12">
                    <div className="d-flex justify-content-between mb-2">
                      <div>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToCSV}>Export CSV</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToExcel}>Export Excel</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={exportToPDF}>Export PDF</button>
                        <button className="btn btn-default btn-sm mr-1 exportBtn" onClick={printTable}>Print</button>
                      </div>
                      <input
                        type="text"
                        className="form-control form-control-sm w-25"
                        placeholder="Search by expense name or status..."
                        onChange={(e) => {
                          setSearchText(e.target.value);
                          setCurrentPage(1);
                        }}
                      />
                    </div>

                    <table
                      className="table table-bordered table-sm table-striped tableBody"
                    >
                      <thead>
                        <tr className="text-sm">
                          <th>Sr No.</th>
                          <th>Expense Name</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentRows.map((expense, index) => (
                          <tr key={expense.id}>
                            <td>{index + 1}</td>
                            <td>{expense.expenseHeading}</td>
                            <td>
                              <span
                                className={
                                  expense.status === "pending"
                                    ? "badge rounded-pill bg-warning text-light"
                                    : expense.status === "Processing"
                                      ? "badge rounded-pill bg-yellow text-white text-light" // Orange for "Processing"
                                      : expense.status === "processed"
                                        ? "badge rounded-pill bg-success text-white text-light" // Green for "Processed"
                                        : expense.status === "rejected" || expense.status === "deleted"
                                          ? "badge rounded-pill bg-danger"
                                          : "badge rounded-pill bg-secondary"
                                }
                                style={{ textTransform: "uppercase" }}
                              >
                                {expense.status || "Pending"}
                              </span>
                            </td>
                            <td>
                              <button
                                className="btn btn-outline-info btn-sm cursor-pointer mr-1"
                                onClick={() => ShowSelectedExpenses(expense.id)}
                              >
                                <i class="fas fa-eye"></i>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="d-flex justify-content-between mt-2">
                      <div>
                        Showing {startEntry} to {endEntry} of {filteredExpenses.length} entries
                      </div>
                      <div>
                        <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1}>
                          <i className="fas fa-angle-double-left"></i>
                        </button>
                        <span className="mx-2">Page {currentPage} of {totalPages}</span>
                        <button className="btn btn-xs btn-outline-primary" onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages}>
                          <i className="fas fa-angle-double-right"></i>
                        </button>
                      </div>
                    </div>

                  </div>
                </div>
              ) : null}
              {addNewSectionsDisplay == true ? (
                <div className="row">
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="option1">
                      Expense Name <span className="text-danger"> *</span>
                    </label>
                    <div className="input-group input-group-merge speech-to-text">
                      <input
                        type="text"
                        className={`form-control form-control-sm ${isExpenseNameInvalid ? "is-invalid" : ""
                          }`}
                        id="PayrollTemplateNameInput"
                        placeholder="Enter Expense Name"
                        name="name"
                        ref={expensenameRef}
                        value={salaryComponentsArray[0]?.expenseName || ""}
                        onChange={(e) => {
                          handleExpenseNameChange(e, "0");
                          setIsExpenseNameInvalid(false); // Remove error state when user types
                        }}
                      />
                    </div>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="option1">
                      From Date <span className="text-danger"> *</span>
                    </label>
                    <input
                      type="date"
                      value={fromDate}
                      ref={fromDateRef}
                      className="form-control form-control-sm"
                      placeholder="Date Of Birth"
                      onChange={(e) => {
                        handleFromDateChange(e);
                        fromDateRef.current.classList.remove("is-invalid");
                      }}
                      max={today}


                    />
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="option1">
                      To Date <span className="text-danger"> *</span>
                    </label>
                    <input
                      type="date"
                      value={toDate}
                      ref={toDateRef}
                      className="form-control form-control-sm"
                      placeholder="Date Of Birth"
                      onChange={(e) => {
                        handleToDateChange(e);
                        toDateRef.current.classList.remove("is-invalid");
                      }}
                      max={today}
                    />
                  </div>

                  <div className="col-md-12 mt-3">
                    <div className="table-responsive">
                      <table
                        id="faqs"
                        className="table table-bordered table-sm"
                      >
                        <thead>
                          <tr className="text-sm">
                            <th width="2%"></th>
                            <th width="6%">Sr. No.</th>
                            <th width="29%">Category </th>
                            <th width="9%">Date of expense</th>
                            <th width="9%">Price in Rs</th>
                            <th width="15%">Attachment</th>
                            <th width="6%">Status</th>
                          </tr>
                        </thead>
                        <tbody id="tblBodyId">
                          {salaryComponentsArray.length > 0
                            ? salaryComponentsArray.map((data, index) => (
                              <tr key={index}>
                                <td
                                  className="text-center"
                                  style={{ background: "#238edc" }}
                                >
                                  <span className="handle ui-sortable-handle mt-5">
                                    <i className="fas fa-ellipsis-v"></i>
                                    <i className="fas fa-ellipsis-v"></i>
                                  </span>
                                </td>
                                <td custAttr={index}>{index + 1}</td>
                                <td>
                                  <input
                                    name="SalaryComponentsNameInput"
                                    className="form-control form-control-sm"
                                    value={data.componentName || ""}
                                    ref={expensecomponentnameRef}
                                    onChange={(e) => {
                                      handleSalaryComponentsNameChange(
                                        e,
                                        index,
                                        "name"
                                      );
                                      expensecomponentnameRef.current.classList.remove(
                                        "is-invalid"
                                      );
                                    }}
                                    placeholder="Enter Expense Name"
                                  ></input>
                                </td>
                                {/* <td>
                                <input
                                    type="date"
                                    value={data.dateOfExpense || ""}
                                    className="form-control form-control-sm"
                                    onChange={(e) =>
                                      handleDateOfExpenseChange(e, index)
                                    }
                                    min={fromDate}
                                    max={toDate}
                                  />
                                </td>*/}
                                <td>
                                  {salaryComponents.map((component, index) => (
                                    <>
                                      <DatePicker
                                        key={index}
                                        showIcon
                                        toggleCalendarOnIconClick
                                        selected={component.dateOfExpense ? new Date(component.dateOfExpense) : null}
                                        onChange={(date) => handleChange(date, index)}
                                        renderDayContents={renderDayContents}
                                        dateFormat="dd"
                                        minDate={fromDate ? new Date(fromDate) : null}
                                        maxDate={toDate ? new Date(toDate) : null}
                                        className="form-control form-control-sm"
                                        placeholderText="Select date"
                                      />
                                    </>
                                  ))}
                                </td>

                                <td>
                                  <input
                                    type="text"
                                    name="PercentageInput"
                                    placeholder="Enter Expense Price"
                                    value={
                                      data.percentage != ""
                                        ? data.percentage
                                        : null
                                    }
                                    ref={priceRef}
                                    onChange={(e) => {
                                      handleSalaryComponentsNameChange(
                                        e,
                                        index,
                                        "percentage"
                                      );
                                      priceRef.current.classList.remove(
                                        "is-invalid"
                                      );
                                    }}
                                    className="form-control form-control-sm numberAndFloatInput"
                                  />
                                </td>
                                <td>
                                  <input
                                    type="file"
                                    accept=".jpg,.jpeg,.png,.pdf"
                                    name="FileInput"
                                    className="form-control form-control-sm"
                                    ref={fileRef}
                                    onChange={(e) =>
                                      handleFileChange(e, index)
                                    }
                                  />
                                </td>
                                <td>
                                  <span
                                    className="btn btn-outline-danger btn-sm cursor-pointer"
                                    onClick={() =>
                                      removeComponentFromArray(index)
                                    }
                                    title="Delete"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </span>
                                </td>
                              </tr>
                            ))
                            : null}
                        </tbody>
                      </table>
                    </div>
                    <div className="text-right">
                      <button
                        onClick={() => addNewSalaryComponents()}
                        className="btn btn-sm float-right btn-light"
                      >
                        + Add New Expense Components
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <h4></h4>
              )}
              {showSelectedExpenses &&
                !addNewSectionsDisplay &&
                selectedExpense &&
                selectedExpense.expenseDetails?.length > 0 ? (
                <>
                  <div className="row">
                    <div className="col-md-6">
                      <label>Expense Type</label>
                      <input
                        type="text"
                        className="form-control form-control-sm"
                        value={
                          selectedExpense.expenseHeading ||
                          "Unknown Expense Type"
                        }
                        disabled
                      />
                    </div>
                    {selectedExpense.status == "rejected" && (
                      <div className="col-md-6">
                        <label>Remark</label>
                        <input
                          type="text"
                          className="form-control form-control-sm"
                          value={selectedExpense.remark || "No Remark"}
                          disabled
                        />
                      </div>
                    )}
                    <div className="col-md-12 mt-4">
                      <table className="table table-bordered table-sm table-striped tableBody">
                        <thead>
                          <tr className="text-sm">
                            <th>Sr No.</th>
                            <th>Expense Detail</th>
                            <th>Amount</th>
                            <th>Attachments</th>
                          </tr>
                        </thead>
                        <tbody>
                          {selectedExpense.expenseDetails.map(
                            (detail, index) => (
                              <tr key={index}>
                                <td>{index + 1}</td>
                                <td>
                                  {detail.expenseDescription ||
                                    "No Description"}
                                </td>
                                <td>{detail.amount || "N/A"}</td>
                                <td>
                                  {detail.filePath ? (
                                    <a
                                      href={config.file_URL + detail.filePath}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="btn btn-outline-info btn-sm cursor-pointer mr-1"
                                    >
                                      <i className="fas fa-eye"></i>
                                    </a>
                                  ) : (
                                    "No Attachment"
                                  )}
                                </td>
                              </tr>
                            )
                          )}
                        </tbody>
                        <tfoot>
                          <tr>
                            <td></td>
                            <td>
                              <strong>Total : </strong>
                            </td>
                            <td colSpan="2">
                              <strong>{formattedTotal || "N/A"}</strong>
                            </td>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
                </>
              ) : null}
            </div>
          </div>
        </div>
      </div>
      <div
        class="modal fade"
        id="deleteModal"
        data-backdrop="static"
        data-keyboard="false"
        tabindex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          class="modal-dialog modal-sm modal-dialog-centered"
          role="document"
        >
          <div class="modal-content">
            <div class="modal-header">
              <h6 class="modal-title w-100 text-center" id="exampleModalLabel2">
                Are you sure?
              </h6>
              <button
                type="button"
                onClick={() => hideModal()}
                class="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body justify-content-center">
              <i
                class="w-100 text-center text-warning mb-3 fa fa-ban"
                style={{ fontSize: "3rem" }}
              ></i>
              <h6 class="text-center">
                Do you really want to delete these payroll template?
              </h6>
              <h6 class="text-center text-danger">
                This process cannot be undone.
              </h6>
            </div>
            <div class="modal-footer justify-content-center">
              <button
                type="button"
                class="btn btn-secondary"
                onClick={() => hideModal()}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-danger"
                onClick={() => confirmDeleteTemplate()}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id="showModal"
        data-backdrop="static"
        data-keyboard="false"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          className="modal-dialog modal-md modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="mb-0">Create New Payroll Component</h5>
              <button
                type="button"
                onClick={closeModal}
                className="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body justify-content-center">
              <div className="row">
                <div className="col-md-8">
                  <label>Component Name</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={component}
                    placeholder="Enter Component Name"
                    ref={inputComponentReference}
                    onChange={(e) => setComponent(e.target.value)}
                  />
                </div>
                <div
                  className="col-md-4 d-flex pl-4"
                  style={{ alignItems: "flex-end" }}
                >
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm mr-2"
                    onClick={closeModal}
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={handleSave}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <table className="table table-bordered table-striped table-sm">
                <thead>
                  <tr className="text-sm">
                    <th className="text-center">Sr. No.</th>
                    <th className="text-center">Component Name </th>
                    <th className="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {payrollComponents.length > 0 ? (
                    payrollComponents.map((userObj, index) => (
                      <tr
                        key={index}
                        style={{
                          textDecoration:
                            userObj.isDeleted == true ? "line-through" : "none",
                        }}
                      >
                        <td
                          style={{ fontWeight: 400, fontSize: "smaller" }}
                          className="text-center text-sm"
                        >
                          {index + 1}
                        </td>
                        <td style={{ fontWeight: 400, fontSize: "smaller" }}>
                          {userObj.componentName || "N/A"}
                        </td>
                        <td
                          style={{ fontWeight: "400", fontSize: "smaller" }}
                          onClick={(e) => {
                            handleDelete(userObj);
                          }}
                          className="text-center text-sm"
                        >
                          {!userObj.isDeleted && (
                            <button
                              type="button"
                              className="btn bg-gradient-danger btn-xs ml-2"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="text-center text-muted">
                        No Payroll Components Available
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-center" />
    </>
  );
}

export default ManageExpense;
