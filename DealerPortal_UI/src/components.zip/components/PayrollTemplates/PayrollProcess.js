import React, { useState, useEffect, useRef } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import PleaseWaitButton from "../../shared/PleaseWaitButton";

function PayrollProcess() {
    const [isLoaderActive, setIsLoaderActive] = useState(false);
    const [roles, setRoles] = useState([]);
    const [payroll, setPayroll] = useState([]);
    const [departments, setDepartments] = useState([]);
    const [selectedDepartment, setSelectedDepartment] = useState("all");
    const [selectedEmployees, setSelectedEmployees] = useState([]);
    const personalInfo = useSelector((state) => state.personalInformationReducer);

    useEffect(() => {
        GetRoles();
        GetPayrollTemplates();
        GetDepartments();
        window.$('#monthYearV').datetimepicker({
            format: 'MM-YYYY',
          })
        window.initDatePickerFuncation();
        window
            .$("#monthYearV")
            .on("change.datetimepicker", () => {
                GetRoles();
            });
    }, []);


    const GetRoles = async () => {
        setIsLoaderActive(true);
        const now = new Date();
        const currentMonth = String(now.getMonth() + 1).padStart(2, "0");
        const currentYear = now.getFullYear();
        const monthYearInput =
            document.getElementById("monthYearV").value || `${currentMonth}-${currentYear}`;
        const [month, year] = monthYearInput.split("-");
        try {
            const response = await axios.get(
                `${config.API_URL}Payroll/GetPaymentDetails?month=${month}&year=${year}`
            );
            const appsArray = response.data.data || [];
            setRoles(appsArray);

        } catch (error) {
            console.error('Error fetching emplopyee info:', error);
        } finally {
            setIsLoaderActive(false);
        }
    };

    const GetPayrollTemplates = async () => {
        setIsLoaderActive(true);
        try {
            const response = await axios.get(`${config.API_URL}Payroll/GetTempalates`);
            const payrollsArray = response.data.data || [];
            setPayroll(payrollsArray);
        } catch (error) {
            console.error('Error fetching payroll templates:', error);
        } finally {
            setIsLoaderActive(false);
        }
    };

    const GetDepartments = async () => {
        setIsLoaderActive(true);

        try {
            const response = await axios.get(
                `${config.API_URL}Department/GetAllDepartments`
            );
            const appsArray = response.data.data || [];
            setDepartments(appsArray);
        } catch (error) {
            console.error("Error fetching departments:", error);
        } finally {
            setIsLoaderActive(false);
        }
    };

    const handleDepartmentChange = (e) => {
        setSelectedDepartment(e.target.value);
    };
    // console.log("roles--->",roles);

    const filteredRoles = selectedDepartment == "all" ? roles : roles.filter(role => role.department == selectedDepartment);
    // console.log("selectedDepartment--->",selectedDepartment);
    // console.log("filteredRoles--->",filteredRoles);

    
    const handleCheckboxChange = (e, employeeName) => {
        if (e.target.checked) {
            setSelectedEmployees((prevSelected) => [...prevSelected, employeeName]);
        } else {
            setSelectedEmployees((prevSelected) =>
                prevSelected.filter((name) => name != employeeName)
            );
        }
    };

    const handleRemoveEmployee = (employeeName) => {
        setSelectedEmployees((prevSelected) =>
            prevSelected.filter((name) => name != employeeName)
        );
    };


    const handleSubmit = async () => {
        setIsLoaderActive(true);

        const now = new Date();
        const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
        const currentYear = now.getFullYear();

        const monthYearInput = document.getElementById("monthYearV").value || `${currentMonth}-${currentYear}`;
        const [month, year] = monthYearInput.split("-");

        const selectedEmployeeIds = roles
            .filter((role) => selectedEmployees.includes(role.firstName))
            .map((role) => role.empId);

        if (selectedEmployeeIds.length == 0) {
            toast.error("No employees selected for processing.");
            setIsLoaderActive(false);

            return;

        }
        // console.log("selectedEMpIn--->",selectedEmployeeIds);
        
        const payload = selectedEmployeeIds.map((empId) => ({
            empId,
            year,
            month,
            createdBy: personalInfo.userID,
            createdOn: new Date().toISOString(),
        }));

        try {
            const response = await axios.post(
                `${config.API_URL}Payroll/AddEmployeesToPaymentProcess`,
                payload
            );

            if (response.data.success) {
                toast.success(response.data.message);
                setSelectedEmployees([]);
                setSelectedDepartment('all');
                document.getElementById("monthYearV").value = `${currentMonth}-${currentYear}`;
                document.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
                    checkbox.checked = false;
                });
                window
                    .$("#monthYearV")
                    .on("change.datetimepicker", () => {
                        GetRoles();
                    });

            } else {
                toast.error(response.data.message);
            }
        } catch (error) {
            console.error("Error:", error.response?.data);
            const errorMessage =
                error.response?.data?.errors?.$?.[0] ||
                error.response?.data?.errors?.empId?.[0] ||
                'An error occurred';
            toast.error(errorMessage);
        } finally {
            setIsLoaderActive(false);
        }
    };





    return (
        <>
            <div className="content-header">
                <div className="container-fluid">
                    <div className="row mb-2">
                        <div className="col-sm-6">
                            <h5 className="m-0">Manage Payroll Process
                                <span hover-tooltip="In this you can process the payments for the employees in bulk or independently or by department wise. As the selected employees will be dispaly and you can deselect them as well." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span> </h5>
                        </div>
                        <div className="col-sm-6">
                            <ol className="breadcrumb float-sm-right">
                                <li className="breadcrumb-item">
                                    <Link to="/manage-employee">Home</Link>
                                </li>
                                <li className="breadcrumb-item active">Payroll Process</li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>

            <div className='container-fluid px-3'>
                <div className='card card-outline card-primary'>
                    <div className="card-header" >
                        <div className="row d-flex">
                            <div className="col-md-6">
                                <h5 className='mt-1 mb-0'>Employee Details<span hover-tooltip="This is a table showing employee details as Action: A checkbox for each employee, Employee Name, Payroll Template, Assigned CTC, Date of Joining, Contact No. Filter by Department and Search." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span> </h5>
                            </div>
                            <div className="col-md-6 pl-3">
                                <div className="row d-flex align-items-center">
                                    <div
                                        className="input-group col-md-3"
                                        id="year"
                                        data-target-input="nearest"
                                    >
                                        <input
                                            type="text"
                                            className="form-control form-control-sm"
                                            id="monthYearV"
                                            defaultValue={`${String(new Date().getMonth() + 1).padStart(2, '0')}-${new Date().getFullYear()}`}
                                            placeholder="Select Month"
                                            data-target="#monthYearV"
                                        />
                                        <div
                                            className="input-group-append"
                                            custDatePicker
                                            data-target="#monthYearV"
                                            data-toggle="datetimepicker"
                                        >
                                            <div className="input-group-text">
                                                <i className="fa fa-calendar"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-9">
                                        <div className="row d-flex" style={{ flexWrap: "nowrap" }}>
                                            <div className="col-md-8">
                                                <select
                                                    className="form-control form-control-sm"
                                                    id="userRoleNameInput"
                                                    value={selectedDepartment}
                                                    onChange={handleDepartmentChange}
                                                >
                                                    <option value="all" selected>
                                                        All Departments
                                                    </option>
                                                    {departments.map((role) => (
                                                        <option
                                                            key={role.departmentID}
                                                            value={role.departmentID}
                                                        >
                                                            {role.departmentName}
                                                        </option>
                                                    ))}
                                                </select>
                                            </div>
                                            <div className="col-md-4">
                                                <div className="row d-flex">
                                                    <div className="col-md-6 pl-3">
                                                        <button
                                                            type="button"
                                                            className="btn btn-sm btn-primary"
                                                            onClick={handleSubmit}
                                                        >
                                                            Submit
                                                        </button>
                                                    </div>
                                                    <div className="col-md-6 d-flex align-items-center pl-4">
                                                        <button
                                                            type="button"
                                                            className="btn btn-tool float-right"
                                                            data-card-widget="maximize"
                                                        >
                                                            <i className="fas fa-expand"></i>
                                                        </button>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    {selectedEmployees.length > 0 ? (
                        <div
                            className="card-header"
                            style={{ backgroundColor: "rgba(153, 198, 241, 0.39)" }}
                        >
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="button-container d-flex">
                                        {selectedEmployees.length > 0 ? (
                                            selectedEmployees.map((employee, index) => (
                                                <button
                                                    key={index}
                                                    className="btn btn-primary btn-xs m-1 d-flex justify-content-center align-items-center"
                                                >
                                                    {employee}
                                                    <span
                                                        type="button"
                                                        className="close text-sm ml-2 p-1"
                                                        style={{ cursor: "pointer", color: 'red' }}
                                                        onClick={() => handleRemoveEmployee(employee)}
                                                        checked={selectedEmployees.includes(employee)}
                                                        onChange={(e) => handleCheckboxChange(e, employee)}
                                                    >
                                                        <i className="fas fa-times"></i>
                                                    </span>
                                                </button>
                                            ))
                                        ) : null}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : null}
                    <div className='card-body text-sm position-relative'>
                        {isLoaderActive && (
                            <div
                                style={{
                                    position: "absolute",
                                    top: 0,
                                    left: 0,
                                    width: "100%",
                                    height: "100%",
                                    backgroundColor: "rgb(233 236 239 / 81%)",
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "center",
                                    zIndex: 10,
                                }}
                            >
                                <i
                                    className="fas fa-sync-alt fa-spin"
                                    style={{ fontSize: "2rem", color: "#333" }}
                                ></i>
                            </div>
                        )}
                        <table id="example1" class="table table-bordered table-sm table-striped">
                            <thead>
                                <tr>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Action</th>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Employee Name</th>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Payroll Template</th>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Assigned CTC</th>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Date of Joining</th>
                                    <th style={{ fontWeight: '500', fontSize: 'smaller' }}>Contact No</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredRoles.length > 0 ? (
                                    filteredRoles.map((roleObj) => {
                                        const template = payroll.find(
                                            (template) => template.autoId == roleObj.payrollTempId);
                                        const templateName = template ? template.templateName : "N/A";

                                        return (
                                            <tr key={roleObj.empId || roleObj.firstName}>
                                                <td className='text-center' style={{ fontWeight: '400', fontSize: 'smaller' }}>
                                                    <input
                                                        type="checkbox"
                                                        checked={
                                                            selectedEmployees.includes(roleObj.firstName) ||
                                                            Boolean(roleObj.paymentStatus)
                                                        }
                                                        onChange={(e) => handleCheckboxChange(e, roleObj.firstName)}
                                                    />
                                                </td>
                                                <td style={{ fontWeight: '400', fontSize: 'smaller' }}>{roleObj.firstName}</td>
                                                <td style={{ fontWeight: '400', fontSize: 'smaller' }}>{templateName}</td>
                                                <td style={{ fontWeight: '400', fontSize: 'smaller' }}>{roleObj.assignedCTC}</td>
                                                <td style={{ fontWeight: '400', fontSize: 'smaller' }}>{roleObj.joiningDate}</td>
                                                <td style={{ fontWeight: '400', fontSize: 'smaller' }}>{roleObj.mobile}</td>
                                            </tr>
                                        );
                                    })
                                ) : (
                                    <tr>
                                        <td colSpan="6" className="text-center">No employees found</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div >
            <ToastContainer position="top-center" />
        </>
    )
}

export default PayrollProcess