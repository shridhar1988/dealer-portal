import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import $ from "jquery";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";
import config from "../../config/config.json";
import { Link } from "react-router-dom";
import PleaseWaitButton from "../../shared/PleaseWaitButton";

import "./PayrollTemplate.css";

let pageLoadCount = 0;

function PayrollTemplate() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const personalInfo = useSelector((state) => state.personalInformationReducer);
  const inputComponentReference = useRef(null);
  const [addNewSectionsDisplay, setAddNewSectionsDisplay] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState("");
  const [component, setComponent] = useState('');
  const [payrollTemplateName, setPayrollTemplateName] = useState("");
  const [probationType, setProbationType] = useState("");
  const [allTempalatesArray, setAllTempalatesArray] = useState([]);
  const [payrollComponents, setPayrollComponents] = useState([]);
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [salaryComponentsArray, setSalaryComponentsArray] = useState([{
    componentName: "",
    percentage: "",
    isPercentageOrAmount: "per",
    salaryComponentsType: "addition"
  }]);

  const AddNewPayrollTemplateClickHandler = (e) => {
    setAddNewSectionsDisplay(true);
  };

  const cancleAddNewPayrollTemplateClickHandler = (e) => {
    setAddNewSectionsDisplay(false);
    setSelectedTemplateId("");
    GetAllTempalates();
    setPayrollTemplateName("");
    setProbationType("");
    setSalaryComponentsArray([{
      componentName: "",
      percentage: "",
      isPercentageOrAmount: "per",
      salaryComponentsType: "addition"
    }]);
  };

  useEffect(() => {
    GetAllTempalates();
    GetAllPayrollComponents();
  }, []);

  const GetAllTempalates = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(config.apiEndPoint + "/Payroll/GetTempalates");
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);
      setAllTempalatesArray(tempalatesArray);
    } catch (error) {
      console.error('Error fetching tempalates:', error);
      toast.error('Error fetching tempalates');
    } finally {
      setIsLoaderActive(false);
    }
  };

  const percentageOrRupeesChangeHandler = (getSelectedChangedValue, getIndexToChange) => {
    setSalaryComponentsArray(prevArray => {
      // Create a copy of the array and modify the object at the specified index
      const updatedArray = [...prevArray];
      updatedArray[getIndexToChange] = {
        ...updatedArray[getIndexToChange], // Copy the existing object at that index
        isPercentageOrAmount: getSelectedChangedValue // Update the specific field (IsPercentageOrAmount)
      };
      return updatedArray; // Return the updated array
    });
  };

  const salaryComponentsTypeChangeHandler = (getSelectedChangedValue, getIndexToChange) => {
    setSalaryComponentsArray(prevArray => {
      // Create a copy of the array and modify the object at the specified index
      const updatedArray = [...prevArray];
      updatedArray[getIndexToChange] = {
        ...updatedArray[getIndexToChange], // Copy the existing object at that index
        salaryComponentsType: getSelectedChangedValue // Update the specific field (IsPercentageOrAmount)
      };
      return updatedArray; // Return the updated array
    });
  };



  const removeComponentFromArray = (indexToRemove) => {
    // Filter out the item at the provided index
    setSalaryComponentsArray(prevArray =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(salaryComponentsArray);
  };

  const addNewSalaryComponents = () => {
    let tempObj = {
      componentName: "",
      percentage: "",
      isPercentageOrAmount: "per",
      salaryComponentsType: "addition"
    };

    // Instead of mutating the array, create a new array
    setSalaryComponentsArray(prevArray => [...prevArray, tempObj]);
    initSortableTable(salaryComponentsArray);
  }

  const initSortableTable = (getSalaryComponentsArray) => {
    setTimeout(() => {
      window.$("#faqs").sortable({
        items: 'tr:not(tr:first-child)',
        cursor: 'pointer',
        axis: 'y',
        dropOnEmpty: false,
        start: function (e, ui) {
          ui.item.addClass("selected");
        },
        stop: function (e, ui) {
          ui.item.removeClass("selected");
          $(this).find("tr").each(function (index) {
            if (index > 0) {

              // allTasksArray = projectTaskListData;
              // //console.log("Sort allTasksArray ===>", allTasksArray);
              // createTableDesign(allTasksArray)
            }
          });
        }
      });
    }, 1000)
  }

  const handleSalaryComponentsNameChange = (e, index, inputName) => {
    if (inputName == 'name') {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the salaryComponentsArray by creating a new array and modifying the object at the specific index
      setSalaryComponentsArray(prevArray => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index],  // Copy the current object at that index
          componentName: updatedValue // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    } else {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the salaryComponentsArray by creating a new array and modifying the object at the specific index
      setSalaryComponentsArray(prevArray => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index],  // Copy the current object at that index
          percentage: updatedValue // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    }


  };

  const savePayrollTemplateClickHandler = async () => {
    // console.log("salaryComponentsArray: ", salaryComponentsArray);


    // Calculate the total percentage
    const totalPercentage = salaryComponentsArray.reduce((total, component) => {
      const percentage = parseFloat(component.percentage) || 0; // Default to 0 if NaN
      return total + percentage;
    }, 0);

    // Validate total percentage
    // if (totalPercentage > 100) {
    //   toast.error("The total percentage of all components cannot exceed 100%.");
    //   return; // Exit the function if validation fails
    // }



    var salaryComponentsRows = $("#tblBodyId tr");
    var newSalaryComponentsListData = [];
    salaryComponentsRows.each(function () {
      // Get the 'custAttr' value from the second <td> in the row
      var getIndex = $(this).find('td:eq(1)').attr('custAttr');
      // console.log("getIndex ...", getIndex);

      // Check if getIndex is a valid index/key in getSalaryComponentsArray
      if (salaryComponentsArray.hasOwnProperty(getIndex)) {
        // Push the corresponding value into the new list if it's not undefined
        if (salaryComponentsArray[getIndex] !== undefined) {
          let tempObj = {
            componentName: salaryComponentsArray[getIndex].componentName,
            percentage: salaryComponentsArray[getIndex].percentage,
            isPercentageOrAmount: salaryComponentsArray[getIndex].isPercentageOrAmount,
            salaryComponentsType: salaryComponentsArray[getIndex].salaryComponentsType
          };
          newSalaryComponentsListData.push(tempObj);
        }
      } else {
        // console.log("No match found for getIndex:", getIndex);
      }
    });


    // console.log("newSalaryComponentsListData ...", newSalaryComponentsListData);
    window.$("#tblBodyId tr").each(function () {
      $(this).find("input[name='SalaryComponentsNameInput']").each(function () {
        if (window.$(this).val()) {
          window.$(this).removeClass('is-invalid');
        }
      });
      $(this).find("input[name='PercentageInput']").each(function () {
        if (window.$(this).val()) {
          window.$(this).removeClass('is-invalid');
        }
      });
    });
    window.$("#PayrollTemplateNameInput").removeClass('is-invalid');
    window.$("#ProbationTypeInput").removeClass('is-invalid');
    if (payrollTemplateName) {
      if (probationType) {
        let tempValidationBit = true;
        window.$("#tblBodyId tr").each(function () {
          $(this).find("select[name='SalaryComponentsNameInput']").each(function () {
            if (!window.$(this).val()) {
              window.$(this).addClass('is-invalid');
              tempValidationBit = false;
              toast.error("Select salary component");
              return;
            }
          });
          $(this).find("input[name='PercentageInput']").each(function () {
          
            
            if (!window.$(this).val()) {
              window.$(this).addClass('is-invalid');
              tempValidationBit = false;
              toast.error("Enter salary component percentage");
              return;
            }
          });
        });

        setTimeout(async () => {
          if (tempValidationBit) {
            const formData = {
              templateName: payrollTemplateName.trim(),
              probationType: probationType.trim(),
              createdBy: personalInfo.userID,
              checkId: selectedTemplateId,
              payrollSubDtos: newSalaryComponentsListData
            };
            setIsLoaderActive(true);
            const response = await axios.post(config.apiEndPoint + "/Payroll/CreateTemplates",
              formData
            );
            const returnData = response.data.data || [];
            if (response.data.success == "True") {
              toast.success(response.data.message);
              setAddNewSectionsDisplay(false);
              setSelectedTemplateId("");
              GetAllTempalates();
              setPayrollTemplateName("");
              setProbationType("");
              setSalaryComponentsArray([{
                componentName: "",
                percentage: "",
                isPercentageOrAmount: "per",
                salaryComponentsType: "addition"
              }]);
            }
          }
          setIsLoaderActive(false);
        }, 500);
      } else {
        toast.error("Please Select Probation Type.");
        window.$("#ProbationTypeInput").focus();
        window.$("#ProbationTypeInput").addClass('is-invalid');
      }
    } else {
      toast.error("Please Enter Payroll Template Name.");
      window.$("#PayrollTemplateNameInput").focus();
      window.$("#PayrollTemplateNameInput").addClass('is-invalid');
    }
  };

  const handlePayrollTemplateEditChange = (e, getInputName) => {
    const { name, value } = e.target;
    if (getInputName == 'name') {
      setPayrollTemplateName(value);
    } else {
      setProbationType(value)
    }
  };

  const templateDropDownChangeHandler = async (getSelectedTemplateId) => {
    setIsLoaderActive(true);
    setSelectedTemplateId(getSelectedTemplateId);
    try {
      const response = await axios.get(config.apiEndPoint + "/Payroll/GetTempalateByTemplateId?id=" + getSelectedTemplateId);
      const tempalatesArray = response.data.data || [];
      // console.log("tempalatesArray ===> ", tempalatesArray);

      if (response.data.success) {
        // console.log("tempalatesArray[0]['payrollTemplateMaster'].templateName ===> ", tempalatesArray[0]['payrollTemplateMaster'].templateName);
        setPayrollTemplateName(tempalatesArray[0]['payrollTemplateMaster'].templateName);
        setProbationType(tempalatesArray[0]['payrollTemplateMaster'].probationType);
        setSalaryComponentsArray(tempalatesArray[0]['payrollComponents']);
        setAddNewSectionsDisplay(true);
        initSortableTable(tempalatesArray[0]['payrollComponents']);
      }
      //setPayrollTemplateName()
      //   setAllTempalatesArray(tempalatesArray);
    } catch (error) {
      console.error('Error fetching tempalates:', error);
      toast.error('Error fetching tempalates');
    } finally {
      setIsLoaderActive(false);
    }
  };

  const RemovePayrollTemplateClickHandler = async () => {
    window.$("#deleteModal").modal("show");
  };

  const hideModal = async () => {
    window.$("#deleteModal").modal("hide");
  };

  const confirmDeleteTemplate = async () => {
    setIsLoaderActive(true);
    const response = await axios.post(config.apiEndPoint + "/Payroll/deleteTempalate?templateId=" + selectedTemplateId);
    const tempalatesArray = response.data.data || [];
    // console.log("tempalatesArray ===> ", tempalatesArray);

    if (response.data.success) {
      // console.log("response ===> ", response);
      setPayrollTemplateName("");
      setProbationType("");
      setSalaryComponentsArray([{
        componentName: "",
        percentage: "",
        isPercentageOrAmount: "per",
        salaryComponentsType: "addition"
      }]);
      setAddNewSectionsDisplay(false);
      setSelectedTemplateId("");
      window.$("#deleteModal").modal("hide");
      GetAllTempalates();
      toast.error('Payroll template deleted successfully...');
    }
    setIsLoaderActive(false);
  };

  const showModal = async () => {
    window.$("#showModal").modal("show");
  }

  const closeModal = async () => {
    window.$("#showModal").modal("hide");
  }

  const handleSave = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.post(
        `${config.API_URL}Payroll/AddPayrollComponent`,
        {
          componentName: component,
          createdBy: personalInfo.userID,
        }
      );

      if (response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
        setIsLoaderActive(false);
        setComponent('');
      } else {
        setIsLoaderActive(false);
        toast.error(response.data.message);
      }
    } catch (error) {
      if (error.response && error.response.data && error.response.data.message) {
        toast.error(error.response.data.message);
      } else {
        toast.error("Please try again later.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };

  const GetAllPayrollComponents = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(config.apiEndPoint + "/Payroll/GetAllPayrollComponents");
      const componentsArray = response.data.data || [];
      // console.log("GetAllPayrollComponents ===> ", componentsArray);
      setPayrollComponents(componentsArray);
    } catch (error) {
      console.error('Error fetching components:', error);
      setPayrollComponents([]);
      toast.error('Error fetching components');
    } finally {
      setIsLoaderActive(false);
    }
  }

  const handleDelete = async (userObj) => {
    try {
      setIsLoaderActive(true);
      const response = await axios.post(`${config.apiEndPoint}/Payroll/DeleteComponent/${userObj.autoId}`);

      if (response.data.success == "True") {
        toast.success(response.data.message);
        GetAllPayrollComponents();
      } else {
        toast.error(response.data.message);
      }
      setIsLoaderActive(false);
    } catch (error) {
      if (error.response && error.response.data) {
        toast.error(error.response.data.message || "An error occurred.");
      } else {
        toast.error("Please try again later.");
      }
      setIsLoaderActive(false);
    } finally {
      setIsLoaderActive(false);
    }
  };



  return (
    <>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h5 className="m-0">Manage Payroll Template<span hover-tooltip="In this page you can manage payroll templates by selecting an existing template from the dropdown menu or click the 'Add New Payroll Template' button to create a new one." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span> </h5>

            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/manage-employee">Home</Link>
                </li>
                <li className="breadcrumb-item active">Manage Payroll Template</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
      <div className="container-fluid">
        <div className="col-md-12">
          {/* First Card Section */}
          <div className="card card-outline card-primary">
            <div className="card-header">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <h3 className="card-title">
                    Manage Payroll Templates{" "}
                    {addNewSectionsDisplay == true ?
                      <span hover-tooltip="This Manage Payroll Templates page allows creating custom payroll templates. Each payroll component, such as HRA, TA, or other allowances, can be assigned either a percentage or a fixed amount in rupees. These templates can then be selected during employee onboarding for streamlined payroll management." tooltip-position="bottom"><i class="fas fa-info-circle" style={{ marginLeft: "5px", cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span>
                      : null
                    }

                    {/* <em style={{ fontSize: "12px" }}>
                      ( Add details of an payroll templates )
                    </em> */}
                  </h3>
                  {addNewSectionsDisplay == false ?
                    <select
                      className="form-control form-control-sm w-50 ml-5"
                      id="userRoleNameInput"
                      style={{ display: 'inline-block' }}
                      defaultValue={selectedTemplateId}
                      onChange={(e) => templateDropDownChangeHandler(e.target.value)}
                    >
                      <option value="">Select Template</option>
                      {allTempalatesArray.map((tempalate) => (
                        <option key={tempalate.autoId} value={tempalate.autoId}>
                          {tempalate.templateName}
                        </option>
                      ))}
                      {/* <option value="Fresher Template">Fresher Template</option>
                      <option value="Less Than 2 Year Experience Template">Less Than 2 Year Experience Template</option>
                      <option value="Greater Than 2 And Less Than 5 Year Experience Template">Greater Than 2 And Less Than 5 Year Experience Template</option>
                      <option value="Greater Than 5 And Less Than 10 Year Experience Template">Greater Than 5 And Less Than 10 Year Experience Template</option>
                      <option value="Greater Than 10 Year Experience Template">Greater Than 10 Year Experience Template</option> */}
                    </select>
                    : null
                  }

                </div>

                <div className="col-md-6 float-right">
                  <div className="card-tools float-right mt-1">
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>

                  {addNewSectionsDisplay == false ?
                    <button
                      className="btn btn-sm float-right btn-primary mr-1"
                      type="button"
                      onClick={() => AddNewPayrollTemplateClickHandler()}
                    >
                      Add New Payroll Template
                    </button>
                    :
                    <>
                      <button
                        className="btn btn-sm float-right btn-default mr-1"
                        onClick={() => { cancleAddNewPayrollTemplateClickHandler() }}
                        type="button"
                      >
                        Cancel
                      </button>
                      {isLoaderActive ? <PleaseWaitButton className='float-right btn-sm mr-2 font-weight-medium auth-form-btn' /> :
                        <button
                          className="btn btn-sm float-right btn-primary mr-2"
                          onClick={() => { savePayrollTemplateClickHandler() }}
                          type="button"
                        >
                          Save Payroll Template
                        </button>
                      }
                    </>
                  }
                  {selectedTemplateId != "" ?
                    <button
                      className="btn btn-sm float-right btn-danger mr-1"
                      type="button"
                      onClick={() => RemovePayrollTemplateClickHandler()}
                    >
                      Remove Payroll Template
                    </button>
                    : null}
                </div>
              </div>
            </div>
            <div className="card-body position-relative">
              {isLoaderActive && (
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    backgroundColor: "rgb(233 236 239 / 81%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    zIndex: 10,
                  }}
                >
                  <i
                    className="fas fa-sync-alt fa-spin"
                    style={{ fontSize: "2rem", color: "#333" }}
                  ></i>
                </div>
              )}
              {addNewSectionsDisplay == true ?
                <div className="row">
                  <div className="col-md-8">
                    <label className="form-label" htmlFor="option1">
                      Payroll Template Name <span className="text-danger"> *</span>
                    </label>
                    <div className="input-group input-group-merge speech-to-text">
                      <input
                        type="text"
                        className={`form-control form-control-sm`}
                        id="PayrollTemplateNameInput"
                        placeholder="Enter Payroll Template Name"
                        name="name"
                        defaultValue={payrollTemplateName}
                        onChange={(e) => handlePayrollTemplateEditChange(e, 'name')}
                      />

                    </div>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label" htmlFor="option1">
                      Select Probation Type? <span className="text-danger"> *</span>
                    </label>
                    <select
                      className="form-control form-control-sm"
                      id="ProbationTypeInput"
                      defaultValue={probationType}
                      onChange={(e) => handlePayrollTemplateEditChange(e, 'probation')}
                    >
                      <option value="">Select Probation Type</option>
                      <option value="Probation Period">Probation Period</option>
                      <option value="Non Probation Period">Non Probation Period</option>
                    </select>
                  </div>

                  <div className="col-md-12 mt-3">
                    <div className="table-responsive">
                      <table id="faqs" className="table table-bordered table-sm">
                        <thead>
                          <tr className="text-sm">
                            <th width="2%"></th>
                            <th width="6%">Sr. No.</th>
                            <th width="30%">Salary Components {" "} <label
                              className="ml-3 text-sm mb-0"
                              style={{ color: '#2b5bc9', cursor: "pointer" }}
                              onClick={showModal}
                            >
                              + Add New
                            </label>  <span hover-tooltip="In this 'Add New' you can create and delete the salary components which will be shown in the dropdown of the salary components." tooltip-position="bottom"><i class="fas fa-info-circle mx-2" style={{ cursor: 'pointer', color: "rgb(0 0 0 / 51%)" }}></i></span></th>
                            <th width="12%">Percentage (%)</th>
                            <th width="10%">Is Per(%)</th>
                            <th width="10%">Components Type</th>
                            <th width="6%">Status</th>
                          </tr>
                        </thead>
                        <tbody id="tblBodyId">
                          {salaryComponentsArray.length > 0
                            ? salaryComponentsArray.map((data, index) => (
                              <tr key={index} >
                                <td className="text-center" style={{ background: '#238edc' }}>
                                  <span className="handle ui-sortable-handle mt-5">
                                    <i className="fas fa-ellipsis-v"></i>
                                    <i className="fas fa-ellipsis-v"></i>
                                  </span>
                                </td>
                                <td custAttr={index}>{index + 1}</td>
                                <td>
                                  <select
                                    name="SalaryComponentsNameInput"
                                    className="form-control form-control-sm"
                                    value={data.componentName || ""}
                                    onChange={(e) => handleSalaryComponentsNameChange(e, index, 'name')}
                                  >
                                    <option value="" disabled>
                                      Select Salary Component
                                    </option>
                                    {payrollComponents.map((component, i) => (
                                      <option key={i} value={component.autoId}>
                                        {component.componentName}
                                      </option>
                                    ))}
                                  </select>

                                </td>
                                <td><input type="text" name="PercentageInput" placeholder="Enter Salary Components Percentage (%)" value={data.percentage != "" ? data.percentage : null} onChange={(e) => handleSalaryComponentsNameChange(e, index, 'percentage')} className="form-control form-control-sm numberAndFloatInput" /></td>
                                <td>
                                  <select
                                    className="form-control form-control-sm"
                                    id="PercentageOrRupees"
                                    defaultValue={data.isPercentageOrAmount}
                                    onChange={(e) => percentageOrRupeesChangeHandler(e.target.value, index)}
                                  >
                                    <option value="per" >Percentage</option>
                                    <option value="rs">Rupees</option>
                                  </select>
                                </td>
                                <td>
                                  <select
                                    className="form-control form-control-sm"
                                    id="SalaryComponentsType"
                                    defaultValue={data.salaryComponentsType}
                                    onChange={(e) => salaryComponentsTypeChangeHandler(e.target.value, index)}
                                  >
                                    <option value="addition" >Addition</option>
                                    <option value="deduction">Deduction</option>
                                  </select>
                                </td>
                                <td><span className="btn btn-outline-danger btn-sm cursor-pointer" onClick={() => removeComponentFromArray(index)} title="Delete"><i className="fas fa-trash"></i></span></td>
                              </tr>
                            ))
                            : null}

                        </tbody>
                      </table>
                    </div>
                    <div className="text-right"><button onClick={() => addNewSalaryComponents()} className="btn btn-sm float-right btn-light">+ Add New Salary Components</button></div>
                  </div>
                </div>
                :
                <h4></h4>
              }

            </div>
          </div>
        </div>
      </div>
      <div
        class="modal fade"
        id="deleteModal"
        data-backdrop="static"
        data-keyboard="false"
        tabindex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          class="modal-dialog modal-sm modal-dialog-centered"
          role="document"
        >
          <div class="modal-content">
            <div class="modal-header">
              <h6 class="modal-title w-100 text-center" id="exampleModalLabel2">
                Are you sure?
              </h6>
              <button
                type="button"
                onClick={() => hideModal()}
                class="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body justify-content-center">
              <i
                class="w-100 text-center text-warning mb-3 fa fa-ban"
                style={{ fontSize: "3rem" }}
              ></i>
              <h6 class="text-center">
                Do you really want to delete these payroll template?
              </h6>
              <h6 class="text-center text-danger">
                This process cannot be undone.
              </h6>
            </div>
            <div class="modal-footer justify-content-center">
              <button
                type="button"
                class="btn btn-secondary"
                onClick={() => hideModal()}
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                Cancel
              </button>
              <button
                type="button"
                class="btn btn-danger"
                onClick={() => confirmDeleteTemplate()}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      </div>

      <div
        className="modal fade"
        id="showModal"
        data-backdrop="static"
        data-keyboard="false"
        tabIndex="-1"
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div
          className="modal-dialog modal-md modal-dialog-centered"
          role="document"
        >
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="mb-0">Create New Payroll Component</h5>
              <button
                type="button"
                onClick={closeModal}
                className="close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div className="modal-body justify-content-center">
              <div className="row">
                <div className="col-md-8">
                  <label >Component Name</label>
                  <input
                    type="text"
                    className="form-control form-control-sm"
                    value={component}
                    placeholder="Enter Component Name"
                    ref={inputComponentReference}
                    onChange={(e) =>
                      setComponent(e.target.value)
                    }
                  />
                </div>
                <div className="col-md-4 d-flex pl-4" style={{ alignItems: 'flex-end' }}>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm mr-2"
                    onClick={closeModal}
                    data-bs-dismiss="modal"
                    aria-label="Close"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={handleSave}
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <table className="table table-bordered table-striped table-sm">
                <thead>
                  <tr className="text-sm">
                    <th className="text-center">Sr. No.</th>
                    <th className="text-center">Component Name </th>
                    <th className="text-center">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {payrollComponents.length > 0 ? (
                    payrollComponents.map((userObj, index) => (
                      <tr
                        key={index}
                        style={{ textDecoration: userObj.isDeleted == true ? 'line-through' : 'none' }}
                      >
                        <td style={{ fontWeight: 400, fontSize: "smaller" }} className="text-center text-sm">
                          {index + 1}
                        </td>
                        <td style={{ fontWeight: 400, fontSize: "smaller" }}>
                          {userObj.componentName || "N/A"}
                        </td>
                        <td style={{ fontWeight: '400', fontSize: 'smaller' }} onClick={(e) => { handleDelete(userObj) }} className='text-center text-sm'>
                          {!userObj.isDeleted && (
                            <button type="button" className="btn bg-gradient-danger btn-xs ml-2">
                              <i className="fas fa-trash"></i>
                            </button>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={3} className="text-center text-muted">
                        No Payroll Components Available
                      </td>
                    </tr>
                  )}
                </tbody>

              </table>
            </div>
          </div>
        </div>
      </div>

      <ToastContainer position="top-center" />
    </>
  );
}

export default PayrollTemplate;
