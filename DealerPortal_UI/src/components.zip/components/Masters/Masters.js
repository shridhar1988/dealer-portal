import React from "react";
import { Link } from "react-router-dom";

function Masters() {

  return (
    <div>
      <div className="content-header">
        <div className="container-fluid">
          <div className="row mb-2">
            <div className="col-sm-6">
              <h1 className="m-0">Masters List</h1>
            </div>
            <div className="col-sm-6">
              <ol className="breadcrumb float-sm-right">
                <li className="breadcrumb-item">
                  <Link to="/form-builder">Home</Link>
                </li>
                <li className="breadcrumb-item active">Masters</li>
              </ol>
            </div>
          </div>
        </div>
      </div>

      <section className="content">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12">
              <div className="card card-outline">
                <div className="card-header">
                  <h3 className="card-title text-sm">Masters</h3>
                  <div className="card-tools">
                    <button
                      type="button"
                      className="btn btn-tool"
                      data-card-widget="maximize"
                    >
                      <i className="fas fa-expand"></i>
                    </button>
                  </div>
                </div>
                <div className="card-body">
                  <div className="row ml-3">
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/AppMaster"}
                    >
                      Apps
                    </Link>
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/RoleswithApps"}
                    >
                      Roles
                    </Link>
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/manage-leaveTypes"}
                    >
                      Leave Types
                    </Link>
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/manage-departments"}
                    >
                      Departments
                    </Link>
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/location-master"}
                    >
                      Locations
                    </Link>
                    <Link
                      className="btn btn-sm btn-primary mr-3 text-sm"
                      to={"/manage-designations"}
                    >
                      Designations
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Masters;