import React, { useState, useEffect } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import { Link } from "react-router-dom";
import config from "../../config/config.json";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import PleaseWaitButton from "../../shared/PleaseWaitButton";
import $ from "jquery";

function ManageTaxSlab() {
  const [isLoaderActive, setIsLoaderActive] = useState(false);
  const [departments, setDepartments] = useState([]);
  const [fetchPreviousYear, setFetchPreviousYear] = useState(false);
  const [saveTemplate, setSaveTemplate] = useState(false);
  const [previousYearDataLoaded, setPreviousYearDataLoaded] = useState(false);
  const [selectedYear, setSelectedYear] = useState("");
  const currentYear = new Date().getFullYear();
  const [selectedRegime, setSelectedRegime] = useState("new");

  const [slabTaxComponentsArray, setSlabTaxComponentsArray] = useState([
    {
      minIncome: "",
      maxIncome: "",
      taxRate: "",
      isPercentageOrAmount: "per",
    },
  ]);

  // Define the array with the property names

  useEffect(() => {
    GetDepartments();
    window.initDataTableFuncation();
    window.initDatePickerFuncation();
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    setSelectedYear(defaultYear);
    window.$("#dateV").datetimepicker({
      format: "MM-YYYY",
      minDate: new Date(2016, 0),
      viewMode: "months",
      maxDate: new Date(),
    });
    window.$("#dateV").on("change.datetimepicker", () => { });
  }, []);
  const generateYears = () => {
    let years = [];
    let startYear = 2016;
    for(let i = startYear; i <= currentYear; i++) {
      years.push(`${i}-${i + 1}`);
    }

    return years;
  };

  const showModal = async () => {
    window.$("#showModal").modal("show");
  };
  const initSortableTable = (getslabTaxComponentsArray) => {
    setTimeout(() => {
      window.$("#faqs").sortable({
        items: "tr:not(tr:first-child)",
        cursor: "pointer",
        axis: "y",
        dropOnEmpty: false,
        start: function(e, ui) {
          ui.item.addClass("selected");
        },
        stop: function(e, ui) {
          ui.item.removeClass("selected");
          $(this)
            .find("tr")
            .each(function(index) {
              if(index > 0) {
                // allTasksArray = projectTaskListData;
                // //console.log("Sort allTasksArray ===>", allTasksArray);
                // createTableDesign(allTasksArray)
              }
            });
        },
      });
    }, 1000);
  };
  const GetDepartments = async () => {
    setIsLoaderActive(true);
    try {
      const response = await axios.get(
        `${config.API_URL}Department/GetAllDepartments`
      );
      const appsArray = response.data.data || [];
      setDepartments(appsArray);
      // console.log("all department-->", appsArray);
    } catch(error) {
      console.error("Error fetching departments:", error);
      toast.error("Error fetching departments");
    } finally {
      setIsLoaderActive(false);
    }
  };
  const removeComponentFromArray = (indexToRemove) => {
    // Filter out the item at the provided index
    setSlabTaxComponentsArray((prevArray) =>
      prevArray.filter((_, index) => index !== indexToRemove)
    );
    initSortableTable(slabTaxComponentsArray);
  };
  const handleSalaryComponentsNameChange = (e, index, inputName) => {
    if(inputName == "name") {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the slabTaxComponentsArray by creating a new array and modifying the object at the specific index
      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          minIncome: updatedValue, // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    } else if(inputName == "maxname") {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the slabTaxComponentsArray by creating a new array and modifying the object at the specific index
      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          maxIncome: updatedValue, // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    } else {
      const updatedValue = e.target.value; // Get the new value from the input field

      // Update the slabTaxComponentsArray by creating a new array and modifying the object at the specific index
      setSlabTaxComponentsArray((prevArray) => {
        const updatedArray = [...prevArray]; // Make a shallow copy of the array
        updatedArray[index] = {
          ...updatedArray[index], // Copy the current object at that index
          taxRate: updatedValue, // Update the ComponentName
        };
        return updatedArray; // Return the updated array
      });
    }
  };

  const cancleBtnClickHandler = () => {
    const defaultYear = `${currentYear}-${currentYear + 1}`;
    setSelectedYear(defaultYear);
    setSelectedRegime("new");
    setSlabTaxComponentsArray([
      {
        minIncome: "",
        maxIncome: "",
        taxRate: "",
        isPercentageOrAmount: "per",
      },
    ]);
  };

  const addNewSalaryComponents = () => {
    let tempObj = {
      minIncome: "",
      maxIncome: "",
      taxRate: "",
      isPercentageOrAmount: "per",
    };

    // Instead of mutating the array, create a new array
    setSlabTaxComponentsArray((prevArray) => [...prevArray, tempObj]);
    initSortableTable(slabTaxComponentsArray);
  };

  const cardClickHandler = (value) => {
    setSelectedRegime(value); // Set the regime state
  };

  useEffect(() => {
    if(selectedYear && selectedRegime) {
      GetSlabDataByYear(); // Fetch data when regime or year changes
    }
  }, [selectedRegime, selectedYear]);

  const savePayrollTemplateClickHandler = async () => {
    // console.log("slabTaxComponentsArray: ", slabTaxComponentsArray);

    var salaryComponentsRows = $("#tblBodyId tr");
    var newSalaryComponentsListData = [];
    salaryComponentsRows.each(function() {
      // Get the 'custAttr' value from the second <td> in the row
      var getIndex = $(this).find("td:eq(1)").attr("custAttr");
      // console.log("getIndex ...", getIndex);

      // Check if getIndex is a valid index/key in getslabTaxComponentsArray
      if(slabTaxComponentsArray.hasOwnProperty(getIndex)) {
        // Push the corresponding value into the new list if it's not undefined
        if(slabTaxComponentsArray[getIndex] !== undefined) {
          let tempObj = {
            componentName: slabTaxComponentsArray[getIndex].componentName,
            percentage: slabTaxComponentsArray[getIndex].percentage,
            isPercentageOrAmount:
              slabTaxComponentsArray[getIndex].isPercentageOrAmount,
          };
          newSalaryComponentsListData.push(tempObj);
        }
      } else {
        // console.log("No match found for getIndex:", getIndex);
      }
    });

    // console.log("newSalaryComponentsListData ...", newSalaryComponentsListData);
    window.$("#tblBodyId tr").each(function() {
      $(this)
        .find("input[name='SalaryComponentsNameInput']")
        .each(function() {
          if(window.$(this).val()) {
            window.$(this).removeClass("is-invalid");
          }
        });
      $(this)
        .find("input[name='PercentageInput']")
        .each(function() {
          if(window.$(this).val()) {
            window.$(this).removeClass("is-invalid");
          }
        });
    });
    window.$("#SalaryComponentsNameInput").removeClass("is-invalid");
    window.$("#PercentageInput").removeClass("is-invalid");

    let tempValidationBit = true;
    window.$("#tblBodyId tr").each(function() {
      $(this)
        .find("input[name='SalaryComponentsNameInput']")
        .each(function() {
          if(!window.$(this).val()) {
            window.$(this).addClass("is-invalid");
            tempValidationBit = false;
            toast.error("Enter Tax Slab");
            return;
          }
        });
      if(!tempValidationBit) return false;
      $(this)
        .find("input[name='PercentageInput']")
        .each(function() {
          if(!window.$(this).val()) {
            window.$(this).addClass("is-invalid");
            tempValidationBit = false;
            toast.error("Enter Percentage");
            return;
          }
        });
    });

    setTimeout(async () => {
      if(tempValidationBit) {
        // const formData = {
        //   regimeId: selectedRegime.trim(),
        //   year: selectedYear.trim(),
        //   //   createdBy: personalInfo.userID,
        //   taxSlabData: newSalaryComponentsListData,
        // };
        PostTaxSlab();
      }
      setIsLoaderActive(false);
    }, 500);
  };
  const PostTaxSlab = async () => {
    // alert();
    setIsLoaderActive(true);

    try {
      const taxSlabDetail = slabTaxComponentsArray.map((item) => ({
        minIncome: item.minIncome, // Mapping componentName to minIncome
        maxIncome: item.maxIncome,
        taxRate: item.taxRate, // Mapping percentage to taxRate
      }));

      const requestData = {
        regime: selectedRegime,
        financialYear: selectedYear,
        taxSlabDetail: taxSlabDetail,
      };
      const response = await axios.post(
        `${config.API_URL}TaxSlabMaster/CreateTaxSlab`,
        requestData,
        {
          headers: {
            "Content-Type": "application/json; charset=utf-8",
          },
        }
      );
      if(response.data.success) {
        setFetchPreviousYear(false);
        toast.success(response.data.message);
        setIsLoaderActive(false);
      } else {
        toast.error(response.data.message);
        setIsLoaderActive(false);
      }
    } catch {
      toast.error("Error while saving tax slab");
      setIsLoaderActive(false);

    } finally {
      setIsLoaderActive(false);

    }
  };

  const GetSlabDataByYear = async (year = selectedYear) => {
    setIsLoaderActive(true);

    try {
      const response = await axios.get(
        `${config.API_URL}TaxSlabMaster/GetTaxSlabByFinancialYear?FinancialYear=${year}`
      );
      // console.log("API Response:", response.data); // Log to check the response

      if(response.data.success === "True") {
        // Filter data based on selected regime
        const filteredData = response.data.data.filter(
          (item) => item.regime === selectedRegime
        );
        // console.log("Filtered Data:", filteredData); // Log to check the filtered data

        if(filteredData.length > 0) {
          setSlabTaxComponentsArray(filteredData);
          setIsLoaderActive(false);

        } else {
          setSlabTaxComponentsArray([]); // Empty array when no data is found
          setIsLoaderActive(false);

        }
      } else {
        toast.error("Failed to fetch tax slab data");
        setIsLoaderActive(false);

      }
    } catch(error) {
      console.error("Error fetching tax slab data:", error);
      toast.error("Error fetching tax slab data");
    } finally {
      setIsLoaderActive(false);
      setFetchPreviousYear(false);
    }
  };


  const handleCheckboxChange = async (e) => {

    const isChecked = e.target.checked;
    setFetchPreviousYear(isChecked);

    if(isChecked) {
      const [startYear, endYear] = selectedYear.split("-");
      const previousYear = `${parseInt(startYear) - 1}-${parseInt(endYear) - 1}`;

      setIsLoaderActive(true);

      try {
        const response = await axios.get(
          `${config.API_URL}TaxSlabMaster/GetTaxSlabByFinancialYear?FinancialYear=${previousYear}`
        );

        if(response.data.success === "True") {
          const filteredData = response.data.data.filter(
            (item) => item.regime === selectedRegime
          );

          if(filteredData.length > 0) {
            setSlabTaxComponentsArray(filteredData);
            // toast.success(`Previous year (${previousYear}) data loaded`);
          } else {
            setSlabTaxComponentsArray([]);
            toast.error(`No data found for ${previousYear}`);
          }
        } else {
          setSlabTaxComponentsArray([]);
          toast.error("Failed to fetch previous year tax slab data");
        }
      } catch(error) {
        console.error("Error fetching previous year data:", error);
        toast.error("Error fetching previous year data");
      }
      finally {
        setIsLoaderActive(false);
      }
    } else {
      GetSlabDataByYear(selectedYear);
    }
  };


  return (
    <>
      <main id="main" className="addAssignee">
        <div className="content-header">
          <div className="container-fluid">
            <div className="row mb-2">
              <div className="col-sm-6">
                <h1 className="m-0">
                  Manage Tax Slab
                  <span
                    hover-tooltip="In this page you can set a particular tax regime for the whole employee and you can select the year for which you are setting this tax slab and you can also choose an old tax regime or the new tax regime."
                    tooltip-position="bottom"
                  >
                    <i
                      class="fas fa-info-circle"
                      style={{
                        marginLeft: "5px",
                        cursor: "pointer",
                        color: "rgb(0 0 0 / 51%)",
                      }}
                    ></i>
                  </span>
                </h1>
              </div>
              <div className="col-sm-6">
                <ol className="breadcrumb float-sm-right">
                  <li className="breadcrumb-item">
                    <Link to="/employee-dashboard">Home</Link>
                  </li>
                  <li className="breadcrumb-item active">Tax Slab</li>
                </ol>
              </div>
            </div>
          </div>
        </div>

        <div className="container-fluid px-3">
          <div className="card p-2">
            <div class="row">
              <div class="col-12 col-sm-6 col-md-3">
                <div
                  class="info-box reportcard mb-0"
                  value="old"
                  onClick={(e) => cardClickHandler("old")}
                  style={{
                    border: selectedRegime === "old" ? "1px solid rgb(35, 142, 220)" : "",
                    cursor: "pointer",
                  }}
                >
                  <span class="info-box-icon bg-primary elevation-1">
                    <div
                      className=""
                      style={{
                        position: "relative",
                        display: "inline-block",
                      }}
                    >
                      <i className="fas fa-money-check-alt" />
                      <i
                        className="fas fa-rupee-sign"
                        style={{
                          position: "absolute",
                          color: "#007bff",
                          backgroundColor: "white",
                          top: "50%",
                          left: "26%",
                          transform: "translate(-50%, -50%)",
                          fontSize: "15px",
                        }}
                      />
                    </div>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md">Old Regime</span>
                  </div>
                </div>
              </div>
              <div
                class="col-12 col-sm-6 col-md-3"
                style={{
                  cursor: "pointer",
                }}
                value="new"
                onClick={(e) => cardClickHandler("new")}
              >
                <div class="info-box reportcard mb-0" style={{
                  border: selectedRegime === "new" ? "1px solid rgb(35, 142, 220)" : "",
                  cursor: "pointer",
                }}>
                  <span class="info-box-icon bg-danger elevation-1">
                    <i class="fas fa-file-invoice"></i>
                  </span>
                  <div class="info-box-content">
                    <span class="text-bold text-md">New Regime</span>
                  </div>
                </div>
              </div>
              <div className="col-12 col-sm-6 col-md-3 ml-auto">
                <div className="row d-flex justify-content-end">
                  <div className="col-md-6">
                    <span className="text-nowrap ">Select Year</span>
                  </div>
                  <div className="col-md-7 ">
                    <select
                      value={selectedYear}
                      // onChange={(e) => {
                      //   setSelectedYear(e.target.value);
                      //   GetSlabDataByYear();
                      // }}
                      onChange={(e) => {
                        const newYear = e.target.value;
                        setFetchPreviousYear(false);
                        setSelectedYear(newYear);
                        GetSlabDataByYear(newYear);
                      }}
                      className="border border-gray-400 rounded px-4 py-2 w-52 cursor-pointer text-center bg-white shadow-md"
                    >
                      {generateYears().map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Table */}

        <div className="container-fluid">
          <div className="col-md-12">
            {/* First Card Section */}
            <div className="card card-outline card-primary">
              <div className="card-header">
                <div className="row align-items-center">
                  <div className="col-md-7">
                    <h3 className="card-title">
                      {selectedRegime == "new" ? "New Regime" : "Old Regime"} {selectedYear}
                    </h3>
                  </div>

                  <div className="col-md-5 float-right d-flex flex-row justify-content-between">
                    <div className="mr-2">
                      <input
                        type="checkbox"
                        id="fetchPreviousYear"
                        checked={fetchPreviousYear}
                        className="mt-2"
                        onChange={handleCheckboxChange}
                      />
                      <label htmlFor="fetchPreviousYear" className="ml-1">
                        Fetch Previous Year Data
                      </label>
                    </div>

                    <button
                      className="btn btn-sm float-right btn-primary mr-2"
                      onClick={() => {
                        savePayrollTemplateClickHandler();
                      }}
                      type="button"
                    >
                      Save Tax Template
                    </button>
                    <button
                      className="btn btn-sm float-right btn-default mr-1"
                      onClick={() => {
                        cancleBtnClickHandler();
                      }}
                      type="button"
                    >
                      Cancel
                    </button>
                    <div className="card-tools float-right mt-2">
                      <button
                        type="button"
                        className="btn btn-tool"
                        data-card-widget="maximize"
                      >
                        <i className="fas fa-expand"></i>
                      </button>
                    </div>
                  </div>

                </div>
              </div>
              <div className="card-body px-0 position-relative">
                {isLoaderActive && (
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: 0,
                      width: "100%",
                      height: "100%",
                      backgroundColor: "rgb(233 236 239 / 81%)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      zIndex: 10,
                    }}
                  >
                    <i
                      className="fas fa-sync-alt fa-spin"
                      style={{ fontSize: "2rem", color: "#333" }}
                    ></i>
                  </div>
                )}
                <div className="row">
                  <div className="col-md-12 ">
                    <div className="col-md-12">
                      <div className="table-responsive">
                        <table
                          id="faqs"
                          className="table table-bordered table-sm"
                        >
                          <thead>
                            <tr className="text-sm">
                              <th width="2%"></th>
                              <th width="6%">Sr. No.</th>
                              <th width="30%">From Tax Slab </th>
                              <th width="30%">To Tax Slab </th>
                              <th width="12%">Percentage (%)</th>
                              <th width="6%">Status</th>
                            </tr>
                          </thead>
                          <tbody id="tblBodyId">
                            {slabTaxComponentsArray.length > 0
                              ? slabTaxComponentsArray.map((data, index) => (
                                <tr key={data.id || index}>
                                  <td
                                    className="text-center"
                                    style={{ background: "#238edc" }}
                                  >
                                    <span className="handle ui-sortable-handle mt-5">
                                      <i className="fas fa-ellipsis-v"></i>
                                      <i className="fas fa-ellipsis-v"></i>
                                    </span>
                                  </td>
                                  <td>{index + 1}</td>
                                  <td>
                                    <input
                                      type="text"
                                      name="SalaryComponentsNameInput"
                                      placeholder="Enter from tax slab"
                                      value={data.minIncome}
                                      onChange={(e) =>
                                        handleSalaryComponentsNameChange(
                                          e,
                                          index,
                                          "name"
                                        )
                                      }
                                      className="form-control form-control-sm"
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="SalaryComponentsNameInput"
                                      placeholder="Enter to tax slab"
                                      value={data.maxIncome}
                                      onChange={(e) =>
                                        handleSalaryComponentsNameChange(
                                          e,
                                          index,
                                          "maxname"
                                        )
                                      }
                                      className="form-control form-control-sm"
                                    />
                                  </td>
                                  <td>
                                    <input
                                      type="text"
                                      name="PercentageInput"
                                      placeholder="Enter Salary Components Percentage (%)"
                                      value={data.taxRate || ""}
                                      onChange={(e) =>
                                        handleSalaryComponentsNameChange(
                                          e,
                                          index,
                                          "percentage"
                                        )
                                      }
                                      className="form-control form-control-sm numberAndFloatInput"
                                    />
                                  </td>
                                  <td>
                                    <span
                                      className="btn btn-outline-danger btn-sm cursor-pointer"
                                      onClick={() =>
                                        removeComponentFromArray(index)
                                      }
                                      title="Delete"
                                    >
                                      <i className="fas fa-trash"></i>
                                    </span>
                                  </td>
                                </tr>
                              ))
                              : null}
                          </tbody>
                        </table>
                      </div>
                      <div className="text-right">
                        <button
                          onClick={() => addNewSalaryComponents()}
                          className="btn btn-sm float-right btn-light"
                        >
                          + Add New Tax Components
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <ToastContainer position="top-center" />
      </main>
    </>
  );
}

export default ManageTaxSlab;
