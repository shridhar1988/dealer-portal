import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { ToastContainer, toast } from "react-toastify";

import { Link } from "react-router-dom";
import axios from "axios";
import config from "../../config/config.json";

function IncomeTaxSlabs() {
    const [isLoaderActive, setIsLoaderActive] = useState(false);
    const [show, setShow] = useState(false);
    const [selectedTaxSlab, setSelectedTaxSlab] = useState("");
    const [selectedYear, setSelectedYear] = useState("");
    const [oldRegimeData, setOldRegimeData] = useState([]);
    const [regime, setRegime] = useState("new");
    const [newRegimeData, setNewRegimeData] = useState([]);
    const [taxDeclarationData, setTaxDeclarationData] = useState([]);

    const currentYear = new Date().getFullYear();
    const personalInfo = useSelector((state) => state.personalInformationReducer);

    useEffect(() => {
        const defaultYear = `${currentYear}-${currentYear + 1}`;
        getTaxSlabOfEmp(defaultYear);
        setSelectedYear(defaultYear);
        handleYearChange(defaultYear);
        GetAllTaxComponentsByYear(defaultYear);
    }, [currentYear]);

    useEffect(() => {
        const taxDeclarationArray = Array.isArray(taxDeclarationData)
            ? taxDeclarationData
            : [taxDeclarationData];

        const filteredOldData = taxDeclarationArray.filter(
            (item) =>
                item.regime == "old" && item.financialYear == selectedYear
        );
        const filteredNewData = taxDeclarationArray.filter(
            (item) =>
                item.regime == "new" && item.financialYear == selectedYear
        );

        // console.log("taxDeclarationArray--->", taxDeclarationArray);

        // console.log("filteredOldData--->", filteredOldData);
        // console.log("filteredNewData--->", filteredNewData);

        setOldRegimeData(filteredOldData);
        setNewRegimeData(filteredNewData);
    }, [taxDeclarationData, selectedYear]);

    const generateYears = () => {
        let years = [];
        const startYear = currentYear-4;
        for (let i = startYear; i <= currentYear; i++) {
            years.push(`${i}-${i + 1}`);
        }
        return years;
    };

    const handleYearChange = (year) => {
        setSelectedYear(year);
        GetAllTaxComponentsByYear(year);
        setShow(true);
    };

    const getTaxSlabOfEmp = async (year) => {
        setIsLoaderActive(true);
        try {
            const response = await axios.get(
                `${config.apiEndPoint}/TaxSlabMaster/GetAllTaxSlabOfEmployee?EmpId=${personalInfo.userID}&year=${year}`
            );
            if (response.data.success == "True") {
                var slab = response.data.data.regimeName;
                // console.log("regimeName--->", response);

                var value = slab == "new" ? "2" : "1";
                setSelectedTaxSlab(value);
            } else {
                setSelectedTaxSlab("");

                // toast.error("Slab not updated");
            }
        } catch (error) {
            console.error("Error fetching components:", error);
        } finally {
            setIsLoaderActive(false);
        }
    };
    const handleTaxSlabChange = async (e) => {
        let response = await updateSlab(e.target.value);
        if (response == true) {
            // setSelectedTaxSlab(e.target.value);
            getTaxSlabOfEmp(selectedYear);
        }
    };
    const updateSlab = async (slab) => {
        setIsLoaderActive(true);
        try {
            const payload = {
                empId: personalInfo.userID,
                regimeName: slab == 1 ? "old" : "new",
                financialYear: selectedYear,
                createdBy: personalInfo.userID,
            };

            const response = await axios.post(
                `${config.API_URL}TaxSlabMaster/SelectTaxSlabByEmployee`,
                payload,
                { headers: { "Content-Type": "application/json" } }
            );

            if (response.data.success == "True") {
                toast.success("Slab updated successfully for year "+selectedYear);
            setIsLoaderActive(false);

                return true;
            } else {
                toast.error("Slab not updated");
            setIsLoaderActive(false);

                return false;
            }
        } catch {
            // console.log("Error while updating slab.");
            setIsLoaderActive(false);

            return false;
        } finally {
            setIsLoaderActive(false);
        }
    };
    const GetAllTaxComponentsByYear = async (year) => {
        setIsLoaderActive(true);

        try {
            const response = await axios.get(
                `${config.apiEndPoint}/TaxSlabMaster/GetTaxSlabByFinancialYear?FinancialYear=${year}`
            );
            const componentsArray = response.data.data || [];
            // console.log("GetAllPayrollComponents ===> ", componentsArray);
            setTaxDeclarationData(componentsArray);
            getTaxSlabOfEmp(year);
        } catch (error) {
            console.error("Error fetching components:", error);
        } finally {
            setIsLoaderActive(false);
        }
    };

    return (
        <>
            <main id="main" className="addAssignee">
                <div className="content-header">
                    <div className="container-fluid">
                        <div className="row mb-2">
                            <div className="col-sm-6">
                                <h1 className="m-0">
                                    Income Tax
                                    <span
                                        hover-tooltip="Here employees can view the Income Tax Slab based on the selected year and tax regime. They can choose the most suitable slab for themselves by selecting the appropriate option."
                                        tooltip-position="bottom"
                                    >
                                        <i
                                            className="fas fa-info-circle"
                                            style={{
                                                marginLeft: "5px",
                                                cursor: "pointer",
                                                color: "rgb(0 0 0 / 51%)",
                                            }}
                                        ></i>
                                    </span>
                                </h1>
                            </div>
                            <div className="col-sm-6">
                                <ol className="breadcrumb float-sm-right">
                                    <li className="breadcrumb-item">
                                        <Link to="/employee-dashboard">Home</Link>
                                    </li>
                                    <li className="breadcrumb-item active">Income Tax</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="container-fluid px-3">
                    <div className="card">
                        <div className="card-header">
                            <div className="row">
                                <div className="col-md-11">
                                    <div className="button-container d-flex">
                                        {generateYears().map((year) => (
                                            <button
                                                key={year}
                                                className={`btn btn-xs m-1 ${selectedYear === year ? "btn-primary" : "btn-default"
                                                    }`}
                                                onClick={() => handleYearChange(year)}
                                            >
                                                {year}
                                            </button>
                                        ))}
                                    </div>
                                </div>{" "}
                                <div className="card-tools ml-auto">
                                    <button
                                        type="button"
                                        className="btn btn-tool mt-1"
                                        data-card-widget="maximize"
                                    >
                                        <i className="fas fa-expand"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        {show && (
                            <div className="card-body pt-3 position-relative">
                                {isLoaderActive && (
                                    <div
                                        style={{
                                            position: "absolute",
                                            top: 0,
                                            left: 0,
                                            width: "100%",
                                            height: "100%",
                                            backgroundColor: "rgb(233 236 239 / 81%)",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            zIndex: 10,
                                        }}
                                    >
                                        <i
                                            className="fas fa-sync-alt fa-spin"
                                            style={{ fontSize: "2rem", color: "#333" }}
                                        ></i>
                                    </div>
                                )}
                                <div
                                    className="card-header"
                                    style={{ backgroundColor: "rgba(153, 198, 241, 0.39)" }}
                                >
                                    <h5 className="card-title mt-1">
                                        Income Tax Details for FY {selectedYear}
                                    </h5>
                                    <div className="card-tools">
                                        <select
                                            style={{
                                                cursor: "pointer",
                                                border: "1px solid #ddd",
                                                borderRadius: "5px",
                                            }}
                                            className="btn btn-default btn-xs py-1"
                                            onChange={handleTaxSlabChange}
                                            value={selectedTaxSlab}

                                        >
                                            <option value="" disabled>
                                                Choose Tax Regime
                                            </option>
                                            <option value="1">Old Tax Slab</option>
                                            <option value="2">New Tax Slab</option>
                                        </select>
                                    </div>
                                </div>
                                <style>
                                    {`
                                      .dot {
                                            color: rgba(71, 226, 47, 0.58)
                                        }`}
                                </style>

                                <div
                                    className="row d-flex p-2 pt-4"
                                    style={{ justifyContent: "space-between" }}
                                >
                                    <div
                                        className={`col-md-5 p-3 shadow-sm ${selectedTaxSlab == "1" ? "activeTax" : ""
                                            }`}
                                        style={{
                                            border: "1px solid #ddd",
                                            borderRadius: "8px",
                                            backgroundColor: "#fff",
                                        }}
                                    >
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                            <h6 className="mb-0 font-weight-bold">Old Slab</h6>
                                            {selectedTaxSlab == "1" && (
                                                <button
                                                    className="btn btn-xs text-xs"
                                                    style={{
                                                        borderRadius: "20px",
                                                        border: "1px solid rgba(71, 226, 47, 0.58)",
                                                        backgroundColor: "rgba(71, 226, 47, 0.1)",
                                                    }}
                                                >
                                                    <i className="fas fa-circle mr-1 text-success" />
                                                    Active
                                                </button>
                                            )}
                                        </div>

                                        <div className="table-responsive">
                                            <table className="table table-bordered table-striped text-center table-sm">
                                                <thead className="" style={{ backgroundColor: '#212529bf', color: '#fff' }}>
                                                    <tr className="text-sm">
                                                        <th>Sr. No.</th>
                                                        <th>Min Amount</th>
                                                        <th>Max Amount</th>
                                                        <th>Tax Rate</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {oldRegimeData.length > 0
                                                        ? oldRegimeData.map((data, index) => (
                                                            <tr key={index}>
                                                                <td>{index + 1}</td>
                                                                <td>{data.minIncome}</td>
                                                                <td>{data.maxIncome}</td>

                                                                <td>{data.taxRate}</td>
                                                            </tr>
                                                        ))
                                                        : null}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <div
                                        className={`col-md-5 p-3 shadow-sm ${selectedTaxSlab == "2" ? "activeTax" : ""
                                            }`}
                                        style={{
                                            border: "1px solid #ddd",
                                            borderRadius: "8px",
                                            backgroundColor: "#fff",
                                        }}
                                    >
                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                            <h6 className="mb-0 font-weight-bold">New Slab</h6>
                                            {selectedTaxSlab == "2" && (
                                                <button
                                                    className="btn btn-xs text-xs"
                                                    style={{
                                                        borderRadius: "20px",
                                                        border: "1px solid rgba(71, 226, 47, 0.58)",
                                                        backgroundColor: "rgba(71, 226, 47, 0.1)",
                                                    }}
                                                >
                                                    <i className="fas fa-circle mr-1 text-success" />
                                                    Active
                                                </button>
                                            )}
                                        </div>
                                        <div className="table-responsive">
                                            <table className="table table-bordered table-striped text-center table-sm">
                                                <thead className="" style={{ backgroundColor: '#212529bf', color: '#fff' }}>
                                                    <tr className="text-sm">
                                                        <th>Sr. No.</th>
                                                        <th>Min Amount</th>
                                                        <th>Max Amount</th>

                                                        <th>Tax Rate</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {newRegimeData.length > 0
                                                        ? newRegimeData.map((data, index) => (
                                                            <tr key={index}>
                                                                <td>{index + 1}</td>
                                                                <td>{data.minIncome}</td>
                                                                <td>{data.maxIncome}</td>
                                                                <td>{data.taxRate}</td>
                                                            </tr>
                                                        ))
                                                        : null}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                <ToastContainer position="top-center" />
            </main>
        </>
    );
}

export default IncomeTaxSlabs;
